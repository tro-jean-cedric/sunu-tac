/**
 * https://github.com/you-dont-need/You-Dont-Need-Lodash-Underscore?tab=readme-ov-file#_flatten
 * https://github.com/you-dont-need-x/you-dont-need-lodash
 */

// ----------------------------------------------------------------------

/**
 * Flatten a tree into a single list by repeatedly splicing in each node's
 * children array.
 *
 * @template {Record<string, unknown>} T
 * @param {T[] | null | undefined} list
 * @param {string} [key] Property holding the children. Defaults to
 *   `'children'`.
 * @returns {T[] | undefined}
 */
export function flattenArray(list, key = 'children') {
  let children = [];

  const flatten = list?.map((item) => {
    if (item[key] && item[key].length) {
      children = [...children, ...item[key]];
    }
    return item;
  });

  return flatten?.concat(children.length ? flattenArray(children, key) : children);
}

// ----------------------------------------------------------------------

/**
 * Fully flatten a nested array. Non-arrays yield `[]`.
 *
 * @param {readonly unknown[] | null | undefined} array
 * @returns {unknown[]}
 */
export function flattenDeep(array) {
  const isArray = array && Array.isArray(array);

  if (isArray) {
    return array.flat(Infinity);
  }
  return [];
}

// ----------------------------------------------------------------------

/**
 * Stable-ish sort by several properties. Returns a new array.
 *
 * @template T
 * @param {readonly T[]} array
 * @param {readonly (keyof T & string)[]} properties Property names to sort by,
 *   in priority order.
 * @param {readonly ('asc' | 'desc')[]} [orders] Direction per property.
 *   Defaults to ascending.
 * @returns {T[]}
 */
export function orderBy(array, properties, orders) {
  return array.slice().sort((a, b) => {
    for (let i = 0; i < properties.length; i += 1) {
      const property = properties[i];
      const order = orders && orders[i] === 'desc' ? -1 : 1;

      const aValue = a[property];
      const bValue = b[property];

      if (aValue < bValue) return -1 * order;
      if (aValue > bValue) return 1 * order;
    }
    return 0;
  });
}

// ----------------------------------------------------------------------

/**
 * Index a list by one of its properties (or by the item itself).
 *
 * @template T
 * @param {readonly T[] | null | undefined} array
 * @param {(keyof T & string)} [key] Property to use as the key. When omitted
 *   the item itself is stringified.
 * @returns {Record<string, T>}
 */
export function keyBy(array, key) {
  return (array || []).reduce((result, item) => {
    const keyValue = key ? item[key] : item;

    return { ...result, [String(keyValue)]: item };
  }, {});
}

// ----------------------------------------------------------------------

/**
 * Sum a list by projecting each item to a number.
 *
 * @template T
 * @param {readonly T[]} array
 * @param {(item: T) => number} iteratee
 * @returns {number}
 */
export function sumBy(array, iteratee) {
  return array.reduce((sum, item) => sum + iteratee(item), 0);
}

// ----------------------------------------------------------------------

/**
 * Structural deep equality for plain values, arrays and plain objects.
 *
 * @param {unknown} a
 * @param {unknown} b
 * @returns {boolean}
 */
export function isEqual(a, b) {
  if (a === null || a === undefined || b === null || b === undefined) {
    return a === b;
  }

  if (typeof a !== typeof b) {
    return false;
  }

  if (typeof a === 'string' || typeof a === 'number' || typeof a === 'boolean') {
    return a === b;
  }

  if (Array.isArray(a) && Array.isArray(b)) {
    if (a.length !== b.length) {
      return false;
    }

    return a.every((item, index) => isEqual(item, b[index]));
  }

  if (typeof a === 'object' && typeof b === 'object') {
    const keysA = Object.keys(a);
    const keysB = Object.keys(b);

    if (keysA.length !== keysB.length) {
      return false;
    }

    return keysA.every((key) => isEqual(a[key], b[key]));
  }

  return false;
}

// ----------------------------------------------------------------------

function isObject(item) {
  return item && typeof item === 'object' && !Array.isArray(item);
}

/**
 * Deep-merge `sources` into `target`. Mutates and returns `target`.
 *
 * @param {Record<string, unknown>} target
 * @param {...Record<string, unknown>} sources
 * @returns {Record<string, unknown>}
 */
export const merge = (target, ...sources) => {
  if (!sources.length) return target;

  const source = sources.shift();

  // eslint-disable-next-line no-restricted-syntax
  for (const key in source) {
    if (isObject(source[key])) {
      if (!target[key]) Object.assign(target, { [key]: {} });
      merge(target[key], source[key]);
    } else {
      Object.assign(target, { [key]: source[key] });
    }
  }

  return merge(target, ...sources);
};
