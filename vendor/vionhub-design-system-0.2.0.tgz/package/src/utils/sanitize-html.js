import DOMPurify from 'dompurify';

// Allowlist tuned for editor output: DOMPurify defaults plus the table family
// (Excel/Sheets paste produces these) and a couple of attributes we rely on.
const CONFIG = {
  ADD_TAGS: ['table', 'thead', 'tbody', 'tfoot', 'tr', 'th', 'td', 'colgroup', 'col'],
  ADD_ATTR: ['target', 'rel', 'colspan', 'rowspan', 'class', 'style'],
  // Excel pastes a lot of <o:p>, mso-* styles, conditional comments. DOMPurify
  // strips them by default; we keep FORBID_TAGS explicit for clarity.
  FORBID_TAGS: ['script', 'style', 'iframe', 'object', 'embed', 'form'],
  FORBID_ATTR: ['onerror', 'onload', 'onclick', 'onmouseover', 'onfocus', 'onblur'],
};

/**
 * Sanitize an HTML string with DOMPurify, keeping the table family and a few
 * layout attributes.
 *
 * @param {unknown} html Raw HTML. `null`/`undefined` yield `''`.
 * @returns {string}
 */
export const sanitizeHtml = (html) => {
  if (html == null) return '';
  return DOMPurify.sanitize(String(html), CONFIG);
};
