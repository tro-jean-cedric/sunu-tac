/**
 * MUI's own `onClose` signature, reused verbatim so the wrapped handler stays
 * assignable to `<Dialog onClose>`.
 *
 * @typedef {NonNullable<import('@mui/material').DialogProps['onClose']>} StaticDialogOnClose
 */

/**
 * Wraps a Dialog onClose so that clicks on the backdrop are ignored.
 * Escape key presses still close the dialog. Use as `onClose={staticDialog(handleClose)}`.
 *
 * @param {StaticDialogOnClose} [onClose] Handler to call for every reason other
 *   than `'backdropClick'`.
 * @returns {StaticDialogOnClose}
 */
export function staticDialog(onClose) {
  return (event, reason) => {
    if (reason === 'backdropClick') return;
    onClose?.(event, reason);
  };
}
