// ----------------------------------------------------------------------
// Locale handling
//
// The app resolved this through its i18n runtime (src/locales). In the design
// system the locale is injectable instead: call setFormatNumberLocale({ code,
// currency }) once at app startup (e.g. from your i18n language-change hook).
// Until then the formatters fall back to DEFAULT_LOCALE.

const DEFAULT_LOCALE = { code: 'en-US', currency: 'USD' };

let currentNumberLocale = null;

/**
 * Locale used by every formatter in this module.
 *
 * @typedef {object} FormatNumberLocale
 * @property {string} code BCP 47 tag passed to `Intl.NumberFormat`, e.g. `'fr-FR'`.
 * @property {string} currency ISO 4217 code used by {@link fCurrency}, e.g. `'XOF'`.
 */

/**
 * Loose numeric input accepted by every formatter below.
 *
 * @typedef {string | number | null | undefined} FormatNumberInput
 */

/**
 * Install the locale used by every formatter. Call once at app startup, e.g.
 * `setFormatNumberLocale({ code: 'fr-FR', currency: 'XOF' })`. Passing `null`
 * (or nothing) restores the `en-US`/`USD` fallback.
 *
 * @param {FormatNumberLocale | null} [locale]
 * @returns {void}
 */
export function setFormatNumberLocale(locale) {
  currentNumberLocale = locale ?? null;
}

function formatNumberLocale() {
  return currentNumberLocale;
}

function processInput(inputValue) {
  if (inputValue == null || Number.isNaN(inputValue)) return null;
  return Number(inputValue);
}

// ----------------------------------------------------------------------

/**
 * Format a number with the current locale (0-2 fraction digits).
 *
 * @param {FormatNumberInput} inputValue
 * @param {Intl.NumberFormatOptions} [options] Overrides merged into the
 *   `Intl.NumberFormat` options.
 * @returns {string} `''` when the input is nullish or `NaN`.
 */
export function fNumber(inputValue, options) {
  const locale = formatNumberLocale() || DEFAULT_LOCALE;

  const number = processInput(inputValue);
  if (number === null) return '';

  const fm = new Intl.NumberFormat(locale.code, {
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
    ...options,
  }).format(number);

  return fm;
}

// ----------------------------------------------------------------------

/**
 * Format a number as currency using the current locale.
 *
 * @param {FormatNumberInput} inputValue
 * @param {Intl.NumberFormatOptions} [options] Overrides merged into the
 *   `Intl.NumberFormat` options.
 * @returns {string} `''` when the input is nullish or `NaN`.
 */
export function fCurrency(inputValue, options) {
  const locale = formatNumberLocale() || DEFAULT_LOCALE;

  const number = processInput(inputValue);
  if (number === null) return '';

  const fm = new Intl.NumberFormat(locale.code, {
    style: 'currency',
    currency: locale.currency,
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
    ...options,
  }).format(number);

  return fm;
}

// ----------------------------------------------------------------------

/**
 * Format a number as a percentage. The input is a percentage value, e.g. `12` renders as `12%`.
 *
 * @param {FormatNumberInput} inputValue
 * @param {Intl.NumberFormatOptions} [options] Overrides merged into the
 *   `Intl.NumberFormat` options.
 * @returns {string} `''` when the input is nullish or `NaN`.
 */
export function fPercent(inputValue, options) {
  const locale = formatNumberLocale() || DEFAULT_LOCALE;

  const number = processInput(inputValue);
  if (number === null) return '';

  const fm = new Intl.NumberFormat(locale.code, {
    style: 'percent',
    minimumFractionDigits: 0,
    maximumFractionDigits: 1,
    ...options,
  }).format(number / 100);

  return fm;
}

// ----------------------------------------------------------------------

/**
 * Format a number in compact notation, e.g. `1.2k`.
 *
 * @param {FormatNumberInput} inputValue
 * @param {Intl.NumberFormatOptions} [options] Overrides merged into the
 *   `Intl.NumberFormat` options.
 * @returns {string} `''` when the input is nullish or `NaN`.
 */
export function fShortenNumber(inputValue, options) {
  const locale = formatNumberLocale() || DEFAULT_LOCALE;

  const number = processInput(inputValue);
  if (number === null) return '';

  const fm = new Intl.NumberFormat(locale.code, {
    notation: 'compact',
    maximumFractionDigits: 2,
    ...options,
  }).format(number);

  return fm.replace(/[A-Z]/g, (match) => match.toLowerCase());
}

// ----------------------------------------------------------------------

/**
 * Format a byte count with a binary unit suffix, e.g. `1.5 Mb`.
 *
 * @param {FormatNumberInput} inputValue
 * @returns {string}
 */
export function fData(inputValue) {
  const number = processInput(inputValue);
  if (number === null || number === 0) return '0 bytes';

  const units = ['bytes', 'Kb', 'Mb', 'Gb', 'Tb', 'Pb', 'Eb', 'Zb', 'Yb'];
  const decimal = 2;
  const baseValue = 1024;

  const index = Math.floor(Math.log(number) / Math.log(baseValue));
  const fm = `${parseFloat((number / baseValue ** index).toFixed(decimal))} ${units[index]}`;

  return fm;
}

// ----------------------------------------------------------------------
// Editable-input helpers.
// These are used by number text fields so that a value shows with a SPACE
// thousand separator while being typed (10000 -> "10 000"), yet is stored /
// submitted as plain digits ("10000"). The separator is always a plain space,
// independent of the locale used by fNumber/fCurrency above.

/**
 * Separator inserted between thousands by {@link formatNumberInput}.
 *
 * @type {string}
 */
export const THOUSAND_SEPARATOR = ' ';

/**
 * Strip a display value back to a plain numeric string: keep digits, a single
 * decimal point and an optional leading minus. "10 000,50" -> "10000.50".
 * Returns '' when there is nothing numeric to keep.
 *
 * @param {string | number | null | undefined} value
 * @returns {string}
 */
export function unformatNumber(value) {
  if (value == null) return '';
  let s = String(value).replace(/\s/g, '');
  const negative = s.startsWith('-');

  // Resolve the comma: it is a decimal separator (fr locale) only when it is
  // the sole grouping char; when a dot is present or there are several commas
  // the commas are thousand separators and must be dropped. This keeps pasted
  // "1,234,567.89" -> "1234567.89" instead of mangling it.
  const commaCount = (s.match(/,/g) || []).length;
  if (s.includes('.')) {
    s = s.replace(/,/g, '');
  } else if (commaCount > 1) {
    s = s.replace(/,/g, '');
  } else if (commaCount === 1) {
    s = s.replace(',', '.');
  }

  s = s.replace(/[^\d.]/g, '');
  const firstDot = s.indexOf('.');
  if (firstDot !== -1) {
    // keep only the first decimal point
    s = s.slice(0, firstDot + 1) + s.slice(firstDot + 1).replace(/\./g, '');
  }
  return negative && s !== '' ? `-${s}` : s;
}

/**
 * Format a raw value (number or in-progress string) with space thousand
 * separators, preserving a trailing/partial decimal so typing "10." or "10.50"
 * is not clobbered. "10000" -> "10 000", "1234.5" -> "1 234.5".
 *
 * @param {string | number | null | undefined} value
 * @returns {string}
 */
export function formatNumberInput(value) {
  const raw = unformatNumber(value);
  if (raw === '' || raw === '-') return raw;

  const negative = raw.startsWith('-');
  const body = negative ? raw.slice(1) : raw;
  const [intPart, ...decRest] = body.split('.');
  const grouped = intPart.replace(/\B(?=(\d{3})+(?!\d))/g, THOUSAND_SEPARATOR);
  const out = body.includes('.') ? `${grouped}.${decRest.join('')}` : grouped;

  return negative ? `-${out}` : out;
}
