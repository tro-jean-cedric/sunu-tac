// ----------------------------------------------------------------------

/**
 * Whether `window.localStorage` can actually be written to.
 *
 * @returns {boolean}
 */
export function localStorageAvailable() {
  try {
    const key = '__some_random_key_you_are_not_going_to_use__';
    window.localStorage.setItem(key, key);
    window.localStorage.removeItem(key);
    return true;
  } catch (error) {
    return false;
  }
}

// ----------------------------------------------------------------------

/**
 * Read a raw `localStorage` entry, guarded against unavailable storage.
 *
 * @param {string} key Storage key.
 * @param {string} [defaultValue] Value returned when the key is absent.
 *   Defaults to `''`.
 * @returns {string | undefined} `undefined` when storage is unavailable.
 */
export function localStorageGetItem(key, defaultValue = '') {
  const storageAvailable = localStorageAvailable();

  let value;

  if (storageAvailable) {
    value = localStorage.getItem(key) || defaultValue;
  }

  return value;
}
