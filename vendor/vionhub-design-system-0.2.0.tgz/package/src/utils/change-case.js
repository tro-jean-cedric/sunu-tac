// ----------------------------------------------------------------------

/**
 * Lowercase and dash-separate a string, dropping every other character.
 *
 * @param {string} str
 * @returns {string}
 */
export function paramCase(str) {
  return str
    .toLowerCase()
    .replace(/\s+/g, '-')
    .replace(/[^a-z0-9-]/g, '');
}

// ----------------------------------------------------------------------

/**
 * Lowercase and underscore-separate a string, dropping every other character.
 *
 * @param {string} str
 * @returns {string}
 */
export function snakeCase(str) {
  return str
    .toLowerCase()
    .replace(/\s+/g, '_')
    .replace(/[^a-z0-9_]/g, '');
}

// ----------------------------------------------------------------------

/**
 * Uppercase the first character, leaving the rest untouched.
 *
 * @param {string} string
 * @returns {string}
 */
export function sentenceCase(string) {
  return string.charAt(0).toUpperCase() + string.slice(1);
}
