import dayjs from 'dayjs';
import duration from 'dayjs/plugin/duration';
import relativeTime from 'dayjs/plugin/relativeTime';
import customParseFormat from 'dayjs/plugin/customParseFormat';

// ----------------------------------------------------------------------

dayjs.extend(duration);
dayjs.extend(relativeTime);
dayjs.extend(customParseFormat);

// The VionHub backend serializes timestamps from AdditionDataDto as
// "DD-MM-YYYY HH:mm", which dayjs cannot infer natively. Try the
// native parser first (ISO 8601, Date objects, timestamps) and fall
// back to the VionHub pattern before giving up.
const VIONHUB_DATE_FORMAT = 'DD-MM-YYYY HH:mm';

function parseFlexible(value) {
  if (value == null) return null;
  let d = dayjs(value);
  if (!d.isValid() && typeof value === 'string') {
    d = dayjs(value, VIONHUB_DATE_FORMAT);
  }
  return d.isValid() ? d : null;
}

/**
 * Anything dayjs can parse, plus the VionHub `DD-MM-YYYY HH:mm` backend format.
 *
 * @typedef {string | number | Date | import('dayjs').Dayjs | null | undefined} FormatTimeInput
 */

/**
 * Duration parts accepted by {@link fAdd} and {@link fSub}. Every part is
 * optional and defaults to `0`.
 *
 * @typedef {object} FormatTimeDuration
 * @property {number} [years]
 * @property {number} [months]
 * @property {number} [days]
 * @property {number} [hours]
 * @property {number} [minutes]
 * @property {number} [seconds]
 * @property {number} [milliseconds]
 */

/**
 * Docs: https://day.js.org/docs/en/display/format
 */
export const formatStr = {
  dateTime: 'DD MMM YYYY h:mm a', // 17 Apr 2022 12:00 am
  date: 'DD MMM YYYY', // 17 Apr 2022
  time: 'h:mm a', // 12:00 am
  split: {
    dateTime: 'DD/MM/YYYY h:mm a', // 17/04/2022 12:00 am
    date: 'DD/MM/YYYY', // 17/04/2022
  },
  paramCase: {
    dateTime: 'DD-MM-YYYY h:mm a', // 17-04-2022 12:00 am
    date: 'DD-MM-YYYY', // 17-04-2022
  },
};

/**
 * Start of the current day, formatted.
 *
 * @param {string} [format] dayjs format string. Defaults to dayjs' own default.
 * @returns {string}
 */
export function today(format) {
  return dayjs(new Date()).startOf('day').format(format);
}

// ----------------------------------------------------------------------

/**
 * output: 17 Apr 2022 12:00 am
 *
 * @param {FormatTimeInput} date
 * @param {string} [format] dayjs format string. Defaults to
 *   `formatStr.dateTime`.
 * @returns {string | null} `null` for a nullish input, `'Invalid time value'`
 *   for an unparsable one.
 */
export function fDateTime(date, format) {
  if (!date) {
    return null;
  }

  const isValid = dayjs(date).isValid();

  return isValid ? dayjs(date).format(format ?? formatStr.dateTime) : 'Invalid time value';
}

// ----------------------------------------------------------------------

/**
 * output: 17 Apr 2022
 *
 * @param {FormatTimeInput} date
 * @param {string} [format] dayjs format string. Defaults to
 *   `formatStr.date`.
 * @returns {string | null} `null` for a nullish input, `'Invalid time value'`
 *   for an unparsable one.
 */
export function fDate(date, format) {
  if (!date) {
    return null;
  }

  const isValid = dayjs(date).isValid();

  return isValid ? dayjs(date).format(format ?? formatStr.date) : 'Invalid time value';
}

// ----------------------------------------------------------------------

/**
 * output: 12:00 am
 *
 * @param {FormatTimeInput} date
 * @param {string} [format] dayjs format string. Defaults to
 *   `formatStr.time`.
 * @returns {string | null} `null` for a nullish input, `'Invalid time value'`
 *   for an unparsable one.
 */
export function fTime(date, format) {
  if (!date) {
    return null;
  }

  const isValid = dayjs(date).isValid();

  return isValid ? dayjs(date).format(format ?? formatStr.time) : 'Invalid time value';
}

// ----------------------------------------------------------------------

/**
 * output: 1713250100
 *
 * @param {FormatTimeInput} date
 * @returns {number | string | null} Epoch milliseconds, `null` for a nullish
 *   input, or `'Invalid time value'`.
 */
export function fTimestamp(date) {
  if (!date) {
    return null;
  }

  const isValid = dayjs(date).isValid();

  return isValid ? dayjs(date).valueOf() : 'Invalid time value';
}

// ----------------------------------------------------------------------

/**
 * output: a few seconds, 2 years
 *
 * @param {FormatTimeInput} date
 * @returns {string | null}
 */
export function fToNow(date) {
  if (!date) {
    return null;
  }

  const d = parseFlexible(date);
  return d ? d.toNow(true) : 'Invalid time value';
}

// ----------------------------------------------------------------------

/**
 * Whether `inputDate` falls inside the inclusive `[startDate, endDate]` range.
 *
 * @param {FormatTimeInput} inputDate
 * @param {FormatTimeInput} startDate
 * @param {FormatTimeInput} endDate
 * @returns {boolean}
 */
export function fIsBetween(inputDate, startDate, endDate) {
  if (!inputDate || !startDate || !endDate) {
    return false;
  }

  const formattedInputDate = fTimestamp(inputDate);
  const formattedStartDate = fTimestamp(startDate);
  const formattedEndDate = fTimestamp(endDate);

  if (formattedInputDate && formattedStartDate && formattedEndDate) {
    return formattedInputDate >= formattedStartDate && formattedInputDate <= formattedEndDate;
  }

  return false;
}

// ----------------------------------------------------------------------

/**
 * Whether `startDate` is strictly after `endDate`.
 *
 * @param {FormatTimeInput} startDate
 * @param {FormatTimeInput} endDate
 * @returns {boolean}
 */
export function fIsAfter(startDate, endDate) {
  return dayjs(startDate).isAfter(endDate);
}

// ----------------------------------------------------------------------

/**
 * Whether both dates fall in the same `units` bucket.
 *
 * @param {FormatTimeInput} startDate
 * @param {FormatTimeInput} endDate
 * @param {import('dayjs').OpUnitType} [units] Comparison unit. Defaults to
 *   `'year'`.
 * @returns {boolean | string} `'Invalid time value'` when either date is
 *   unparsable.
 */
export function fIsSame(startDate, endDate, units) {
  if (!startDate || !endDate) {
    return false;
  }

  const isValid = dayjs(startDate).isValid() && dayjs(endDate).isValid();

  if (!isValid) {
    return 'Invalid time value';
  }

  return dayjs(startDate).isSame(endDate, units ?? 'year');
}

// ----------------------------------------------------------------------

/** output:
 * Same day: 26 Apr 2024
 * Same month: 25 - 26 Apr 2024
 * Same month: 25 - 26 Apr 2024
 * Same year: 25 Apr - 26 May 2024
 */
/**
 * @param {FormatTimeInput} startDate
 * @param {FormatTimeInput} endDate
 * @param {boolean} [initial] Skip the shortening and always render both dates
 *   in full.
 * @returns {string}
 */
export function fDateRangeShortLabel(startDate, endDate, initial) {
  const isValid = dayjs(startDate).isValid() && dayjs(endDate).isValid();

  const isAfter = fIsAfter(startDate, endDate);

  if (!isValid || isAfter) {
    return 'Invalid time value';
  }

  let label = `${fDate(startDate)} - ${fDate(endDate)}`;

  if (initial) {
    return label;
  }

  const isSameYear = fIsSame(startDate, endDate, 'year');
  const isSameMonth = fIsSame(startDate, endDate, 'month');
  const isSameDay = fIsSame(startDate, endDate, 'day');

  if (isSameYear && !isSameMonth) {
    label = `${fDate(startDate, 'DD MMM')} - ${fDate(endDate)}`;
  } else if (isSameYear && isSameMonth && !isSameDay) {
    label = `${fDate(startDate, 'DD')} - ${fDate(endDate)}`;
  } else if (isSameYear && isSameMonth && isSameDay) {
    label = `${fDate(endDate)}`;
  }

  return label;
}

/**
 * Add a duration to now. output: '2024-05-28T05:55:31+00:00'
 *
 * @param {FormatTimeDuration} duration
 * @returns {string} ISO 8601 string.
 */
export function fAdd({
  years = 0,
  months = 0,
  days = 0,
  hours = 0,
  minutes = 0,
  seconds = 0,
  milliseconds = 0,
}) {
  const result = dayjs()
    .add(
      dayjs.duration({
        years,
        months,
        days,
        hours,
        minutes,
        seconds,
        milliseconds,
      })
    )
    .format();

  return result;
}

/**
 * Subtract a duration from now. output: '2024-05-28T05:55:31+00:00'
 *
 * @param {FormatTimeDuration} duration
 * @returns {string} ISO 8601 string.
 */
export function fSub({
  years = 0,
  months = 0,
  days = 0,
  hours = 0,
  minutes = 0,
  seconds = 0,
  milliseconds = 0,
}) {
  const result = dayjs()
    .subtract(
      dayjs.duration({
        years,
        months,
        days,
        hours,
        minutes,
        seconds,
        milliseconds,
      })
    )
    .format();

  return result;
}
