// @vionhub/design-system/src/motion — the raw-source deep-import path.
// =============================================================================
//
// The motion barrel's definition lives in `src/entries/motion.js`, which is the
// build entry behind the package's "./motion" export. THIS file is the source
// path a consumer reaches through the "./src/*" export condition:
//
//     import { m, varFade } from "@vionhub/design-system/src/motion";
//
// It re-exports the entry and nothing else. Keeping it a leaf — imported by no
// module inside this library — is deliberate: under `output.preserveModules`
// both files would otherwise map to `dist/motion.js`, and rollup would one day
// have to break the tie by renaming an output that the "./motion" export
// condition names explicitly. See the "ONE FILE, ONE OUTPUT" note in
// src/entries/motion.js.
//
// The framer-motion rationale, the mandatory `<MotionLazy>` mount and the
// "import `m`, never `motion`" rule are all documented there too.
// =============================================================================

export * from './entries/motion';
