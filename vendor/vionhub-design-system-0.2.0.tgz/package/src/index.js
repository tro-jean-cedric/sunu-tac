// @vionhub/design-system — public entry point.
//
// Export-name collisions were checked across all groups below (0 duplicates);
// `layouts` intentionally re-exports named symbols only (see its barrel).

// Global styles: @fontsource families (public-sans, barlow, dm-sans, inter,
// nunito-sans), the local 'Futura LT Pro' @font-face, plugin CSS and baseline
// resets. In the source app this lives in app.jsx (`import 'src/global.css'`);
// importing it here makes the lib build extract it — fonts inlined — into
// dist/styles.css, so the "./styles.css" export is the complete stylesheet.
import './global.css';

// Theme: ThemeProvider, createTheme/defaultThemeSettings, palette tokens
// (primary/secondary/... colors, typography, shadows, customShadows) and
// style helpers (varAlpha, stylesMode, ...).
export * from './theme';

// Components: every folder under src/components.
export * from './components';

// Layouts: dashboard/simple/main/auth-* + core sections + example nav configs.
export * from './layouts';

// Auth views: SignInView (the v2 login page design; the sign-in action is
// injected via the onSignIn prop) and its zod SignInSchema.
export * from './auth';

// Page sections: DashboardOverviewView (the v2 dashboard page, data via
// props) and its building blocks (DashboardHero, KpiTile, RoleWidgetCard),
// RequestsListView + RequestDetailDrawer (the v2 requests page), CrudListPage
// (admin CRUD screen, + CrudFormDialog/useCrudPaginatedList), CardGridListPage
// (card-grid list page, + ImageItemCard/ImageWithFallback) and the status
// views (ErrorStatusView + View403/NotFoundView/View500,
// ModulePlaceholderView).
export * from './sections';

// Routing helpers: RouterLink, useRouter/usePathname/useParams/... .
export * from './routes';

// Generic hooks (useBoolean, useTabs, useResponsive, ...).
export * from './hooks';

// Generic utils (fNumber, fDate, uuidv4, ...).
export * from './utils';

// Motion: the framer-motion primitives, lent out through this package.
//
// The library's OWN motion vocabulary (varFade, MotionLazy, AnimateCountUp,
// the motion* tokens, ...) already arrives above via `./components`. What is
// missing at this point is framer itself, and `types/motion.d.ts` publishes it
// from the root — so the runtime has to match, or `import { m } from
// '@vionhub/design-system'` type-checks and then crashes at runtime.
//
// Named, not `export * from './motion'`: a star re-export of that module would
// collide with the animate symbols already exported through `./components`,
// and ESM resolves an ambiguous star name by SILENTLY OMITTING it — varFade
// and friends would disappear from this barrel with no error anywhere.
//
// framer-motion is a peerDependency: these are the consumer's own copy.
// See src/entries/motion.js for the full rationale and the usage rules.
//
// Imported from './entries/motion', NOT from './motion': under
// `output.preserveModules` both of those source files map to `dist/motion.js`,
// so only one of them may ever be in the build graph. The entry is the one that
// has to be (it backs the "./motion" export condition), which makes
// `src/motion.js` a leaf that exists purely for the
// `@vionhub/design-system/src/motion` raw-source deep import.
export {
  m,
  motion,
  AnimatePresence,
  LazyMotion,
  domMax,
  domAnimation,
  MotionConfig,
  animate,
  useAnimate,
  useScroll,
  useSpring,
  useTransform,
  useMotionTemplate,
  useMotionValue,
  useMotionValueEvent,
  useInView,
  useReducedMotion,
  useAnimationControls,
  stagger,
} from './entries/motion';

export { CONFIG } from './config-global';
