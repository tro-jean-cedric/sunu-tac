// ----------------------------------------------------------------------

/**
 * Whether a URL carries a non-empty query string.
 *
 * @param {string} url
 * @returns {boolean}
 */
export const hasParams = (url) => {
  const queryString = url.split('?')[1];
  return queryString ? new URLSearchParams(queryString).toString().length > 0 : false;
};

// ----------------------------------------------------------------------

/**
 * Remove a trailing slash from a pathname, except from the root `'/'`.
 *
 * @param {string} pathname
 * @returns {string}
 */
export function removeLastSlash(pathname) {
  /**
   * Remove last slash
   * [1]
   * @input  = '/dashboard/calendar/'
   * @output = '/dashboard/calendar'
   * [2]
   * @input  = '/dashboard/calendar'
   * @output = '/dashboard/calendar'
   */
  if (pathname !== '/' && pathname.endsWith('/')) {
    return pathname.slice(0, -1);
  }

  return pathname;
}

// ----------------------------------------------------------------------

/**
 * Strip the query string (and any trailing slash) from a URL.
 *
 * @param {string} url
 * @returns {string}
 */
export function removeParams(url) {
  try {
    const urlObj = new URL(url, window.location.origin);

    return removeLastSlash(urlObj.pathname);
  } catch (error) {
    return url;
  }
}

// ----------------------------------------------------------------------

/**
 * Whether a URL points outside the app (starts with `http`).
 *
 * @param {string} url
 * @returns {boolean}
 */
export function isExternalLink(url) {
  return url.startsWith('http');
}
