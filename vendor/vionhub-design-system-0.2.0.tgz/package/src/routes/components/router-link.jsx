import { forwardRef } from 'react';
import { Link } from 'react-router-dom';

/**
 * Props of {@link RouterLink}.
 *
 * A thin wrapper over `react-router-dom`'s `<Link>` that additionally accepts
 * `href` as an alias for `to`, so it can stand in for a plain anchor. Both are
 * optional and both are forwarded, which is what lets the component be used
 * polymorphically as a MUI `component=` target:
 *
 *   <Button component={RouterLink} to="/import">…</Button>
 *   <Link component={RouterLink} href={paths.dashboard}>…</Link>
 *
 * @typedef {{ href?: string, to?: import('react-router-dom').To } & Omit<import('react-router-dom').LinkProps, 'to'>} RouterLinkProps
 */

/** @type {import('react').ForwardRefExoticComponent<RouterLinkProps & import('react').RefAttributes<HTMLAnchorElement>>} */
export const RouterLink = forwardRef(({ href, ...other }, ref) => (
  <Link ref={ref} to={href} {...other} />
));
