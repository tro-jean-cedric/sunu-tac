import { useMemo } from 'react';
import { useParams as _useParams } from 'react-router-dom';

// ----------------------------------------------------------------------

/**
 * Memoized `react-router-dom` route params.
 *
 * @returns {Readonly<import('react-router-dom').Params<string>>}
 */
export function useParams() {
  const params = _useParams();

  return useMemo(() => params, [params]);
}
