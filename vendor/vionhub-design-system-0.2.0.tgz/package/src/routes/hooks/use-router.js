import { useMemo } from 'react';
import { useNavigate } from 'react-router-dom';

// ----------------------------------------------------------------------

/**
 * Imperative navigation helpers, mirroring the Next.js router shape.
 *
 * @typedef {object} UseRouterReturn
 * @property {() => void} back Go one entry back in the history stack.
 * @property {() => void} forward Go one entry forward in the history stack.
 * @property {() => void} refresh Re-navigate to the current entry.
 * @property {(href: import('react-router-dom').To) => void} push
 * @property {(href: import('react-router-dom').To) => void} replace
 */

/**
 * @returns {UseRouterReturn}
 */
export function useRouter() {
  const navigate = useNavigate();

  const router = useMemo(
    () => ({
      back: () => navigate(-1),
      forward: () => navigate(1),
      refresh: () => navigate(0),
      push: (href) => navigate(href),
      replace: (href) => navigate(href, { replace: true }),
    }),
    [navigate]
  );

  return router;
}
