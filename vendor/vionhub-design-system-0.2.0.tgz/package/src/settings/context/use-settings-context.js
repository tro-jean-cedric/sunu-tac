import { useContext } from 'react';

import { SettingsContext } from './settings-provider';

// ----------------------------------------------------------------------

/**
 * Reads the settings context.
 * @returns {import('./settings-provider').SettingsContextValue}
 * @throws {Error} When used outside a `<SettingsProvider>`.
 */
export function useSettingsContext() {
  const context = useContext(SettingsContext);

  if (!context) throw new Error('useSettingsContext must be use inside SettingsProvider');

  return context;
}
