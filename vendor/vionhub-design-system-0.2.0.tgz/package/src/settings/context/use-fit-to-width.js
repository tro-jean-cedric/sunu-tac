import { useEffect } from 'react';

// ----------------------------------------------------------------------

/** Window width (CSS px) the app is laid out for; narrower windows scale down. */
export const FIT_DESIGN_WIDTH = 1440;

/** Never scale below this, so text stays readable on small laptops. */
export const FIT_MIN_SCALE = 0.8;

/**
 * Id of the element that gets zoomed — the React mount point, not `<html>`.
 * MUI portals (menus, popovers, tooltips, dialogs) mount in `<body>`, outside
 * it: they stay unzoomed and therefore land where their anchor is. Zooming
 * `<html>` instead would scale their measured position a second time and open
 * them up and to the left of the field.
 */
export const FIT_TARGET_ID = 'root';

/**
 * Scale factor that makes a `FIT_DESIGN_WIDTH`-wide layout fit the window:
 * 1 on wide windows, down to `FIT_MIN_SCALE` on narrow ones.
 * @param {number} viewportWidth
 * @returns {number}
 */
export function fitScale(viewportWidth) {
  return Math.max(FIT_MIN_SCALE, Math.min(1, viewportWidth / FIT_DESIGN_WIDTH));
}

/**
 * While `enabled`, zooms the app (`#root`, see `FIT_TARGET_ID`) so it keeps
 * its proportions on narrow windows — typically Windows at 125–150 % display scaling, where a
 * 1920 px screen only offers 1280 CSS px. Browser zoom (Ctrl +/−) also narrows
 * the window, so it is partly absorbed until the window exceeds the design width.
 *
 * The factor is exposed as the `--fit-scale` custom property so full-viewport
 * sizes can compensate (`calc(100vh / var(--fit-scale, 1))`).
 * @param {boolean} enabled
 */
export function useFitToWidth(enabled) {
  useEffect(() => {
    if (!enabled) return undefined;

    const root = document.getElementById(FIT_TARGET_ID) ?? document.body;

    const apply = () => {
      const scale = fitScale(window.innerWidth);
      root.style.zoom = scale === 1 ? '' : String(scale);
      root.style.setProperty('--fit-scale', String(scale));
    };

    apply();
    window.addEventListener('resize', apply);

    return () => {
      window.removeEventListener('resize', apply);
      root.style.zoom = '';
      root.style.removeProperty('--fit-scale');
    };
  }, [enabled]);
}
