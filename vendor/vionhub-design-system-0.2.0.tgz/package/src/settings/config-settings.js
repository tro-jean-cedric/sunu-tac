// Default font family of the design system. It lives here — and not in
// `src/theme` — so the settings layer stays free of any theme import:
// `src/theme` depends on `src/settings`, never the other way around.
export const defaultFont = 'Futura LT Pro';

// ----------------------------------------------------------------------

/** localStorage key the settings state is persisted under. */
export const STORAGE_KEY = 'app-settings';

/**
 * The persisted appearance settings of the app.
 * @typedef {object} SettingsState
 * @property {'light' | 'dark'} colorScheme
 * @property {'ltr' | 'rtl'} direction
 * @property {'default' | 'hight'} contrast
 * @property {'vertical' | 'horizontal' | 'mini'} navLayout
 * @property {'default' | 'cyan' | 'purple' | 'blue' | 'orange' | 'red'} primaryColor
 * @property {'integrate' | 'apparent'} navColor
 * @property {boolean} compactLayout
 * @property {string} fontFamily
 * @property {boolean} fitToWidth Scale the app down on windows narrower than
 *   1440 px (e.g. Windows display scaling at 150 %), never below 80 %.
 */

/** @type {SettingsState} */
export const defaultSettings = {
  colorScheme: 'light',
  direction: 'ltr',
  contrast: 'hight',
  navLayout: 'vertical',
  primaryColor: 'default',
  navColor: 'integrate',
  compactLayout: false,
  fontFamily: defaultFont,
  fitToWidth: false,
};
