// Settings context/config layer.
//
// Kept outside `src/components` on purpose: `src/theme` needs `defaultSettings`
// and `SettingsContext`, so hosting them here is what keeps the theme <->
// components import cycle broken. This folder must never import from
// `src/theme` or `src/components`.
//
// The settings drawer UI (SettingsDrawer) stays in `src/components/settings`
// and re-exports everything below, so the public API is unchanged.

export * from './context';

export * from './config-settings';
