import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import Divider from '@mui/material/Divider';
import MenuList from '@mui/material/MenuList';
import MenuItem from '@mui/material/MenuItem';
import Typography from '@mui/material/Typography';

import { useRouter } from 'src/routes/hooks';

import { Label } from 'src/components/label';
import { usePopover, CustomPopover } from 'src/components/custom-popover';

import { AccountButton } from './account-button';

// ----------------------------------------------------------------------

/**
 * Design-system version: the current user and the sign-out behavior are
 * injected via props instead of coming from the app auth context.
 *
 * @param {Array}    data        menu options: { label, href, icon, info? }
 * @param {Object}   user        { displayName, email, photoURL }
 * @param {Function} onSignOut   called when the sign-out button is clicked
 */
export function AccountPopover({
  data = [],
  user,
  onSignOut,
  signOutLabel = 'Déconnexion',
  sx,
  ...other
}) {
  const router = useRouter();

  const popover = usePopover();

  const handleClickItem = (path) => {
    popover.onClose();
    router.push(path);
  };

  return (
    <>
      <AccountButton
        open={popover.open}
        onClick={popover.onOpen}
        photoURL={user?.photoURL}
        displayName={user?.displayName}
        sx={sx}
        {...other}
      />

      <CustomPopover
        open={popover.open}
        anchorEl={popover.anchorEl}
        onClose={popover.onClose}
        slotProps={{
          paper: { sx: { p: 0, width: 200 } },
          arrow: { offset: 20 },
        }}
      >
        <Box sx={{ p: 2, pb: 1.5 }}>
          <Typography variant="subtitle2" noWrap>
            {user?.displayName}
          </Typography>

          <Typography variant="body2" sx={{ color: 'text.secondary' }} noWrap>
            {user?.email}
          </Typography>
        </Box>

        <Divider sx={{ borderStyle: 'dashed' }} />

        <MenuList sx={{ p: 1, my: 1 }}>
          {data.map((option) => (
            <MenuItem
              key={option.label}
              onClick={() => handleClickItem(option.href)}
              sx={{
                py: 1,
                color: 'text.secondary',
                '& svg': { width: 24, height: 24 },
                '&:hover': { color: 'text.primary' },
              }}
            >
              {option.icon}

              <Box component="span">{option.label}</Box>

              {option.info && (
                <Label color="error" sx={{ ml: 1 }}>
                  {option.info}
                </Label>
              )}
            </MenuItem>
          ))}
        </MenuList>

        {onSignOut && (
          <>
            <Divider sx={{ borderStyle: 'dashed' }} />

            <Box sx={{ p: 1 }}>
              <Button
                fullWidth
                size="medium"
                variant="text"
                color="error"
                onClick={() => {
                  popover.onClose();
                  onSignOut();
                }}
                sx={{ display: 'block', textAlign: 'left' }}
              >
                {signOutLabel}
              </Button>
            </Box>
          </>
        )}
      </CustomPopover>
    </>
  );
}
