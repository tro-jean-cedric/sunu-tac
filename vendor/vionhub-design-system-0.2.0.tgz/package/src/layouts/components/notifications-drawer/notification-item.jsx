import Box from '@mui/material/Box';
import Stack from '@mui/material/Stack';
import Tooltip from '@mui/material/Tooltip';
import IconButton from '@mui/material/IconButton';
import Typography from '@mui/material/Typography';
import ListItemText from '@mui/material/ListItemText';
import { alpha, useTheme } from '@mui/material/styles';
import ListItemAvatar from '@mui/material/ListItemAvatar';
import ListItemButton from '@mui/material/ListItemButton';

import { fToNow } from 'src/utils/format-time';

import { Iconify } from 'src/components/iconify';

// ----------------------------------------------------------------------

const TYPE_VISUAL = {
  INFO: { icon: 'solar:info-circle-bold', color: 'info' },
  SUCCESS: { icon: 'solar:check-circle-bold', color: 'success' },
  WARNING: { icon: 'solar:bell-bing-bold', color: 'warning' },
  ERROR: { icon: 'solar:close-circle-bold', color: 'error' },
};

const typeVisual = (type) => TYPE_VISUAL[type] ?? TYPE_VISUAL.INFO;

/**
 * Generic notification row.
 *
 * @param {Object}   notification       { title, body?, type?, createdAt, isRead?, sourceEntityType? }
 * @param {Object}   entityTypeLabels   optional map: sourceEntityType -> display label
 * @param {string}   removeLabel        tooltip on the remove button
 */
export function NotificationItem({
  notification,
  onClick,
  onRemove,
  entityTypeLabels = {},
  removeLabel = 'Supprimer',
}) {
  const theme = useTheme();
  const visual = typeVisual(notification.type);
  const paletteColor = theme.palette[visual.color]?.main ?? theme.palette.info.main;

  const entityLabel =
    notification.sourceEntityType && entityTypeLabels[notification.sourceEntityType];

  const renderAvatar = (
    <ListItemAvatar>
      <Stack
        alignItems="center"
        justifyContent="center"
        sx={{
          width: 40,
          height: 40,
          borderRadius: '50%',
          color: paletteColor,
          bgcolor: alpha(paletteColor, 0.12),
        }}
      >
        <Iconify icon={visual.icon} width={22} />
      </Stack>
    </ListItemAvatar>
  );

  const renderText = (
    <ListItemText
      disableTypography
      primary={
        <Typography variant="subtitle2" sx={{ mb: 0.25 }}>
          {notification.title}
        </Typography>
      }
      secondary={
        <>
          {notification.body && (
            <Typography variant="body2" sx={{ color: 'text.secondary', mb: 0.5 }}>
              {notification.body}
            </Typography>
          )}
          <Stack
            direction="row"
            alignItems="center"
            sx={{ typography: 'caption', color: 'text.disabled' }}
            divider={
              <Box
                sx={{
                  width: 2,
                  height: 2,
                  bgcolor: 'currentColor',
                  mx: 0.5,
                  borderRadius: '50%',
                }}
              />
            }
          >
            {fToNow(notification.createdAt)}
            {entityLabel && <span>{entityLabel}</span>}
          </Stack>
        </>
      }
    />
  );

  const renderUnReadBadge = !notification.isRead && (
    <Box
      sx={{
        top: 26,
        width: 8,
        height: 8,
        right: 20,
        borderRadius: '50%',
        bgcolor: 'info.main',
        position: 'absolute',
      }}
    />
  );

  const renderRemove = (
    <Tooltip title={removeLabel}>
      <IconButton
        size="small"
        onClick={(e) => {
          e.stopPropagation();
          onRemove?.();
        }}
        sx={{
          position: 'absolute',
          top: 8,
          right: 8,
          opacity: 0,
          transition: 'opacity 150ms ease',
          '.MuiListItemButton-root:hover &': { opacity: 1 },
        }}
      >
        <Iconify icon="mingcute:close-line" width={16} />
      </IconButton>
    </Tooltip>
  );

  return (
    <ListItemButton
      disableRipple
      onClick={onClick}
      sx={{
        p: 2.5,
        alignItems: 'flex-start',
        borderBottom: (t) => `dashed 1px ${t.vars.palette.divider}`,
        bgcolor: !notification.isRead ? (t) => alpha(t.palette.info.main, 0.04) : 'transparent',
      }}
    >
      {renderUnReadBadge}
      {renderRemove}
      {renderAvatar}
      <Stack sx={{ flexGrow: 1 }}>{renderText}</Stack>
    </ListItemButton>
  );
}
