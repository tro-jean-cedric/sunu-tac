import Box from '@mui/material/Box';
import Link from '@mui/material/Link';
import Button from '@mui/material/Button';
import { styled, useTheme } from '@mui/material/styles';

import { RouterLink } from 'src/routes/components';

import { Logo } from 'src/components/logo';

import { HeaderSection } from './header-section';
import { Searchbar } from '../components/searchbar';
import { MenuButton } from '../components/menu-button';
import { SignInButton } from '../components/sign-in-button';
import { AccountPopover } from '../components/account-popover';
import { SettingsButton } from '../components/settings-button';
import { WorkspacesPopover } from '../components/workspaces-popover';

// ----------------------------------------------------------------------

const StyledDivider = styled('span')(({ theme }) => ({
  width: 1,
  height: 10,
  flexShrink: 0,
  display: 'none',
  position: 'relative',
  alignItems: 'center',
  flexDirection: 'column',
  marginLeft: theme.spacing(2.5),
  marginRight: theme.spacing(2.5),
  backgroundColor: 'currentColor',
  color: theme.vars.palette.divider,
  '&::before, &::after': {
    top: -5,
    width: 3,
    height: 3,
    content: '""',
    flexShrink: 0,
    borderRadius: '50%',
    position: 'absolute',
    backgroundColor: 'currentColor',
  },
  '&::after': { bottom: -5, top: 'auto' },
}));

// ----------------------------------------------------------------------

/**
 * Design-system version: app-specific pieces (account drawer, notifications
 * drawer) are injected via slots/props instead of imported.
 *
 * - `data.user` / `data.account` / `slotProps.account` feed the AccountPopover.
 * - `slots.notifications` renders in place of the app NotificationsDrawer.
 * - `helpHref` / `purchaseHref` replace the hardcoded app routes.
 *
 * `slotsDisplay` toggles the slots this header actually renders. It used to
 * also destructure `contacts` and `localization`, for a contacts popover and a
 * language popover that this header does not ship — so those two flags were
 * read and then never consulted. They are gone rather than silently ignored;
 * the JSX for both is still below, commented out, and whoever re-enables it
 * puts the flag back at the same time.
 */
export function HeaderBase({
  sx,
  data,
  slots,
  slotProps,
  onOpenNav,
  layoutQuery,

  helpHref = '/faqs',
  helpLabel = 'Need help?',
  purchaseHref = 'https://mui.com/store/items/minimal-dashboard/',
  purchaseLabel = 'Purchase',

  slotsDisplay: {
    signIn = true,
    account = true,
    helpLink = true,
    settings = true,
    purchase = true,
    searchbar = true,
    workspaces = true,
    menuButton = true,
    notifications = true,
  } = {},

  ...other
}) {
  const theme = useTheme();

  return (
    <HeaderSection
      sx={sx}
      layoutQuery={layoutQuery}
      slots={{
        ...slots,
        leftAreaStart: slots?.leftAreaStart,
        leftArea: (
          <>
            {slots?.leftAreaStart}

            {/* -- Menu button -- */}
            {menuButton && (
              <MenuButton
                data-slot="menu-button"
                onClick={onOpenNav}
                sx={{
                  mr: 1,
                  ml: -1,
                  [theme.breakpoints.up(layoutQuery)]: { display: 'none' },
                }}
              />
            )}

            {/* -- Logo -- */}
            <Logo data-slot="logo" />

            {/* -- Divider -- */}
            <StyledDivider data-slot="divider" />

            {/* -- Workspace popover -- */}
            {workspaces && <WorkspacesPopover data-slot="workspaces" data={data?.workspaces} />}

            {slots?.leftAreaEnd}
          </>
        ),
        rightArea: (
          <>
            {slots?.rightAreaStart}

            <Box
              data-area="right"
              sx={{
                display: 'flex',
                alignItems: 'center',
                gap: { xs: 1, sm: 1.5 },
              }}
            >
              {/* -- Help link -- */}
              {helpLink && (
                <Link
                  data-slot="help-link"
                  href={helpHref}
                  component={RouterLink}
                  color="inherit"
                  sx={{ typography: 'subtitle2' }}
                >
                  {helpLabel}
                </Link>
              )}

              {/* -- Searchbar -- */}
              {searchbar && <Searchbar data-slot="searchbar" data={data?.nav} />}

              {/* -- Language popover: not shipped. Re-add `localization` to
                  slotsDisplay above if this is ever re-enabled. -- */}
              {/* <LanguagePopover data-slot="localization" data={data?.langs} /> */}

              {/* -- Notifications (inject an app-specific drawer/popover here) -- */}
              {notifications && slots?.notifications}

              {/* -- Contacts popover: not shipped. Re-add `contacts` to
                  slotsDisplay above if this is ever re-enabled. -- */}
              {/* <ContactsPopover data-slot="contacts" data={data?.contacts} /> */}

              {/* -- Settings button -- */}
              {settings && <SettingsButton data-slot="settings" />}

              {/* -- Account popover -- */}
              {account && (
                <AccountPopover
                  data-slot="account"
                  data={data?.account}
                  user={data?.user}
                  {...slotProps?.account}
                />
              )}

              {/* -- Sign in button -- */}
              {signIn && <SignInButton />}

              {/* -- Purchase button -- */}
              {purchase && (
                <Button
                  data-slot="purchase"
                  variant="contained"
                  rel="noopener"
                  target="_blank"
                  href={purchaseHref}
                  sx={{
                    display: 'none',
                    [theme.breakpoints.up(layoutQuery)]: {
                      display: 'inline-flex',
                    },
                  }}
                >
                  {purchaseLabel}
                </Button>
              )}
            </Box>

            {slots?.rightAreaEnd}
          </>
        ),
      }}
      slotProps={slotProps}
      {...other}
    />
  );
}
