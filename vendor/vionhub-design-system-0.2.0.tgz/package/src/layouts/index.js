// Layouts barrel.
//
// NOTE: deliberately uses named re-exports (not `export *`): each layout
// folder exports an internal styled `Main`, which would collide across
// folders in a wildcard barrel.

export { layoutClasses } from './classes';

// Layouts
export { DashboardLayout, DashboardContent } from './dashboard';
export { SimpleLayout, CompactContent } from './simple';
export { MainLayout } from './main';
export { AuthCenteredLayout } from './auth-centered';
export { AuthSplitLayout } from './auth-split';

// Core building blocks (for apps composing their own layout)
export { HeaderBase } from './core/header-base';
export { HeaderSection } from './core/header-section';
export { LayoutSection } from './core/layout-section';

// Example nav/account/workspace configs: `_account`, `_workspaces`,
// `mainNavData`, `dashboardNavData`
export * from './examples';
