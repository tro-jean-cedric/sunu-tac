import { useMemo } from 'react';

import Alert from '@mui/material/Alert';
import { useTheme } from '@mui/material/styles';
import { iconButtonClasses } from '@mui/material/IconButton';

import { useBoolean } from 'src/hooks/use-boolean';

import { varAlpha, stylesMode } from 'src/theme/styles';

import { bulletColor } from 'src/components/nav-section';
import { useSettingsOrDefaults } from 'src/components/settings/use-settings-or-defaults';

import { Main } from './main';
import { NavMobile } from './nav-mobile';
import { layoutClasses } from '../classes';
import { NavVertical } from './nav-vertical';
import { NavHorizontal } from './nav-horizontal';
import { HeaderBase } from '../core/header-base';
import { LayoutSection } from '../core/layout-section';

// ----------------------------------------------------------------------

/**
 * A single entry of the dashboard sidebar / horizontal nav.
 *
 * `icon` is a rendered node (e.g. `<Iconify icon="solar:home-2-outline" />`),
 * NOT an icon name.
 *
 * @typedef {object} DashboardNavItem
 * @property {string} title
 * @property {string} path
 * @property {import('react').ReactNode} [icon]
 * @property {import('react').ReactNode} [info]
 * @property {string} [caption]
 * @property {boolean} [disabled]
 * @property {DashboardNavItem[]} [children]
 */

/**
 * A group of nav items, optionally introduced by a subheader.
 *
 * @typedef {object} DashboardNavSection
 * @property {string} [subheader]
 * @property {DashboardNavItem[]} items
 */

/**
 * The signed-in user shown by the account popover.
 *
 * @typedef {object} DashboardLayoutUser
 * @property {string} [displayName]
 * @property {string} [email]
 * @property {string} [photoURL]
 */

/**
 * One entry of the account popover menu.
 *
 * @typedef {object} DashboardAccountMenuItem
 * @property {string} label
 * @property {string} href
 * @property {import('react').ReactNode} [icon]
 * @property {import('react').ReactNode} [info]
 */

/**
 * @typedef {object} DashboardLangOption
 * @property {string} value
 * @property {string} label
 * @property {string} [countryCode]
 */

/**
 * @typedef {object} DashboardWorkspaceOption
 * @property {string} id
 * @property {string} name
 * @property {string} [logo]
 * @property {string} [plan]
 */

/**
 * @typedef {object} DashboardContactOption
 * @property {string} id
 * @property {string} name
 * @property {string} [avatarUrl]
 * @property {string} [status]
 * @property {string | number | Date} [lastActivity]
 */

/**
 * Everything the layout needs from the host app. No auth/roles/i18n coupling.
 *
 * @typedef {object} DashboardLayoutData
 * @property {DashboardNavSection[]} [nav]
 * @property {DashboardLayoutUser} [user]
 * @property {DashboardAccountMenuItem[]} [account]
 * @property {DashboardLangOption[]} [langs]
 * @property {DashboardContactOption[]} [contacts]
 * @property {DashboardWorkspaceOption[]} [workspaces]
 * @property {unknown[]} [notifications]
 */

/**
 * Props forwarded to the AccountPopover through `slotProps.account`.
 *
 * @typedef {object} DashboardAccountSlotProps
 * @property {() => void | Promise<unknown>} [onSignOut]
 * @property {string} [signOutLabel]
 * @property {import('@mui/material').SxProps<import('@mui/material').Theme>} [sx]
 */

/**
 * @typedef {object} DashboardLayoutSlotProps
 * @property {DashboardAccountSlotProps} [account]
 * @property {import('@mui/material').ToolbarProps} [toolbar]
 * @property {import('@mui/material').ContainerProps} [container]
 */

/**
 * Extra header slots forwarded to HeaderBase.
 *
 * @typedef {object} DashboardHeaderSlots
 * @property {import('react').ReactNode} [topArea]
 * @property {import('react').ReactNode} [bottomArea]
 * @property {import('react').ReactNode} [leftAreaStart]
 * @property {import('react').ReactNode} [leftAreaEnd]
 * @property {import('react').ReactNode} [rightAreaStart]
 * @property {import('react').ReactNode} [rightAreaEnd]
 * @property {import('react').ReactNode} [notifications]
 */

/**
 * @typedef {object} DashboardLayoutProps
 * @property {import('@mui/material').SxProps<import('@mui/material').Theme>} [sx]
 * @property {import('react').ReactNode} [children]
 * @property {DashboardLayoutData} [data]
 * @property {DashboardLayoutSlotProps} [slotProps]
 * @property {DashboardHeaderSlots} [headerSlots]
 */

/**
 * Design-system version: all app data comes in via the `data` prop —
 * no auth/roles/i18n/mock coupling.
 *
 * @param {DashboardLayoutProps} props
 * @returns {import('react').JSX.Element}
 */
export function DashboardLayout({ sx, children, data, slotProps, headerSlots }) {
  const theme = useTheme();

  const mobileNavOpen = useBoolean();

  const settings = useSettingsOrDefaults();

  const navColorVars = useNavColorVars(theme, settings);

  const layoutQuery = 'lg';

  const navData = useMemo(() => data?.nav ?? [], [data]);

  const isNavMini = settings.navLayout === 'mini';

  const isNavHorizontal = settings.navLayout === 'horizontal';

  const isNavVertical = isNavMini || settings.navLayout === 'vertical';

  return (
    <>
      <NavMobile
        data={navData}
        open={mobileNavOpen.value}
        onClose={mobileNavOpen.onFalse}
        cssVars={navColorVars.section}
      />

      <LayoutSection
        /** **************************************
         * Header
         *************************************** */
        headerSection={
          <HeaderBase
            layoutQuery={layoutQuery}
            disableElevation={isNavVertical}
            onOpenNav={mobileNavOpen.onTrue}
            data={{
              nav: navData,
              user: data?.user,
              langs: data?.langs,
              account: data?.account,
              contacts: data?.contacts,
              workspaces: data?.workspaces,
              notifications: data?.notifications,
            }}
            slotsDisplay={{
              signIn: false,
              purchase: false,
              helpLink: false,
              workspaces: false,
            }}
            slots={{
              ...headerSlots,
              topArea: headerSlots?.topArea ?? (
                <Alert severity="info" sx={{ display: 'none', borderRadius: 0 }}>
                  This is an info Alert.
                </Alert>
              ),
              bottomArea: isNavHorizontal ? (
                <NavHorizontal
                  data={navData}
                  layoutQuery={layoutQuery}
                  cssVars={navColorVars.section}
                />
              ) : null,
            }}
            slotProps={{
              ...slotProps,
              toolbar: {
                sx: {
                  [`& [data-slot="logo"]`]: {
                    display: 'none',
                  },
                  [`& [data-area="right"]`]: {
                    gap: { xs: 0, sm: 0.75 },
                  },
                  ...(isNavHorizontal && {
                    bgcolor: 'var(--layout-nav-bg)',
                    [`& .${iconButtonClasses.root}`]: {
                      color: 'var(--layout-nav-text-secondary-color)',
                    },
                    [theme.breakpoints.up(layoutQuery)]: {
                      height: 'var(--layout-nav-horizontal-height)',
                    },
                    [`& [data-slot="workspaces"]`]: {
                      color: 'var(--layout-nav-text-primary-color)',
                    },
                    [`& [data-slot="logo"]`]: {
                      display: 'none',
                      [theme.breakpoints.up(layoutQuery)]: {
                        display: 'inline-flex',
                      },
                    },
                    [`& [data-slot="divider"]`]: {
                      [theme.breakpoints.up(layoutQuery)]: {
                        display: 'flex',
                      },
                    },
                  }),
                  ...slotProps?.toolbar?.sx,
                },
              },
              container: {
                maxWidth: false,
                sx: {
                  ...(isNavVertical && { px: { [layoutQuery]: 5 } }),
                  ...slotProps?.container?.sx,
                },
              },
            }}
          />
        }
        /** **************************************
         * Sidebar
         *************************************** */
        sidebarSection={
          isNavHorizontal ? null : (
            <NavVertical
              data={navData}
              isNavMini={isNavMini}
              layoutQuery={layoutQuery}
              cssVars={navColorVars.section}
              onToggleNav={() =>
                settings.onUpdateField(
                  'navLayout',
                  settings.navLayout === 'vertical' ? 'mini' : 'vertical'
                )
              }
            />
          )
        }
        /** **************************************
         * Footer
         *************************************** */
        footerSection={null}
        /** **************************************
         * Style
         *************************************** */
        cssVars={{
          ...navColorVars.layout,
          '--layout-transition-easing': 'linear',
          '--layout-transition-duration': '120ms',
          '--layout-nav-mini-width': '88px',
          '--layout-nav-vertical-width': '300px',
          '--layout-nav-horizontal-height': '64px',
          '--layout-dashboard-content-pt': theme.spacing(1),
          '--layout-dashboard-content-pb': theme.spacing(8),
          '--layout-dashboard-content-px': theme.spacing(5),
          '--layout-current-nav-width': '0px',
          [theme.breakpoints.up(layoutQuery)]: {
            '--layout-current-nav-width': isNavMini
              ? 'var(--layout-nav-mini-width)'
              : 'var(--layout-nav-vertical-width)',
          },
        }}
        sx={{
          [`& .${layoutClasses.hasSidebar}`]: {
            [theme.breakpoints.up(layoutQuery)]: {
              transition: theme.transitions.create(['padding-left'], {
                easing: 'var(--layout-transition-easing)',
                duration: 'var(--layout-transition-duration)',
              }),
              pl: isNavMini ? 'var(--layout-nav-mini-width)' : 'var(--layout-nav-vertical-width)',
            },
          },
          ...sx,
        }}
      >
        <Main isNavHorizontal={isNavHorizontal}>{children}</Main>
      </LayoutSection>
    </>
  );
}

// ----------------------------------------------------------------------

function useNavColorVars(theme, settings) {
  const {
    vars: { palette },
  } = theme;

  return useMemo(() => {
    switch (settings.navColor) {
      case 'integrate':
        return {
          layout: {
            '--layout-nav-bg': palette.common.white,
            '--layout-nav-horizontal-bg': varAlpha(palette.background.defaultChannel, 0.8),
            '--layout-nav-border-color': varAlpha(palette.grey['500Channel'], 0.12),
            '--layout-nav-text-primary-color': palette.text.primary,
            '--layout-nav-text-secondary-color': palette.text.secondary,
            '--layout-nav-text-disabled-color': palette.text.disabled,
            [stylesMode.dark]: {
              '--layout-nav-bg': palette.grey[900],
              '--layout-nav-border-color': varAlpha(palette.grey['500Channel'], 0.08),
              '--layout-nav-horizontal-bg': varAlpha(palette.background.defaultChannel, 0.96),
            },
          },
          section: {},
        };
      case 'apparent':
        return {
          layout: {
            '--layout-nav-bg': palette.grey[900],
            '--layout-nav-horizontal-bg': varAlpha(palette.grey['900Channel'], 0.96),
            '--layout-nav-border-color': 'transparent',
            '--layout-nav-text-primary-color': palette.common.white,
            '--layout-nav-text-secondary-color': palette.grey[500],
            '--layout-nav-text-disabled-color': palette.grey[600],
            [stylesMode.dark]: {
              '--layout-nav-bg': palette.grey[800],
              '--layout-nav-horizontal-bg': varAlpha(palette.grey['800Channel'], 0.8),
            },
          },
          section: {
            // caption
            '--nav-item-caption-color': palette.grey[600],
            // subheader
            '--nav-subheader-color': palette.grey[600],
            '--nav-subheader-hover-color': palette.common.white,
            // item
            '--nav-item-color': palette.grey[500],
            '--nav-item-root-active-color': palette.primary.light,
            '--nav-item-root-open-color': palette.common.white,
            // bullet
            '--nav-bullet-light-color': bulletColor.dark,
            // sub
            ...(settings.navLayout === 'vertical' && {
              '--nav-item-sub-active-color': palette.common.white,
              '--nav-item-sub-open-color': palette.common.white,
            }),
          },
        };
      default:
        throw new Error(`Invalid color: ${settings.navColor}`);
    }
  }, [
    palette.background.defaultChannel,
    palette.common.white,
    palette.grey,
    palette.primary.light,
    palette.text.disabled,
    palette.text.primary,
    palette.text.secondary,
    settings.navColor,
    settings.navLayout,
  ]);
}
