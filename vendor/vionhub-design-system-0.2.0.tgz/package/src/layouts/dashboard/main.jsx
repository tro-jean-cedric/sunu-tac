import Box from '@mui/material/Box';
import { useTheme } from '@mui/material/styles';
import Container from '@mui/material/Container';

import { layoutClasses } from 'src/layouts/classes';

import { useSettingsOrDefaults } from 'src/components/settings/use-settings-or-defaults';

// ----------------------------------------------------------------------

/**
 * @typedef {object} DashboardMainOwnProps
 * @property {boolean} [isNavHorizontal]
 */
/** @typedef {DashboardMainOwnProps & import('@mui/material').BoxProps} DashboardMainProps */

/**
 * @param {DashboardMainProps} props
 * @returns {import('react').JSX.Element}
 */
export function Main({ children, isNavHorizontal, sx, ...other }) {
  return (
    <Box
      component="main"
      className={layoutClasses.main}
      sx={{
        display: 'flex',
        flex: '1 1 auto',
        flexDirection: 'column',
        overflowX: 'hidden',
        ...(isNavHorizontal && {
          '--layout-dashboard-content-pt': '40px',
        }),
        ...sx,
      }}
      {...other}
    >
      {children}
    </Box>
  );
}

// ----------------------------------------------------------------------

/**
 * @typedef {object} DashboardContentOwnProps
 * @property {boolean} [disablePadding] Removes the content padding on every breakpoint.
 */
/**
 * `maxWidth` is only applied when the settings context runs in compact layout;
 * it accepts the same values as MUI `Container`.
 *
 * @typedef {DashboardContentOwnProps & import('@mui/material').ContainerProps} DashboardContentProps
 */

/**
 * @param {DashboardContentProps} props
 * @returns {import('react').JSX.Element}
 */
export function DashboardContent({ sx, children, disablePadding, maxWidth = 'lg', ...other }) {
  const theme = useTheme();

  const settings = useSettingsOrDefaults();

  const layoutQuery = 'lg';

  return (
    <Container
      className={layoutClasses.content}
      maxWidth={settings.compactLayout ? maxWidth : false}
      sx={{
        display: 'flex',
        flex: '1 1 auto',
        flexDirection: 'column',
        pt: 'var(--layout-dashboard-content-pt)',
        pb: 'var(--layout-dashboard-content-pb)',
        [theme.breakpoints.up(layoutQuery)]: {
          px: 'var(--layout-dashboard-content-px)',
        },
        ...(disablePadding && {
          p: {
            xs: 0,
            sm: 0,
            md: 0,
            lg: 0,
            xl: 0,
          },
        }),
        ...sx,
      }}
      {...other}
    >
      {children}
    </Container>
  );
}
