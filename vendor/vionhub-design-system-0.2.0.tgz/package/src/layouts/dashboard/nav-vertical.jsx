import Box from '@mui/material/Box';
import { useTheme } from '@mui/material/styles';

import { varAlpha, hideScrollY } from 'src/theme/styles';

import { Scrollbar } from 'src/components/scrollbar';
import { NavSectionMini, NavSectionVertical } from 'src/components/nav-section';

import { NavToggleButton } from '../components/nav-toggle-button';

// ----------------------------------------------------------------------

const VIONHUB_RED = '#c8332e';

function VionhubLogo({ size = 48, full = false }) {
  return (
    <Box
      component="img"
      src={full ? '/logo/logo-full-white.png' : '/logo/logo-single.png'}
      alt="VionHub"
      onError={(event) => {
        // apps that ship no white variant fall back to the colour logo
        if (full && !event.currentTarget.dataset.fallback) {
          event.currentTarget.dataset.fallback = '1';
          event.currentTarget.src = '/logo/logo-full.png';
        }
      }}
      sx={{
        height: size,
        width: 'auto',
        objectFit: 'contain',
      }}
    />
  );
}

function VionhubHeader({ onToggleNav, mini }) {
  if (mini) {
    return (
      <Box
        sx={{
          bgcolor: VIONHUB_RED,
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          py: 1.5,
        }}
      >
        <VionhubLogo size={36} />
      </Box>
    );
  }
  return (
    <Box
      sx={{
        bgcolor: VIONHUB_RED,
        display: 'flex',
        alignItems: 'center',
        gap: 1.5,
        px: 2,
        py: 1.5,
      }}
    >
      <Box sx={{ flexGrow: 1, display: 'flex', alignItems: 'center' }}>
        <VionhubLogo full size={48} />
      </Box>
      {/* <IconButton */}
      {/*   onClick={onToggleNav} */}
      {/*   sx={{ color: 'common.white', p: 0.5 }} */}
      {/*   aria-label="toggle navigation" */}
      {/* > */}
      {/*   <SvgIcon viewBox="0 0 24 24" sx={{ width: 28, height: 28 }}> */}
      {/*     <path */}
      {/*       fill="currentColor" */}
      {/*       d="M3 7h18v2H3zm4 5h14v2H7zm-4 5h18v2H3z" */}
      {/*     /> */}
      {/*   </SvgIcon> */}
      {/* </IconButton> */}
    </Box>
  );
}

// ----------------------------------------------------------------------

export function NavVertical({ sx, data, slots, isNavMini, layoutQuery, onToggleNav, ...other }) {
  const theme = useTheme();

  const renderNavVertical = (
    <>
      {slots?.topArea ?? <VionhubHeader onToggleNav={onToggleNav} />}

      <Scrollbar fillContent>
        <NavSectionVertical data={data} sx={{ px: 2, pt: 2, flex: '1 1 auto' }} {...other} />

        {slots?.bottomArea}
      </Scrollbar>
    </>
  );

  const renderNavMini = (
    <>
      {slots?.topArea ?? <VionhubHeader mini onToggleNav={onToggleNav} />}

      <NavSectionMini
        data={data}
        sx={{ pb: 2, px: 0.5, ...hideScrollY, flex: '1 1 auto', overflowY: 'auto' }}
        {...other}
      />

      {slots?.bottomArea}
    </>
  );

  return (
    <Box
      sx={{
        top: 0,
        left: 0,
        height: 1,
        display: 'none',
        position: 'fixed',
        flexDirection: 'column',
        bgcolor: 'var(--layout-nav-bg)',
        zIndex: 'var(--layout-nav-zIndex)',
        width: isNavMini ? 'var(--layout-nav-mini-width)' : 'var(--layout-nav-vertical-width)',
        borderRight: `1px solid var(--layout-nav-border-color, ${varAlpha(theme.vars.palette.grey['500Channel'], 0.12)})`,
        transition: theme.transitions.create(['width'], {
          easing: 'var(--layout-transition-easing)',
          duration: 'var(--layout-transition-duration)',
        }),
        [theme.breakpoints.up(layoutQuery)]: {
          display: 'flex',
        },
        ...sx,
      }}
    >
      <NavToggleButton
        isNavMini={isNavMini}
        onClick={onToggleNav}
        sx={{
          display: 'none',
          [theme.breakpoints.up(layoutQuery)]: {
            display: 'inline-flex',
          },
        }}
      />
      {isNavMini ? renderNavMini : renderNavVertical}
    </Box>
  );
}
