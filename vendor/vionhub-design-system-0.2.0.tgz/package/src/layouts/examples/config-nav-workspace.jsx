import { CONFIG } from 'src/config-global';

// ----------------------------------------------------------------------
// EXAMPLE workspaces popover data. Pass a customized copy to
// <WorkspacesPopover data={...}> or <DashboardLayout data={{ workspaces: ... }}>.

export const _workspaces = [
  {
    id: 'team-1',
    name: 'Team 1',
    logo: `${CONFIG.site.basePath}/assets/icons/workspaces/logo-1.webp`,
    plan: 'Free',
  },
  {
    id: 'team-2',
    name: 'Team 2',
    logo: `${CONFIG.site.basePath}/assets/icons/workspaces/logo-2.webp`,
    plan: 'Pro',
  },
  {
    id: 'team-3',
    name: 'Team 3',
    logo: `${CONFIG.site.basePath}/assets/icons/workspaces/logo-3.webp`,
    plan: 'Pro',
  },
];
