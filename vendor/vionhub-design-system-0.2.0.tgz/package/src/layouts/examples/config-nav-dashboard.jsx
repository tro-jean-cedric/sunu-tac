import { Iconify } from 'src/components/iconify';

// ----------------------------------------------------------------------
// EXAMPLE dashboard nav config (generic hrefs). In a real app, build this
// array yourself (e.g. filtered by user roles) and pass it to
// <DashboardLayout data={{ nav: navData }}>.

const icon = (name) => <Iconify icon={name} width={24} />;

const ICONS = {
  dashboard: icon('solar:home-2-outline'),
  user: icon('solar:users-group-rounded-outline'),
  parameter: icon('solar:buildings-2-outline'),
  order: icon('solar:cart-large-2-outline'),
  invoice: icon('solar:document-text-outline'),
  banking: icon('solar:wallet-money-outline'),
  folder: icon('solar:folder-outline'),
  label: icon('solar:tag-outline'),
  product: icon('solar:box-outline'),
  job: icon('solar:case-outline'),
};

// ----------------------------------------------------------------------

export const navData = [
  {
    items: [
      { title: 'Tableau de bord', path: '/dashboard', icon: ICONS.dashboard },
      { title: 'Utilisateurs', path: '/dashboard/users', icon: ICONS.user },
      { title: 'Filiales', path: '/dashboard/companies', icon: ICONS.parameter },
      { title: 'Demandes', path: '/dashboard/requests', icon: ICONS.order },
      { title: 'Bons de commandes', path: '/dashboard/purchase-orders', icon: ICONS.invoice },
      { title: 'Budgets', path: '/dashboard/budgets', icon: ICONS.banking },
      { title: 'Centre de coûts', path: '/dashboard/departments', icon: ICONS.folder },
      { title: 'Catégories', path: '/dashboard/categories', icon: ICONS.label },
      { title: 'Articles', path: '/dashboard/products', icon: ICONS.product },
      { title: 'Fournisseurs', path: '/dashboard/suppliers', icon: ICONS.job },
    ],
  },
];
