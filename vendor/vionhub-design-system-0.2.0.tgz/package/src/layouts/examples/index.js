export { _account } from './config-nav-account';
export { _workspaces } from './config-nav-workspace';
export { navData as mainNavData } from './config-nav-main';
export { navData as dashboardNavData } from './config-nav-dashboard';
