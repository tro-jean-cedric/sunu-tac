import { Iconify } from 'src/components/iconify';

// ----------------------------------------------------------------------
// EXAMPLE marketing-site nav (generic hrefs). Pass a customized copy to
// <MainLayout data={{ nav: navData }}>.

export const navData = [
  { title: 'Home', path: '/', icon: <Iconify width={22} icon="solar:home-2-bold-duotone" /> },
  {
    title: 'About us',
    path: '/about-us',
    icon: <Iconify width={22} icon="solar:atom-bold-duotone" />,
  },
  {
    title: 'Contact us',
    path: '/contact-us',
    icon: <Iconify width={22} icon="solar:notebook-bold-duotone" />,
  },
  { title: 'FAQs', path: '/faqs', icon: <Iconify width={22} icon="solar:notebook-bold-duotone" /> },
];
