import { Iconify } from 'src/components/iconify';

// ----------------------------------------------------------------------
// EXAMPLE account popover menu (generic hrefs). Pass a customized copy to
// <AccountPopover data={...}> or <DashboardLayout data={{ account: ... }}>.

export const _account = [
  {
    label: 'Tableau de bord',
    href: '/dashboard',
    icon: <Iconify icon="solar:home-angle-bold-duotone" />,
  },
  {
    label: 'Profil',
    href: '/dashboard/profile',
    icon: <Iconify icon="solar:user-bold-duotone" />,
  },
];
