import COLORS from './colors.json';
import { varAlpha, createPaletteChannel } from '../styles';

// ----------------------------------------------------------------------
// Design token shapes.
//
// Every palette token below goes through `createPaletteChannel`, which keeps the
// original hex keys and adds a `<key>Channel` sibling holding the "R G B" string
// used by `varAlpha`. The typedefs describe both halves so consumers can index
// into `theme.palette.*` (and into these raw tokens) with completion.
// ----------------------------------------------------------------------

/** The two color schemes the theme ships. */
/** @typedef {'light' | 'dark'} ThemeColorScheme */

/**
 * A full intensity ramp (primary, secondary, info, success, warning, error).
 * @typedef {object} ThemePaletteColor
 * @property {string} lighter
 * @property {string} light
 * @property {string} main
 * @property {string} dark
 * @property {string} darker
 * @property {string} contrastText
 * @property {string} lighterChannel
 * @property {string} lightChannel
 * @property {string} mainChannel
 * @property {string} darkChannel
 * @property {string} darkerChannel
 * @property {string} contrastTextChannel
 */

/**
 * Grey ramp, 50 -> 900, plus the matching RGB channels.
 * @typedef {{
 *   50: string; 100: string; 200: string; 300: string; 400: string;
 *   500: string; 600: string; 700: string; 800: string; 900: string;
 *   '50Channel': string; '100Channel': string; '200Channel': string;
 *   '300Channel': string; '400Channel': string; '500Channel': string;
 *   '600Channel': string; '700Channel': string; '800Channel': string;
 *   '900Channel': string;
 * }} ThemeGreyPalette
 */

/**
 * @typedef {object} ThemeCommonPalette
 * @property {string} black
 * @property {string} white
 * @property {string} blackChannel
 * @property {string} whiteChannel
 */

/**
 * @typedef {object} ThemeTextPalette
 * @property {string} primary
 * @property {string} secondary
 * @property {string} disabled
 * @property {string} primaryChannel
 * @property {string} secondaryChannel
 * @property {string} disabledChannel
 */

/**
 * @typedef {object} ThemeBackgroundPalette
 * @property {string} paper
 * @property {string} default
 * @property {string} neutral
 * @property {string} paperChannel
 * @property {string} defaultChannel
 * @property {string} neutralChannel
 */

/**
 * The scheme-independent part of `palette.action`.
 * @typedef {object} ThemeBaseActionPalette
 * @property {string} hover
 * @property {string} selected
 * @property {string} focus
 * @property {string} disabled
 * @property {string} disabledBackground
 * @property {number} hoverOpacity
 * @property {number} disabledOpacity
 */

/** @typedef {ThemeBaseActionPalette & { active: string }} ThemeActionPalette */

/**
 * Palette entries shared by both color schemes.
 * @typedef {object} ThemeBasePalette
 * @property {ThemePaletteColor} primary
 * @property {ThemePaletteColor} secondary
 * @property {ThemePaletteColor} info
 * @property {ThemePaletteColor} success
 * @property {ThemePaletteColor} warning
 * @property {ThemePaletteColor} error
 * @property {ThemeGreyPalette} grey
 * @property {ThemeCommonPalette} common
 * @property {string} divider
 * @property {{ light: ThemeActionPalette; dark: ThemeActionPalette }} action
 */

/**
 * Data-visualisation tokens for one color scheme.
 *
 * `categorical` is an IDENTITY palette: five hues in a FIXED order, assigned to
 * series by role and never cycled. It is not the role palette (`primary`,
 * `warning`, `info`, …) — those carry meaning ("this is an error") that a
 * series index does not have.
 *
 * These are plain hex strings with no `*Channel` siblings: chart engines take
 * hex, and none of the tokens is composited with `varAlpha`.
 *
 * @typedef {object} ThemeChartPalette
 * @property {[string, string, string, string, string]} categorical Fixed-order identity hues. Index 0 is the first series, index 4 the fifth. A sixth series folds into "Other", small multiples, or a second encoding — it never wraps back to index 0.
 * @property {string} positive Value above target / good change.
 * @property {string} negative Value below target / bad change.
 * @property {string} neutral Zero-point of the diverging scale, and the "no data" mark.
 * @property {[string, string, string]} diverging Polarity scale, negative -> neutral -> positive.
 */

/**
 * A complete, scheme-resolved palette.
 * @typedef {Omit<ThemeBasePalette, 'action'> & {
 *   text: ThemeTextPalette;
 *   background: ThemeBackgroundPalette;
 *   action: ThemeActionPalette;
 *   chart: ThemeChartPalette;
 * }} ThemePalette
 */

/**
 * @typedef {object} ThemeColorSchemes
 * @property {{ palette: ThemePalette }} light
 * @property {{ palette: ThemePalette }} dark
 */

// ----------------------------------------------------------------------

// Grey
/** @type {ThemeGreyPalette} */
export const grey = createPaletteChannel(COLORS.grey);

// Primary
/** @type {ThemePaletteColor} */
export const primary = createPaletteChannel(COLORS.primary);

// Secondary
/** @type {ThemePaletteColor} */
export const secondary = createPaletteChannel(COLORS.secondary);

// Info
/** @type {ThemePaletteColor} */
export const info = createPaletteChannel(COLORS.info);

// Success
/** @type {ThemePaletteColor} */
export const success = createPaletteChannel(COLORS.success);

// Warning
/** @type {ThemePaletteColor} */
export const warning = createPaletteChannel(COLORS.warning);

// Error
/** @type {ThemePaletteColor} */
export const error = createPaletteChannel(COLORS.error);

// Common
/** @type {ThemeCommonPalette} */
export const common = createPaletteChannel(COLORS.common);

// Text
/** @type {{ light: ThemeTextPalette; dark: ThemeTextPalette }} */
export const text = {
  light: createPaletteChannel({
    primary: grey[800],
    secondary: grey[600],
    disabled: grey[500],
  }),
  dark: createPaletteChannel({
    primary: '#FFFFFF',
    secondary: grey[500],
    disabled: grey[600],
  }),
};

// Background
/** @type {{ light: ThemeBackgroundPalette; dark: ThemeBackgroundPalette }} */
export const background = {
  light: createPaletteChannel({
    paper: '#FFFFFF',
    default: '#FFFFFF',
    neutral: grey[200],
  }),
  dark: createPaletteChannel({
    paper: grey[800],
    default: grey[900],
    neutral: '#28323D',
  }),
};

// Action
/** @type {ThemeBaseActionPalette} */
export const baseAction = {
  hover: varAlpha(grey['500Channel'], 0.08),
  selected: varAlpha(grey['500Channel'], 0.16),
  focus: varAlpha(grey['500Channel'], 0.24),
  disabled: varAlpha(grey['500Channel'], 0.8),
  disabledBackground: varAlpha(grey['500Channel'], 0.24),
  hoverOpacity: 0.08,
  disabledOpacity: 0.48,
};

/** @type {{ light: ThemeActionPalette; dark: ThemeActionPalette }} */
export const action = {
  light: { ...baseAction, active: grey[600] },
  dark: { ...baseAction, active: grey[500] },
};

// Chart
//
// The two ramps are SELECTED, not flipped: each step was measured against its
// own scheme's surfaces. Every number below is reproducible — WCAG contrast on
// sRGB relative luminance, pairwise separation as OKLab dE x100 under the
// Machado-Oliveira-Fernandes (2009) protanopia/deuteranopia simulation at
// severity 1.0, plus CIEDE2000 for reference.
//
// Measured on the chart surfaces this theme actually uses -- light
// `background.paper`/`default` #FFFFFF and `background.neutral` #F4F6F8; dark
// `background.paper` #1C252E, `background.default` #141A21 and
// `background.neutral` #28323D.
//
// LIGHT categorical, contrast vs #FFFFFF / #F4F6F8:
//   #006C9C 5.79 / 5.35   #CB3B2A 5.00 / 4.62   #118D57 4.22 / 3.90
//   #8E33FF 5.16 / 4.77   #7A4100 8.13 / 7.50            (floor 3.0 -- all pass)
//   worst pair, normal vision   dE 16.5  (#CB3B2A vs #7A4100)   -- floor 15
//   worst pair, protan/deutan   dE  6.4  (#CB3B2A vs #118D57)   -- floor 6
//   worst pair, CIEDE2000       21.8     (#CB3B2A vs #7A4100)
//
// DARK categorical, contrast vs #1C252E / #141A21 / #28323D:
//   #078DEE 4.47 / 5.05 / 3.75   #E84A6B 4.15 / 4.69 / 3.48
//   #118D57 3.67 / 4.14 / 3.08   #8E33FF 3.01 / 3.39 / 2.52
//   #B76E00 3.87 / 4.37 / 3.25
//   worst pair, normal vision   dE 16.0  (#E84A6B vs #B76E00)
//   worst pair, protan/deutan   dE  7.4  (#118D57 vs #B76E00)
//   worst pair, CIEDE2000       31.4     (#078DEE vs #8E33FF)
//
// TWO SLOTS DIVERGE BETWEEN THE SCHEMES, both for a measured reason:
//
//   index 0  #006C9C (light) -> #078DEE (dark). `info.dark` reaches only
//     2.68:1 on the dark card surface #1C252E, under the 3:1 floor for a
//     non-text mark. #078DEE (the `cyan` primary preset) is 4.47:1 and its
//     OKLCH L 0.632 sits inside the dark band, where #006C9C's 0.504 does not.
//
//   index 1  #CB3B2A (light) -> #E84A6B (dark). The brand red is too dark and
//     too low-contrast against #1C252E; `primary.light` is the dark-scheme step
//     of the same hue family.
//
// ONE SEEDED VALUE WAS CHANGED. Light index 4 was #B76E00 (`warning.dark`).
// Against light index 1 (#CB3B2A) it measured dE 11.5 under normal vision and
// 4.2 under deuteranopia -- both below floor: two adjacent warm hues at nearly
// the same lightness (OKLCH L 0.605 vs 0.564) collapse into one colour for a
// deuteranope and are hard work for everyone else. Red-vs-amber separation can
// only come from LIGHTNESS, since both sit on the same CVD confusion line, so
// the slot moved two steps down the same ramp to `warning.darker` #7A4100
// (L 0.437): dE 16.5 normal / 7.4 protan / 13.5 deutan / CIEDE2000 21.8 against
// #CB3B2A, and 8.13:1 on white. The alternative -- going lighter, e.g.
// `warning.main` #FFAB00 -- separates on lightness too but lands at 1.90:1 on
// white, far under the mark floor. #B76E00 is kept in the DARK ramp, where
// index 1 is the pinker #E84A6B and the pair measures dE 16.0 / 7.8.
//
// The 6-8 dE band is a floor, not a target: on both schemes the worst CVD pair
// (light #CB3B2A/#118D57 6.4, dark #118D57/#B76E00 7.4) is legal only because
// charts here always carry a second encoding -- `ChartLegends`, direct labels,
// and the 2px surface gap between adjacent marks. Do not ship a five-series
// chart that identifies series by colour alone.
//
// Known relief case: dark #8E33FF is 2.52:1 on `background.neutral` #28323D.
// It clears the floor on paper and default, which is where charts sit; lifting
// it to a paler purple was measured and rejected because it collapses against
// #078DEE under deuteranopia (dE 7.4 -> 3.1).
/** @type {{ light: ThemeChartPalette; dark: ThemeChartPalette }} */
export const chart = {
  light: {
    categorical: ['#006C9C', '#CB3B2A', '#118D57', '#8E33FF', '#7A4100'],
    positive: '#118D57', // success.dark  -- 4.22:1 on #FFFFFF
    negative: '#B71D18', // error.dark    -- 6.56:1 on #FFFFFF
    neutral: grey[500], //  #919EAB       -- the diverging zero point
    diverging: ['#B71D18', '#919EAB', '#118D57'],
  },
  dark: {
    categorical: ['#078DEE', '#E84A6B', '#118D57', '#8E33FF', '#B76E00'],
    positive: '#118D57', // 3.67:1 on #1C252E
    negative: '#E84A6B', // primary.light -- 4.15:1 on #1C252E, where error.dark
    //                      #B71D18 manages only 2.37:1
    neutral: grey[500], //  #919EAB       -- 5.68:1 on #1C252E
    diverging: ['#E84A6B', '#919EAB', '#118D57'],
  },
};

/*
 * Base palette
 */
/** @type {ThemeBasePalette} */
export const basePalette = {
  primary,
  secondary,
  info,
  success,
  warning,
  error,
  grey,
  common,
  divider: varAlpha(grey['500Channel'], 0.2),
  action,
};

/** @type {ThemePalette} */
export const lightPalette = {
  ...basePalette,
  text: text.light,
  background: background.light,
  action: action.light,
  chart: chart.light,
};

/** @type {ThemePalette} */
export const darkPalette = {
  ...basePalette,
  text: text.dark,
  background: background.dark,
  action: action.dark,
  chart: chart.dark,
};

// ----------------------------------------------------------------------

/** @type {ThemeColorSchemes} */
export const colorSchemes = {
  light: { palette: lightPalette },
  dark: { palette: darkPalette },
};
