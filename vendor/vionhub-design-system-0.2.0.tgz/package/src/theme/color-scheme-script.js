// ----------------------------------------------------------------------

/**
 * Color-scheme bootstrap configuration handed to MUI's CssVarsProvider.
 * @typedef {object} ThemeSchemeConfig
 * @property {string} modeStorageKey localStorage key holding the active mode.
 * @property {import('./core/palette').ThemeColorScheme} defaultMode
 */

/** @type {ThemeSchemeConfig} */
export const schemeConfig = {
  modeStorageKey: 'theme-mode',
  defaultMode: 'light',
};
