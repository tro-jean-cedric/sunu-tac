// ----------------------------------------------------------------------

/**
 * CSS selectors targeting the active MUI color scheme. Use them as keys inside
 * an `sx` / styleOverrides object:
 * `{ color: 'red', [stylesMode.dark]: { color: 'blue' } }`.
 * @typedef {object} ThemeStylesMode
 * @property {string} light
 * @property {string} dark
 */
/** @type {ThemeStylesMode} */
export const stylesMode = {
  light: '[data-mui-color-scheme="light"] &',
  dark: '[data-mui-color-scheme="dark"] &',
};

/**
 * @typedef {object} ThemeMediaQueries
 * @property {string} upXs
 * @property {string} upSm
 * @property {string} upMd
 * @property {string} upLg
 * @property {string} upXl
 */
/** @type {ThemeMediaQueries} */
export const mediaQueries = {
  upXs: '@media (min-width:0px)',
  upSm: '@media (min-width:600px)',
  upMd: '@media (min-width:900px)',
  upLg: '@media (min-width:1200px)',
  upXl: '@media (min-width:1536px)',
};

/**
 * Set font family.
 * @param {string} fontName
 * @returns {string} A full `font-family` stack starting with `fontName`.
 */
export function setFont(fontName) {
  return `"${fontName}",-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif,"Apple Color Emoji","Segoe UI Emoji","Segoe UI Symbol"`;
}

/**
 * Converts rem to px.
 * @param {string} value e.g. `'1.5rem'`
 * @returns {number}
 */
export function remToPx(value) {
  return Math.round(parseFloat(value) * 16);
}

/**
 * Converts px to rem.
 * @param {number} value
 * @returns {string}
 */
export function pxToRem(value) {
  return `${value / 16}rem`;
}

/**
 * Responsive font sizes.
 * @param {{ sm: number; md: number; lg: number }} sizes
 * @returns {Record<string, { fontSize: string }>} Media-query keyed style object.
 */
export function responsiveFontSizes({ sm, md, lg }) {
  return {
    [mediaQueries.upSm]: { fontSize: pxToRem(sm) },
    [mediaQueries.upMd]: { fontSize: pxToRem(md) },
    [mediaQueries.upLg]: { fontSize: pxToRem(lg) },
  };
}

/**
 * Converts a hex color to RGB channels.
 * @param {string} hex e.g. `'#00B8D9'`
 * @returns {string} e.g. `'0 184 217'`
 * @throws {Error} When `hex` is not a 6-digit hex color.
 */
export function hexToRgbChannel(hex) {
  if (!/^#[0-9A-F]{6}$/i.test(hex)) {
    throw new Error(`Invalid hex color: ${hex}`);
  }

  const r = parseInt(hex.substring(1, 3), 16);
  const g = parseInt(hex.substring(3, 5), 16);
  const b = parseInt(hex.substring(5, 7), 16);

  return `${r} ${g} ${b}`;
}

/**
 * Adds a `<key>Channel` sibling (RGB channels) to every entry of a hex palette.
 * @template {Record<string, string>} T
 * @param {T} hexPalette
 * @returns {T & Record<string, string>}
 */
export function createPaletteChannel(hexPalette) {
  const channelPalette = {};

  Object.entries(hexPalette).forEach(([key, value]) => {
    channelPalette[`${key}Channel`] = hexToRgbChannel(value);
  });

  return { ...hexPalette, ...channelPalette };
}

/**
 * Color with alpha channel.
 *
 * @param {string} color RGB channels (`'0 184 217'`) or a CSS variable holding
 *   channels (`'var(--palette-common-blackChannel, #000000)'`). Hex, `rgb()`
 *   and `rgba()` are rejected at runtime.
 * @param {number} [opacity=1]
 * @returns {string} e.g. `'rgba(0 184 217 / 0.24)'`
 * @throws {Error} When `color` is not a channel-based format.
 */
export function varAlpha(color, opacity = 1) {
  const unsupported =
    color.startsWith('#') ||
    color.startsWith('rgb') ||
    color.startsWith('rgba') ||
    (!color.includes('var') && color.includes('Channel'));

  if (unsupported) {
    throw new Error(`[Alpha]: Unsupported color format "${color}".
     Supported formats are:
     - RGB channels: "0 184 217".
     - CSS variables with "Channel" prefix: "var(--palette-common-blackChannel, #000000)".
     Unsupported formats are:
     - Hex: "#00B8D9".
     - RGB: "rgb(0, 184, 217)".
     - RGBA: "rgba(0, 184, 217, 1)".
     `);
  }

  return `rgba(${color} / ${opacity})`;
}
