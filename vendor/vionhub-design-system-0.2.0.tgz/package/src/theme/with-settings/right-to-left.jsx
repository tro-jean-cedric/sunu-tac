import { useEffect } from 'react';
import createCache from '@emotion/cache';
import rtlPlugin from 'stylis-plugin-rtl';
import { CacheProvider } from '@emotion/react';

// ----------------------------------------------------------------------

const cacheRtl = createCache({
  key: 'rtl',
  prepend: true,
  stylisPlugins: [rtlPlugin],
});

/**
 * @typedef {object} RTLProps
 * @property {import('react').ReactNode} [children]
 * @property {'ltr' | 'rtl'} direction
 */

/**
 * Mounts the RTL emotion cache when `direction` is `'rtl'` and keeps
 * `document.dir` in sync.
 * @param {RTLProps} props
 * @returns {import('react').JSX.Element}
 */
export function RTL({ children, direction }) {
  useEffect(() => {
    document.dir = direction;
  }, [direction]);

  if (direction === 'rtl') {
    return <CacheProvider value={cacheRtl}>{children}</CacheProvider>;
  }

  return <>{children}</>;
}
