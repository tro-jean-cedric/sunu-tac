// @vionhub/design-system/sections — subpath entry.
//
// Page-level screens: DashboardOverviewView, RequestsListView, CrudListPage, CardGridListPage, the status views, ...
//
// PURE RE-EXPORT, BY DESIGN. This file must never import CSS and must never
// gain a side effect: `import \"@vionhub/design-system/sections\"` has to stay
// statically analysable so a bundler can drop everything the consumer did not
// name. The stylesheet is a separate, explicit import:
//
//     import \"@vionhub/design-system/styles.css\";
//
// (The root entry \"@vionhub/design-system\" DOES import global.css — that is the
// one entry that is deliberately side-effectful, and the reason this file
// exists alongside it.)
//
// COST NOTE: this subpath is NOT cheap. Six files under src/sections statically
// import DashboardContent / SimpleLayout from ../layouts, which pulls in
// ./components and ./theme. Importing @vionhub/design-system/sections therefore
// costs roughly what the root barrel costs. It is an API-ergonomics boundary,
// not a size boundary. See docs/host-setup.md.
export * from "../sections";
