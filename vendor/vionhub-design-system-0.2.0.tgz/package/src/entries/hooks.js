// @vionhub/design-system/hooks — subpath entry.
//
// Generic hooks — useBoolean, useTabs, useResponsive, useSetState, ...
//
// PURE RE-EXPORT, BY DESIGN. This file must never import CSS and must never
// gain a side effect: `import \"@vionhub/design-system/hooks\"` has to stay
// statically analysable so a bundler can drop everything the consumer did not
// name. The stylesheet is a separate, explicit import:
//
//     import \"@vionhub/design-system/styles.css\";
//
// (The root entry \"@vionhub/design-system\" DOES import global.css — that is the
// one entry that is deliberately side-effectful, and the reason this file
// exists alongside it.)
//
// COST NOTE: this subpath is NOT dependency-free. src/hooks/use-scroll-offset-top.js
// imports framer-motion, so @vionhub/design-system/hooks pulls the (peer)
// framer-motion package in. Everything else here is React-only.
export * from "../hooks";
