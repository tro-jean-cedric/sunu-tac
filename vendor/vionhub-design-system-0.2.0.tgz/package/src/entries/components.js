// @vionhub/design-system/components — subpath entry.
//
// Every folder under src/components — Label, Iconify, Scrollbar, Chart, the animate/ motion vocabulary, the form Field set, the editor, the map, ...
//
// PURE RE-EXPORT, BY DESIGN. This file must never import CSS and must never
// gain a side effect: `import \"@vionhub/design-system/components\"` has to stay
// statically analysable so a bundler can drop everything the consumer did not
// name. The stylesheet is a separate, explicit import:
//
//     import \"@vionhub/design-system/styles.css\";
//
// (The root entry \"@vionhub/design-system\" DOES import global.css — that is the
// one entry that is deliberately side-effectful, and the reason this file
// exists alongside it.)
//
// COST NOTE: the barrel is the union of every component folder. With
// `output.preserveModules: true` a bundler tree-shakes down to what you name,
// but the barrel itself reaches mapbox-gl, tiptap, apexcharts, react-joyride and
// the lightbox — so measure before assuming a win. See docs/host-setup.md.
export * from "../components";
