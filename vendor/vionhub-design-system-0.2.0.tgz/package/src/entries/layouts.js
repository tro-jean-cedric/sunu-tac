// @vionhub/design-system/layouts — subpath entry.
//
// DashboardLayout/DashboardContent, SimpleLayout, MainLayout, the auth layouts, their core sections and the example nav configs.
//
// PURE RE-EXPORT, BY DESIGN. This file must never import CSS and must never
// gain a side effect: `import \"@vionhub/design-system/layouts\"` has to stay
// statically analysable so a bundler can drop everything the consumer did not
// name. The stylesheet is a separate, explicit import:
//
//     import \"@vionhub/design-system/styles.css\";
//
// (The root entry \"@vionhub/design-system\" DOES import global.css — that is the
// one entry that is deliberately side-effectful, and the reason this file
// exists alongside it.)
export * from "../layouts";
