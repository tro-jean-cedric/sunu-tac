// @vionhub/design-system/motion — subpath entry, AND the definition of the motion
// barrel. The two are the same file on purpose; see "ONE FILE, ONE OUTPUT".
//
// =============================================================================
//
// WHAT THIS IS FOR
// ----------------
// framer-motion is a PEER dependency of this package. That is the whole point
// of this file: peer means the app and the library share ONE framer-motion
// instance, and a single instance is a hard requirement for framer to work
// across the boundary at all —
//
//   * `m` components read their feature bundle from a `LazyMotion` React
//     context. Two copies of framer-motion means two distinct contexts, so the
//     library's `<MotionLazy>` cannot supply features to the app's `m`
//     components, and vice versa: the animation silently does nothing.
//   * `AnimatePresence` likewise only sees exiting children created by its own
//     copy.
//
// Before framer-motion became a peer dep it resolved only inside this package's
// own node_modules, so consumers could not animate with it at all — the
// reference app hand-rolled a parallel vocabulary in MUI transitions and
// emotion keyframes to work around exactly that. Re-exporting the primitives
// from here means an app never imports 'framer-motion' by name, which in turn
// means it cannot accidentally install a second copy.
//
// HOW TO USE IT
// -------------
// 1. Mount `<MotionLazy>` once, high up (next to `ThemeProvider`). Without it
//    every `m` component renders correctly and animates NOT AT ALL, with no
//    warning. See the JSDoc on `MotionLazy`.
// 2. Import `m`, never `motion` — `motion.*` statically pulls in the whole
//    feature bundle and THROWS in development inside a strict `MotionLazy`.
//    `motion` is re-exported for the rare escape hatch (and for code outside a
//    `MotionLazy`), not as the default choice.
// 3. Reach for the library vocabulary (`varFade`, `MotionViewport`, ...) before
//    writing raw variants, and for the `motion*` timing tokens before writing a
//    raw duration.
//
// Everything here is also exported from the package root; this module exists so
// motion-related symbols can be found in one place.
//
// PURE RE-EXPORT, BY DESIGN. This file must never import CSS and must never
// gain a side effect: `import "@vionhub/design-system/motion"` has to stay
// statically analysable so a bundler can drop everything the consumer did not
// name. The stylesheet is a separate, explicit import:
//
//     import "@vionhub/design-system/styles.css";
//
// (The root entry "@vionhub/design-system" DOES import global.css — that is the
// one entry that is deliberately side-effectful, and the reason this file
// exists alongside it.)
//
// ONE FILE, ONE OUTPUT
// --------------------
// The re-export list below used to live in src/motion.js, and this file was
// `export * from "../motion"`. Two source modules then wanted the SAME output
// path: the build emits with `output.preserveModules`, which mirrors the source
// tree, and both `src/motion.js` (reached from src/index.js) and
// `src/entries/motion.js` (an entry) mapped to `dist/motion.js`. Rollup papered
// over it only because src/motion.js was a pure re-export with no bindings of
// its own, so it folded into the entry and exactly one file came out. The day
// any library module gained something rollup could not fold, it would have had
// to disambiguate — and it does that by renaming an output, which would have
// silently moved `dist/motion.js`, the file the "./motion" export condition
// points at.
//
// So the list lives HERE, in the entry, and nothing else in the build graph
// resolves to `dist/motion.js`. `src/motion.js` still exists — it is the public
// deep-import path `@vionhub/design-system/src/motion` — but it is now a leaf that
// re-exports this file and is imported by no library module, so it never enters
// the bundle at all.
//
// COST NOTE: importing anything from here pulls framer-motion in. That is
// unavoidable and it is the point.
// =============================================================================

// -----------------------------------------------------------------------------
// framer-motion primitives, re-exported so the app shares this package's copy.
// -----------------------------------------------------------------------------

export {
  /** The 5kb feature-less motion component. THE ONE TO USE. Needs a `MotionLazy` ancestor. */
  m,
  /** The full motion component (~34kb). Throws inside a strict `MotionLazy` — prefer `m`. */
  motion,
  /** Keeps children mounted while they play their `exit` variant. */
  AnimatePresence,
  /** Loads a feature bundle for every `m` descendant. Prefer this package's `MotionLazy` wrapper. */
  LazyMotion,
  /** Every feature: gestures, layout projection, drag. What `MotionLazy` loads. */
  domMax,
  /** Animation + gestures, no layout projection or drag. A smaller `domMax`. */
  domAnimation,
  /** Global animation defaults (`transition`, `reducedMotion`) for a subtree. */
  MotionConfig,
  /** Imperatively animate a value, an element or a `MotionValue`. Not a hook. */
  animate,
  /** `[scope, animate]` — imperative animations scoped to a ref'd subtree. */
  useAnimate,
  /** Scroll position as 0-1 `MotionValue`s, for the page or a container. */
  useScroll,
  /** Spring-follows a `MotionValue`, for smoothing jumpy input like scroll. */
  useSpring,
  /** Maps one `MotionValue` onto another (ranges, or an arbitrary function). */
  useTransform,
  /** Interpolates several `MotionValue`s into a string, e.g. a `filter` or `background`. */
  useMotionTemplate,
  /** Creates a `MotionValue` — animatable state that does NOT trigger React renders. */
  useMotionValue,
  /** Subscribes to `'change'` on a `MotionValue` without re-rendering. */
  useMotionValueEvent,
  /** `true` when an element is in the viewport. */
  useInView,
  /** Reactive `prefers-reduced-motion`. See also this package's one-shot `prefersReducedMotion()`. */
  useReducedMotion,
  /** Imperative variant controls to hand to a component's `animate` prop. */
  useAnimationControls,
  /** Delay function for `staggerChildren`-style sequencing. */
  stagger,
} from 'framer-motion';

// -----------------------------------------------------------------------------
// This library's motion vocabulary.
// -----------------------------------------------------------------------------

export {
  // Providers / containers.
  MotionLazy,
  MotionContainer,
  MotionViewport,
  // Animated components.
  AnimateText,
  animateTextClasses,
  AnimateLogo1,
  AnimateLogo2,
  AnimateAvatar,
  AnimateBorder,
  AnimateCountUp,
  BackToTop,
  ScrollProgress,
  useScrollProgress,
  // Variant factories. Each returns framer `Variants` keyed by direction.
  varFade,
  varZoom,
  varFlip,
  varSlide,
  varScale,
  varBounce,
  varRotate,
  varPath,
  varHover,
  varContainer,
  varBgPan,
  varBgColor,
  varBgKenburns,
  // Library default timings (0.64s / 0.48s / 0.32s on [0.43, 0.13, 0.23, 0.96]).
  varTranEnter,
  varTranExit,
  varTranHover,
  TRANSITION,
  // Design tokens — a DIFFERENT, faster timing system. See transition.js.
  motionDurations,
  motionDurationsSec,
  motionEasings,
  motionStagger,
  motionStaggerDelay,
  motionTransition,
  motionCssTransition,
  motionTokenVariantProps,
  prefersReducedMotion,
} from 'src/components/animate';
