// Portable subset of the app's config-global.js.
// Only what UI code plausibly needs (branding, base path for assets).
// No hard dependency on import.meta.env or window: optional chaining keeps
// this safe under any bundler and during SSR/tests.

// ----------------------------------------------------------------------

export const CONFIG = {
  site: {
    name: 'VionHub',
    // Base path prefix for router links and static assets (e.g. '' or '/app').
    basePath: import.meta.env?.VITE_BASE_PATH ?? '',
    // Where static assets (images, fonts, illustrations) are served from.
    assetURL: import.meta.env?.VITE_ASSET_URL ?? '',
    version: '0.1.0',
  },
};
