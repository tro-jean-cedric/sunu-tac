// Generic hooks barrel.

export * from './use-boolean';
export * from './use-client-rect';
export * from './use-copy-to-clipboard';
export * from './use-countdown';
export * from './use-debounce';
export * from './use-double-click';
export * from './use-event-listener';
export * from './use-local-storage';
export * from './use-responsive';
export * from './use-scroll-offset-top';
export * from './use-scroll-to-top';
export * from './use-set-state';
export * from './use-tabs';
