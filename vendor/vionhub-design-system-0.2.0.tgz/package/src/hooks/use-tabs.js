import { useMemo, useState, useCallback } from 'react';

// ----------------------------------------------------------------------

/**
 * @template T
 * @typedef {object} UseTabsReturn
 * @property {T} value
 * @property {import('react').Dispatch<import('react').SetStateAction<T>>} setValue
 * @property {(event: import('react').SyntheticEvent, newValue: T) => void} onChange
 *   Ready to pass straight to a MUI `<Tabs onChange>`.
 */

/**
 * Controlled tab state matching the MUI `<Tabs>` API.
 *
 * @template T
 * @param {T} defaultValue Initially selected tab value.
 * @returns {UseTabsReturn<T>}
 */
export function useTabs(defaultValue) {
  const [value, setValue] = useState(defaultValue);

  const onChange = useCallback((event, newValue) => {
    setValue(newValue);
  }, []);

  const memoizedValue = useMemo(() => ({ value, setValue, onChange }), [onChange, value]);

  return memoizedValue;
}
