import { useMemo, useState, useCallback } from 'react';

// ----------------------------------------------------------------------

/**
 * @typedef {object} UseBooleanReturn
 * @property {boolean} value
 * @property {() => void} onTrue
 * @property {() => void} onFalse
 * @property {() => void} onToggle
 * @property {import('react').Dispatch<import('react').SetStateAction<boolean>>} setValue
 */

/**
 * Boolean state with memoized open/close/toggle handlers.
 *
 * @param {boolean} [defaultValue] Initial value. Defaults to `false`.
 * @returns {UseBooleanReturn}
 */
export function useBoolean(defaultValue = false) {
  const [value, setValue] = useState(defaultValue);

  const onTrue = useCallback(() => {
    setValue(true);
  }, []);

  const onFalse = useCallback(() => {
    setValue(false);
  }, []);

  const onToggle = useCallback(() => {
    setValue((prev) => !prev);
  }, []);

  const memoizedValue = useMemo(
    () => ({
      value,
      onTrue,
      onFalse,
      onToggle,
      setValue,
    }),
    [value, onTrue, onFalse, onToggle, setValue]
  );

  return memoizedValue;
}
