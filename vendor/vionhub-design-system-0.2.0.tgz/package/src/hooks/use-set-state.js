import { useMemo, useState, useCallback } from 'react';

import { isEqual } from 'src/utils/helper';

// ----------------------------------------------------------------------

/**
 * @template T
 * @typedef {object} UseSetStateReturn
 * @property {T} state
 * @property {(updateState: Partial<T>) => void} setState
 * @property {<K extends keyof T>(name: K, updateValue: T[K]) => void} setField
 * @property {() => void} onResetState
 * @property {boolean} canReset
 */

/**
 * Object state updated by shallow merge, with per-field setter and reset.
 *
 * @template T
 * @param {T} initialState Initial (and reset) value.
 * @returns {UseSetStateReturn<T>}
 */
export function useSetState(initialState) {
  const [state, set] = useState(initialState);

  const canReset = !isEqual(state, initialState);

  const setState = useCallback((updateState) => {
    set((prevValue) => ({ ...prevValue, ...updateState }));
  }, []);

  const setField = useCallback(
    (name, updateValue) => {
      setState({
        [name]: updateValue,
      });
    },
    [setState]
  );

  const onResetState = useCallback(() => {
    set(initialState);
  }, [initialState]);

  const memoizedValue = useMemo(
    () => ({
      state,
      setState,
      setField,
      onResetState,
      canReset,
    }),
    [canReset, onResetState, setField, setState, state]
  );

  return memoizedValue;
}
