import { useRef, useMemo, useCallback } from 'react';

// ----------------------------------------------------------------------

/**
 * @typedef {object} UseDoubleClickOptions
 * @property {(event: MouseEvent) => void} [click] Single-click handler, fired
 *   after `timeout` ms if no second click arrives.
 * @property {(event: MouseEvent) => void} doubleClick Double-click handler.
 * @property {number} [timeout] Delay before the single click fires, in
 *   milliseconds. Defaults to `250`.
 */

/**
 * Build a single click handler that distinguishes single from double clicks.
 *
 * @param {UseDoubleClickOptions} options
 * @returns {(event: MouseEvent) => void} Handler to attach to `onClick`.
 */
export function useDoubleClick({ click, doubleClick, timeout = 250 }) {
  const clickTimeout = useRef(/** @type {ReturnType<typeof setTimeout> | null} */ (null));

  const clearClickTimeout = useCallback(() => {
    if (clickTimeout.current) {
      clearTimeout(clickTimeout.current);
      clickTimeout.current = null;
    }
  }, []);

  const handleEvent = useCallback(
    (event) => {
      clearClickTimeout();
      if (click && event.detail === 1) {
        clickTimeout.current = setTimeout(() => {
          click(event);
        }, timeout);
      }
      if (event.detail % 2 === 0) {
        doubleClick(event);
      }
    },
    [click, doubleClick, timeout, clearClickTimeout]
  );

  const memoizedValue = useMemo(() => handleEvent, [handleEvent]);

  return memoizedValue;
}
