import { useRef, useEffect, useLayoutEffect } from 'react';

// ----------------------------------------------------------------------

const useIsomorphicLayoutEffect = typeof window !== 'undefined' ? useLayoutEffect : useEffect;

// ----------------------------------------------------------------------

/**
 * Attach an event listener to a ref'd element (or `window`) and keep the
 * handler identity stable across renders.
 *
 * @param {string} eventName Event name, e.g. `'resize'` or `'keydown'`.
 * @param {(event: Event) => void} handler Event handler.
 * @param {import('react').RefObject<EventTarget | null>} [element] Target
 *   element ref. Defaults to `window`.
 * @param {boolean | AddEventListenerOptions} [options] `addEventListener`
 *   options.
 * @returns {void}
 */
export function useEventListener(eventName, handler, element, options) {
  // Create a ref that stores handler
  const savedHandler = useRef(handler);

  useIsomorphicLayoutEffect(() => {
    savedHandler.current = handler;
  }, [handler]);

  useEffect(() => {
    // Define the listening target
    const targetElement = element?.current || window;
    if (!(targetElement && targetElement.addEventListener)) {
      return;
    }

    // Create event listener that calls handler function stored in ref
    const eventListener = (event) => savedHandler.current(event);

    targetElement.addEventListener(eventName, eventListener, options);

    // Remove event listener on cleanup
    // eslint-disable-next-line consistent-return
    return () => {
      targetElement.removeEventListener(eventName, eventListener);
    };
  }, [eventName, element, options]);
}
