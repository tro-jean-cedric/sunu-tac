import { useMemo, useState, useCallback } from 'react';

// ----------------------------------------------------------------------

/**
 * @typedef {object} UseCopyToClipboardReturn
 * @property {(text: string) => Promise<boolean>} copy
 * @property {string | null} copiedText
 */

/**
 * Copy text to the system clipboard and remember the last copied value.
 *
 * @returns {UseCopyToClipboardReturn}
 */
export function useCopyToClipboard() {
  const [copiedText, setCopiedText] = useState(/** @type {string | null} */ (null));

  const copy = useCallback(
    /**
     * @param {string} text
     * @returns {Promise<boolean>}
     */
    async (text) => {
      if (!navigator?.clipboard) {
        console.warn('Clipboard not supported');
        return false;
      }

      try {
        await navigator.clipboard.writeText(text);
        setCopiedText(text);
        return true;
      } catch (error) {
        console.warn('Copy failed', error);
        setCopiedText(null);
        return false;
      }
    },
    [setCopiedText]
  );

  const memoizedValue = useMemo(() => ({ copy, copiedText }), [copy, copiedText]);

  return memoizedValue;
}
