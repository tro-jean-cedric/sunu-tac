import { useState, useEffect } from 'react';

// ----------------------------------------------------------------------

/**
 * Debounce a value: the returned value only follows `value` after `delay` ms
 * without a change.
 *
 * @template T
 * @param {T} value Value to debounce.
 * @param {number} [delay] Delay in milliseconds. Defaults to `500`.
 * @returns {T}
 */
export function useDebounce(value, delay = 500) {
  const [debouncedValue, setDebouncedValue] = useState(value);

  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedValue(value);
    }, delay);

    return () => {
      clearTimeout(handler);
    };
  }, [value, delay]);

  return debouncedValue;
}
