import { useMemo } from 'react';

import { useTheme } from '@mui/material/styles';
import useMediaQuery from '@mui/material/useMediaQuery';

// ----------------------------------------------------------------------

/** @typedef {'up' | 'down' | 'between' | 'only'} UseResponsiveQuery */

/** @typedef {import('@mui/material/styles').Breakpoint} UseResponsiveBreakpoint */

/**
 * Match a theme breakpoint query.
 *
 * @param {UseResponsiveQuery} query Comparison to run against the theme
 *   breakpoints.
 * @param {UseResponsiveBreakpoint | number} start Breakpoint (or px value) the
 *   query starts at.
 * @param {UseResponsiveBreakpoint | number} [end] Upper breakpoint, only used
 *   by `'between'`.
 * @returns {boolean}
 */
export function useResponsive(query, start, end) {
  const theme = useTheme();

  const getQuery = useMemo(() => {
    switch (query) {
      case 'up':
        return theme.breakpoints.up(start);
      case 'down':
        return theme.breakpoints.down(start);
      case 'between':
        return theme.breakpoints.between(start, end);
      case 'only':
        return theme.breakpoints.only(start);
      default:
        return theme.breakpoints.up('xs');
    }
  }, [theme, query, start, end]);

  const mediaQueryResult = useMediaQuery(getQuery);

  return mediaQueryResult;
}

// ----------------------------------------------------------------------

/**
 * Current breakpoint key, largest matching first.
 *
 * @returns {UseResponsiveBreakpoint}
 */
export function useWidth() {
  const theme = useTheme();

  const keys = useMemo(() => [...theme.breakpoints.keys].reverse(), [theme]);

  const width = keys.reduce((output, key) => {
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const matches = useMediaQuery(theme.breakpoints.up(key));

    return !output && matches ? key : output;
  }, null);

  return width || 'xs';
}
