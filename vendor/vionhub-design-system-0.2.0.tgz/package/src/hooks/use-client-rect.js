import { useRef, useMemo, useState, useEffect, useCallback, useLayoutEffect } from 'react';

import { useEventListener } from './use-event-listener';

// ----------------------------------------------------------------------

/**
 * @typedef {object} UseClientRectReturn
 * @property {import('react').MutableRefObject<HTMLElement | null>} elementRef
 * @property {number} top
 * @property {number} right
 * @property {number} bottom
 * @property {number} left
 * @property {number} x
 * @property {number} y
 * @property {number} width
 * @property {number} height
 * @property {number} scrollWidth
 * @property {number} scrollHeight
 */

/**
 * Measure an element's bounding client rect and scroll size, kept in sync on
 * window resize.
 *
 * @param {import('react').MutableRefObject<HTMLElement | null>} [inputRef]
 *   Existing ref to observe. When omitted an internal ref is created and
 *   returned as `elementRef`.
 * @returns {UseClientRectReturn}
 */
export function useClientRect(inputRef) {
  const initialRef = useRef(/** @type {HTMLElement | null} */ (null));

  const elementRef = inputRef || initialRef;

  const [rect, setRect] = useState(/** @type {DOMRect | undefined} */ (undefined));

  const [scroll, setScroll] = useState(
    /** @type {{ scrollWidth: number, scrollHeight: number } | undefined} */ (undefined)
  );

  const useIsomorphicLayoutEffect = typeof window !== 'undefined' ? useLayoutEffect : useEffect;

  const handleResize = useCallback(() => {
    if (elementRef?.current) {
      const clientRect = elementRef.current.getBoundingClientRect();

      setRect(clientRect);

      setScroll({
        scrollWidth: elementRef.current?.scrollWidth,
        scrollHeight: elementRef.current?.scrollHeight,
      });
    }
  }, [elementRef]);

  useEventListener('resize', handleResize);

  useIsomorphicLayoutEffect(() => {
    handleResize();
  }, []);

  const memoizedRectValue = useMemo(() => rect, [rect]);
  const memoizedScrollValue = useMemo(() => scroll, [scroll]);

  return {
    elementRef,
    //
    top: memoizedRectValue?.top ?? 0,
    right: memoizedRectValue?.right ?? 0,
    bottom: memoizedRectValue?.bottom ?? 0,
    left: memoizedRectValue?.left ?? 0,
    x: memoizedRectValue?.x ?? 0,
    y: memoizedRectValue?.y ?? 0,
    width: memoizedRectValue?.width ?? 0,
    height: memoizedRectValue?.height ?? 0,
    //
    scrollWidth: memoizedScrollValue?.scrollWidth ?? 0,
    scrollHeight: memoizedScrollValue?.scrollHeight ?? 0,
  };
}
