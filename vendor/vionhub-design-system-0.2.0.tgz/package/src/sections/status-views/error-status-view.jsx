import { m } from 'framer-motion';

import Button from '@mui/material/Button';
import Container from '@mui/material/Container';
import Typography from '@mui/material/Typography';

import { RouterLink } from 'src/routes/components';

import { SimpleLayout } from 'src/layouts/simple';

import { varBounce, MotionContainer } from 'src/components/animate';

// ----------------------------------------------------------------------
// Parametric status page — the v2 app shipped three near-identical files
// (403 / 404 / 500) that only differed by copy and illustration. This is
// the shared skeleton; `View403`, `NotFoundView` and `View500` (see
// ./error-presets.jsx) are thin wrappers around it.
//
// Props:
//   title         — h3 heading, animated with varBounce-in.
//   description   — ReactNode rendered below the title in text.secondary.
//   illustration  — ReactNode (typically one of the DS illustrations with
//                   sx={{ my: { xs: 5, sm: 10 } }}); omitted when absent.
//   action        — { label, href }: renders a contained RouterLink button.
//   actionButton  — ReactNode replacing the default button entirely (custom
//                   onClick, several buttons…). Wins over `action`.
//   withLayout    — default true: wraps the content in the DS SimpleLayout
//                   (compact centered column, logo header). Pass false to
//                   embed the content inside an existing layout — e.g. a 403
//                   rendered within the dashboard shell.

export function ErrorStatusView({
  title,
  description,
  illustration,
  action,
  actionButton,
  withLayout = true,
}) {
  const content = (
    <Container component={MotionContainer}>
      <m.div variants={varBounce().in}>
        <Typography variant="h3" sx={{ mb: 2 }}>
          {title}
        </Typography>
      </m.div>

      {description && (
        <m.div variants={varBounce().in}>
          <Typography sx={{ color: 'text.secondary' }}>{description}</Typography>
        </m.div>
      )}

      {illustration && <m.div variants={varBounce().in}>{illustration}</m.div>}

      {actionButton ??
        (action && (
          <Button component={RouterLink} href={action.href} size="large" variant="contained">
            {action.label}
          </Button>
        ))}
    </Container>
  );

  if (!withLayout) {
    return content;
  }

  return <SimpleLayout content={{ compact: true }}>{content}</SimpleLayout>;
}
