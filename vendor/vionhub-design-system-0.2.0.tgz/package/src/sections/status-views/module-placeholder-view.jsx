import Box from '@mui/material/Box';
import Card from '@mui/material/Card';
import Stack from '@mui/material/Stack';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';

import { DashboardContent } from 'src/layouts/dashboard';

import { Iconify } from 'src/components/iconify';
import { CustomBreadcrumbs } from 'src/components/custom-breadcrumbs';

// ----------------------------------------------------------------------
// Placeholder page for a dashboard module that is not (yet) available —
// the v2 app used it while migrating module-by-module; equally useful for
// gating unreleased features. DashboardContent + CustomBreadcrumbs header,
// then a Card with a centered duotone icon, heading, constrained-width
// description, refresh button and an optional dashed neutral block.
//
// Props:
//   title                — CustomBreadcrumbs heading (page title).
//   breadcrumbs          — [{ name, href? }] passed to CustomBreadcrumbs links.
//   action               — ReactNode rendered on the right of the breadcrumbs
//                          (e.g. a disabled "Nouveau" button).
//   icon                 — Iconify name for the large centered glyph.
//                          Default 'solar:hourglass-line-duotone'.
//   heading              — h5 under the icon. Default 'Module en cours de
//                          migration'.
//   description          — body2 text, max-width 480, centered. Default
//                          explains the section arrives once migrated.
//   onRefresh            — click handler of the refresh button. Default
//                          reloads the page.
//   refreshLabel         — refresh button label. Default 'Rafraîchir'.
//   showPlaceholderBlock — default true: renders the dashed neutral block
//                          under the message (skeleton of the future content).
//   children             — replaces the dashed block when provided (preview,
//                          mockup, partial content…).

export function ModulePlaceholderView({
  title,
  breadcrumbs = [],
  action,
  icon = 'solar:hourglass-line-duotone',
  heading = 'Module en cours de migration',
  description,
  onRefresh = () => window.location.reload(),
  refreshLabel = 'Rafraîchir',
  showPlaceholderBlock = true,
  children,
}) {
  return (
    <DashboardContent maxWidth="xl">
      <CustomBreadcrumbs
        heading={title}
        links={breadcrumbs}
        action={action}
        sx={{ mb: { xs: 3, md: 5 } }}
      />

      <Card sx={{ p: { xs: 3, md: 5 } }}>
        <Stack spacing={2} alignItems="center" sx={{ py: 6 }}>
          <Iconify icon={icon} width={64} sx={{ color: 'text.disabled' }} />
          <Typography variant="h5">{heading}</Typography>
          <Typography
            variant="body2"
            color="text.secondary"
            sx={{ maxWidth: 480, textAlign: 'center' }}
          >
            {description ??
              'Cette section sera disponible une fois la migration de ce module terminée.'}
          </Typography>
          <Button
            variant="outlined"
            startIcon={<Iconify icon="solar:refresh-bold" />}
            onClick={onRefresh}
          >
            {refreshLabel}
          </Button>
        </Stack>

        {children ??
          (showPlaceholderBlock && (
            <Box
              sx={{
                mt: 3,
                height: 240,
                borderRadius: 2,
                bgcolor: (theme) => theme.vars.palette.background.neutral,
                border: (theme) => `dashed 1px ${theme.vars.palette.divider}`,
              }}
            />
          ))}
      </Card>
    </DashboardContent>
  );
}
