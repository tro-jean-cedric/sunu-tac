import {
  ForbiddenIllustration,
  ServerErrorIllustration,
  PageNotFoundIllustration,
} from 'src/assets/illustrations';

import { ErrorStatusView } from './error-status-view';

// ----------------------------------------------------------------------
// Preset status pages — thin wrappers around ErrorStatusView wired to the
// DS illustrations, with French default copy (the original app shipped the
// English Minimals template copy untouched). Every prop (title, description,
// illustration, action, actionButton, withLayout) can be overridden; extra
// props pass through to ErrorStatusView.

const DEFAULT_ACTION = { label: 'Retour à l’accueil', href: '/' };

const ILLUSTRATION_SX = { my: { xs: 5, sm: 10 } };

export function View403({
  title = 'Accès refusé',
  description = 'L’accès à cette page est restreint. Veuillez contacter votre administrateur système.',
  illustration = <ForbiddenIllustration sx={ILLUSTRATION_SX} />,
  action = DEFAULT_ACTION,
  ...other
}) {
  return (
    <ErrorStatusView
      title={title}
      description={description}
      illustration={illustration}
      action={action}
      {...other}
    />
  );
}

export function NotFoundView({
  title = 'Page introuvable',
  description = 'Désolé, nous n’avons pas trouvé la page que vous cherchez. Peut-être une erreur dans l’URL ? Vérifiez votre saisie.',
  illustration = <PageNotFoundIllustration sx={ILLUSTRATION_SX} />,
  action = DEFAULT_ACTION,
  ...other
}) {
  return (
    <ErrorStatusView
      title={title}
      description={description}
      illustration={illustration}
      action={action}
      {...other}
    />
  );
}

export function View500({
  title = 'Erreur interne du serveur',
  description = 'Une erreur est survenue, veuillez réessayer plus tard.',
  illustration = <ServerErrorIllustration sx={ILLUSTRATION_SX} />,
  action = DEFAULT_ACTION,
  ...other
}) {
  return (
    <ErrorStatusView
      title={title}
      description={description}
      illustration={illustration}
      action={action}
      {...other}
    />
  );
}
