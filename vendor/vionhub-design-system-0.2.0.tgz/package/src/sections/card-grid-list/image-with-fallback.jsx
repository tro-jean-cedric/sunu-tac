import { useState, useEffect } from 'react';

import { Box } from '@mui/material';

import { Iconify } from 'src/components/iconify';

// ----------------------------------------------------------------------
// Aspect-ratio image frame with a graceful icon fallback — the media block
// used by every card/drawer image in the v2 app. Neutral background, the
// image covers the frame; when there is no `src` or the URL fails to load
// (broken/expired asset link) a centered disabled-color Iconify placeholder
// takes its place. The error state resets whenever `src` changes so a fresh
// URL gets a fresh chance to render.
//
// Props:
//   src               — image URL. Falsy renders the placeholder directly.
//   alt               — img alt text.
//   ratio             — CSS aspect-ratio of the frame (default '1/1').
//   fallbackIcon      — Iconify name of the placeholder (default
//                       'solar:gallery-bold').
//   fallbackIconWidth — placeholder icon size (default 64).
//   borderRadius      — frame border radius (default 2; pass 0 when the
//                       parent card already clips its corners).
//   children          — optional overlay content rendered above the image
//                       (the frame is position: relative).
//   sx                — extra styles for the frame.
// ----------------------------------------------------------------------

export function ImageWithFallback({
  src,
  alt,
  ratio = '1/1',
  fallbackIcon = 'solar:gallery-bold',
  fallbackIconWidth = 64,
  borderRadius = 2,
  children,
  sx,
  ...other
}) {
  const [imgError, setImgError] = useState(false);

  // Reset on each new URL so a replaced image gets a fresh chance to render.
  useEffect(() => {
    setImgError(false);
  }, [src]);

  return (
    <Box
      sx={{
        position: 'relative',
        aspectRatio: ratio,
        borderRadius,
        bgcolor: 'background.neutral',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        overflow: 'hidden',
        ...sx,
      }}
      {...other}
    >
      {src && !imgError ? (
        <Box
          component="img"
          src={src}
          alt={alt}
          loading="lazy"
          onError={() => setImgError(true)}
          sx={{ width: '100%', height: '100%', objectFit: 'cover' }}
        />
      ) : (
        <Iconify icon={fallbackIcon} width={fallbackIconWidth} sx={{ color: 'text.disabled' }} />
      )}

      {children}
    </Box>
  );
}
