import { useState, useEffect } from 'react';

import {
  Box,
  Card,
  Stack,
  Button,
  TextField,
  Pagination,
  Typography,
  InputAdornment,
  CircularProgress,
} from '@mui/material';

import { useDebounce } from 'src/hooks/use-debounce';

import { DashboardContent } from 'src/layouts/dashboard';

import { Iconify } from 'src/components/iconify';
import { EmptyContent } from 'src/components/empty-content';
import { CustomBreadcrumbs } from 'src/components/custom-breadcrumbs';

// ----------------------------------------------------------------------
// The v2 card-grid alternative to the table list page (the "Articles"
// screen): breadcrumbs + toolbar Card with a debounced search field and a
// primary action button + responsive CSS-grid of cards + centered rounded
// pagination + right-aligned total caption. Fully controlled — the caller
// owns the data (pairs naturally with usePaginatedList, but plain props keep
// it independent of any fetching strategy).
//
// Props:
//   heading           — page heading. When given, the page is wrapped in
//                       DashboardContent + CustomBreadcrumbs; when omitted
//                       only the grid block renders (embed anywhere).
//   breadcrumbs       — [{ name, href? }] passed to CustomBreadcrumbs links.
//   items             — current page of items.
//   renderItem        — (item) => node; typically an <ImageItemCard />.
//                       Each item needs a stable `id` (used as the grid key).
//   loading           — data loading flag; while true the empty state is
//                       withheld so the grid doesn't flash "no results".
//   total             — total item count across all pages.
//   page / pageSize   — 1-based current page and page size.
//   onPageChange      — (page) => void.
//   search            — current applied search value (controlled).
//   onSearchChange    — (value) => void, fired after the debounce delay.
//   searchLoading     — shows an inline spinner in the search field.
//   searchPlaceholder — search field placeholder (default 'Rechercher…').
//   searchDebounceMs  — debounce delay in ms (default 600, as in the app).
//   actionButton      — { label, icon?, onClick } primary toolbar button
//                       (default icon 'mingcute:add-line').
//   emptyTitle        — EmptyContent title (default 'Aucun résultat').
//   gridColumns       — columns per breakpoint (default
//                       { xs: 2, sm: 3, md: 4, lg: 5, xl: 6 }).
//   totalLabel        — (n) => string caption under the grid (default
//                       `${n} élément(s)`).
//   children          — rendered after the page content: dialogs, drawers…
// ----------------------------------------------------------------------

export function CardGridListPage({
  heading,
  breadcrumbs = [],
  items = [],
  renderItem,
  loading = false,
  total = 0,
  page = 1,
  pageSize = 24,
  onPageChange,
  search = '',
  onSearchChange,
  searchLoading = false,
  searchPlaceholder = 'Rechercher…',
  searchDebounceMs = 600,
  actionButton,
  emptyTitle = 'Aucun résultat',
  gridColumns = { xs: 2, sm: 3, md: 4, lg: 5, xl: 6 },
  totalLabel = (n) => `${n} élément${n > 1 ? 's' : ''}`,
  children,
}) {
  // Debounce so each keystroke doesn't refetch: the input is local state,
  // the debounced value is pushed to the caller via onSearchChange.
  const [searchInput, setSearchInput] = useState(search);
  const debouncedSearch = useDebounce(searchInput, searchDebounceMs);

  useEffect(() => {
    if (debouncedSearch !== search) onSearchChange?.(debouncedSearch);
    // Only react to the debounced value — `search` here would re-fire loops.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [debouncedSearch]);

  // Keep the input in sync when the caller changes `search` externally
  // (e.g. a "clear filters" button). The guard lets the normal
  // type → debounce → parent-echo cycle through without resetting typing.
  useEffect(() => {
    if (search !== debouncedSearch) setSearchInput(search);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [search]);

  const totalPages = Math.max(1, Math.ceil(total / pageSize));

  const gridTemplateColumns = Object.fromEntries(
    Object.entries(gridColumns).map(([breakpoint, count]) => [breakpoint, `repeat(${count}, 1fr)`])
  );

  const showToolbar = !!onSearchChange || !!actionButton;

  const content = (
    <>
      {showToolbar && (
        <Card sx={{ p: 2.5, mb: 3 }}>
          <Stack
            direction={{ xs: 'column', sm: 'row' }}
            spacing={2}
            alignItems={{ xs: 'stretch', sm: 'center' }}
          >
            {!!onSearchChange && (
              <TextField
                value={searchInput}
                onChange={(e) => setSearchInput(e.target.value)}
                placeholder={searchPlaceholder}
                sx={{ width: { xs: 1, sm: 260 } }}
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <Iconify icon="eva:search-fill" sx={{ color: 'text.disabled' }} />
                    </InputAdornment>
                  ),
                  endAdornment: searchLoading ? (
                    <InputAdornment position="end">
                      <CircularProgress size={16} />
                    </InputAdornment>
                  ) : null,
                }}
              />
            )}
            {!!actionButton && (
              <Button
                variant="contained"
                startIcon={<Iconify icon={actionButton.icon ?? 'mingcute:add-line'} />}
                onClick={actionButton.onClick}
                sx={{
                  ml: { sm: 'auto' },
                  bgcolor: 'primary.main',
                  color: '#ffffff',
                  boxShadow: 'none',
                  borderRadius: '20px',
                  padding: '12px 17px',
                  '&:hover': {
                    bgcolor: '#000000',
                    color: '#ffffff',
                    boxShadow: 'none',
                  },
                }}
              >
                {actionButton.label}
              </Button>
            )}
          </Stack>
        </Card>
      )}

      {!loading && items.length === 0 ? (
        <EmptyContent title={emptyTitle} sx={{ py: 10 }} />
      ) : (
        <>
          <Box
            sx={{
              display: 'grid',
              gap: { xs: 1.5, md: 2 },
              gridTemplateColumns,
            }}
          >
            {items.map((item, index) => (
              <Box key={item?.id ?? index} sx={{ minWidth: 0 }}>
                {renderItem(item)}
              </Box>
            ))}
          </Box>

          {totalPages > 1 && (
            <Stack direction="row" justifyContent="center" sx={{ mt: 4 }}>
              <Pagination
                count={totalPages}
                page={page}
                onChange={(_, p) => onPageChange?.(p)}
                color="primary"
                shape="rounded"
              />
            </Stack>
          )}

          <Typography
            variant="caption"
            color="text.secondary"
            sx={{ display: 'block', mt: 2, textAlign: 'right' }}
          >
            {totalLabel(total)}
          </Typography>
        </>
      )}
    </>
  );

  if (!heading) {
    return (
      <>
        {content}
        {children}
      </>
    );
  }

  return (
    <>
      <DashboardContent maxWidth="xl">
        <CustomBreadcrumbs heading={heading} links={breadcrumbs} sx={{ mb: { xs: 3, md: 5 } }} />
        {content}
      </DashboardContent>

      {children}
    </>
  );
}
