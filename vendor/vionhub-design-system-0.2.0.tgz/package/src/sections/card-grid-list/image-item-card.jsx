import { Card, Stack, Tooltip, Typography, IconButton } from '@mui/material';

import { Iconify } from 'src/components/iconify';

import { ImageWithFallback } from './image-with-fallback';

// ----------------------------------------------------------------------
// Clickable media tile — mirrors the Minimal template's product list look.
// The image fills a 1:1 frame (with icon fallback), then a clean info block
// with a 2-line-clamped title, a secondary caption and a highlighted meta
// line (e.g. a price, pre-formatted by the caller). The whole card lifts on
// hover; a floating action icon row sits top-right of the image.
//
// Props:
//   imageUrl        — resolved image URL (falsy shows the placeholder icon).
//   title           — main label, clamped to 2 lines.
//   subtitle        — optional secondary caption (e.g. category name).
//   meta            — optional highlighted line (e.g. '12 500 F CFA').
//   placeholderIcon — Iconify name used when the image is missing/broken
//                     (default 'solar:gallery-bold').
//   onClick         — fired when the card (or its title) is clicked.
//   actions         — floating buttons: [{ icon, title, color?, onClick }].
//                     Clicks stop propagation so the card onClick stays quiet.
//   sx              — extra styles for the Card.
// ----------------------------------------------------------------------

export function ImageItemCard({
  imageUrl,
  title,
  subtitle,
  meta,
  placeholderIcon = 'solar:gallery-bold',
  onClick,
  actions = [],
  sx,
}) {
  return (
    <Card
      onClick={() => onClick?.()}
      sx={{
        position: 'relative',
        borderRadius: 2,
        overflow: 'hidden',
        cursor: onClick ? 'pointer' : 'default',
        transition: 'transform 0.15s ease, box-shadow 0.15s ease',
        '&:hover': { transform: 'translateY(-2px)', boxShadow: 6 },
        ...sx,
      }}
    >
      <ImageWithFallback
        src={imageUrl}
        alt={title}
        borderRadius={0}
        fallbackIcon={placeholderIcon}
        fallbackIconWidth={56}
      >
        {/* Floating action row — top-right of the image */}
        {actions.length > 0 && (
          <Stack
            direction="row"
            spacing={0.5}
            sx={{
              position: 'absolute',
              top: 8,
              right: 8,
              bgcolor: 'background.paper',
              borderRadius: 1,
              boxShadow: 2,
            }}
          >
            {actions.map((action) => (
              <Tooltip key={action.title} title={action.title}>
                <IconButton
                  size="small"
                  color={action.color}
                  onClick={(e) => {
                    e.stopPropagation();
                    action.onClick?.(e);
                  }}
                >
                  <Iconify icon={action.icon} width={18} />
                </IconButton>
              </Tooltip>
            ))}
          </Stack>
        )}
      </ImageWithFallback>

      <Stack spacing={0.25} sx={{ p: 1.25 }}>
        <Typography
          variant="subtitle2"
          component="button"
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            onClick?.();
          }}
          sx={{
            color: 'text.primary',
            textAlign: 'left',
            textDecoration: 'none',
            background: 'none',
            border: 'none',
            cursor: onClick ? 'pointer' : 'default',
            p: 0,
            font: 'inherit',
            fontSize: 13,
            lineHeight: 1.35,
            display: '-webkit-box',
            WebkitLineClamp: 2,
            WebkitBoxOrient: 'vertical',
            overflow: 'hidden',
            '&:hover': { color: onClick ? 'primary.main' : 'text.primary' },
          }}
        >
          {title}
        </Typography>

        {!!subtitle && (
          <Typography variant="caption" color="text.secondary" noWrap>
            {subtitle}
          </Typography>
        )}

        {!!meta && (
          <Typography variant="subtitle2" sx={{ color: 'primary.main', fontWeight: 700, mt: 0.25 }}>
            {meta}
          </Typography>
        )}
      </Stack>
    </Card>
  );
}
