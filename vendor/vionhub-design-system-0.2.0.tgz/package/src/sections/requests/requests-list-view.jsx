import dayjs from 'dayjs';
import { useMemo, useState, useEffect } from 'react';

import { Box, Stack, Avatar, Button, Typography } from '@mui/material';

import { DashboardContent } from 'src/layouts/dashboard';

import { Label } from 'src/components/label';
import { Iconify } from 'src/components/iconify';
import { CustomBreadcrumbs } from 'src/components/custom-breadcrumbs';
import { ActionsCell, AsyncDataGrid } from 'src/components/async-data-grid';

import { RequestsTabs } from './requests-tabs';
import { StatusFilter } from './status-filter';
import { parseVionhubDate, formatVionhubDate } from './date-utils';

// ----------------------------------------------------------------------

// Default status → Label color heuristic, based on the v2 status naming
// conventions. Override with the `statusColor` prop for custom vocabularies.
export function defaultRequestStatusColor(status) {
  if (!status) return 'default';
  if (
    status.endsWith('_APPROVED') ||
    status === 'PURCHASED' ||
    status === 'DELIVERED' ||
    status === 'COMPLETED'
  )
    return 'success';
  if (status.endsWith('_REJECTED') || status === 'DELIVERY_FAILED' || status === 'PURCHASE_DELETED')
    return 'error';
  if (
    status === 'PENDING' ||
    status.startsWith('SENT_BACK_TO_') ||
    status === 'SH_REJECT_REQ_INFO' ||
    status === 'NEED_PURCHASE_ORDER_DEFINED'
  )
    return 'warning';
  if (status === 'DRAFT') return 'default';
  return 'info';
}

// Visual palette for batch grouping. Each batchCode visible on the current page
// gets a stable color from this list (in iteration order). The left-border
// accent reuses the same index so the eye links siblings together.
const BATCH_PALETTE = ['primary', 'warning', 'info', 'success', 'secondary', 'error'];

// The v2 "Détails" pill button — yellow, flips to black on hover.
const DETAILS_BUTTON_SX = {
  px: 2,
  py: 0.75,
  flexShrink: 0,
  borderRadius: '999px',
  fontWeight: 700,
  textTransform: 'none',
  bgcolor: '#f5c928',
  color: 'common.black',
  boxShadow: '0 4px 10px rgba(0,0,0,0.18)',
  transition: 'background-color 0.2s ease, transform 0.15s ease',
  '&:hover': {
    bgcolor: 'common.black',
    color: 'common.white',
    transform: 'translateY(-1px)',
    boxShadow: '0 6px 14px rgba(0,0,0,0.22)',
  },
};

// ----------------------------------------------------------------------
// The v2 requests list page, data-agnostic. Rows: { id, code, object,
// type, status, createdAt, owner: { name }, batchCode? }. Server-side
// pagination/search is the consumer's job — this view renders the design:
// breadcrumbs header, pill scope tabs, status filter, the data grid with
// status chips and the yellow "Détails" action, and batch-grouping accents.

export function RequestsListView({
  heading = "Demandes d'achat",
  breadcrumbLinks = [{ name: 'Tableau de bord', href: '/dashboard' }, { name: 'Demandes' }],
  // grid data (server-controlled)
  rows,
  total,
  page,
  pageSize,
  search,
  loading,
  onPageChange,
  onPageSizeChange,
  onSearchChange,
  // scope tabs
  tabs = [],
  activeTab,
  tabCounts,
  onTabChange,
  // status filter
  statusOptions,
  statusFilter,
  onStatusFilterChange,
  // presentation
  statusLabels = {},
  statusColor = defaultRequestStatusColor,
  typeLabels = {},
  showOwner = true,
  showAge = false,
  // interactions
  onDetails,
  onCreate,
  createLabel = 'Ajouter une demande',
  renderRowActions,
  toolbar,
  columns: columnsProp,
  // selection passthrough (e.g. multi-select flows)
  checkboxSelection = false,
  rowSelectionModel,
  onRowSelectionModelChange,
  sx,
}) {
  // Batch grouping: requests may carry a `batchCode` (assigned when several
  // requests are submitted together). Siblings on the current page get a
  // color-accented left border; clicking is delegated to the focus bar.
  const [focusedBatch, setFocusedBatch] = useState(null);

  useEffect(() => {
    setFocusedBatch(null);
  }, [activeTab, statusFilter, page]);

  const batchMembers = useMemo(() => {
    const map = new Map();
    (rows ?? []).forEach((r) => {
      if (!r?.batchCode) return;
      const list = map.get(r.batchCode);
      if (list) list.push(r);
      else map.set(r.batchCode, [r]);
    });
    // Only treat a batchCode as a "batch" when 2+ siblings are visible.
    Array.from(map.entries()).forEach(([code, list]) => {
      if (list.length < 2) map.delete(code);
    });
    return map;
  }, [rows]);

  const batchColor = useMemo(() => {
    const idx = new Map();
    let i = 0;
    Array.from(batchMembers.keys()).forEach((code) => {
      idx.set(code, BATCH_PALETTE[i % BATCH_PALETTE.length]);
      i += 1;
    });
    return idx;
  }, [batchMembers]);

  const visibleRows = useMemo(() => {
    if (!focusedBatch) return rows;
    return (rows ?? []).filter((r) => r.batchCode === focusedBatch);
  }, [rows, focusedBatch]);

  useEffect(() => {
    if (focusedBatch && !batchMembers.has(focusedBatch)) {
      setFocusedBatch(null);
    }
  }, [focusedBatch, batchMembers]);

  const columns = useMemo(() => {
    if (columnsProp) return columnsProp;

    const base = [
      {
        field: 'code',
        headerName: 'Code',
        width: 160,
        renderCell: (p) => (
          <Typography variant="body2" noWrap>{p.row?.code ?? '—'}</Typography>
        ),
      },
      {
        field: 'owner',
        headerName: 'Demandeur',
        flex: 1,
        renderCell: (p) => (
          <Stack direction="row" spacing={1} alignItems="center">
            <Avatar sx={{ width: 28, height: 28, fontSize: 12 }}>
              {p.row?.owner?.name?.[0]?.toUpperCase()}
            </Avatar>
            <Typography variant="body2" noWrap>{p.row?.owner?.name ?? '—'}</Typography>
          </Stack>
        ),
      },
      {
        field: 'type',
        headerName: 'Type',
        width: 130,
        renderCell: (p) => (
          <Label
            color={p.row.type === 'organisation' ? 'info' : 'default'}
            variant="soft"
            sx={{ textTransform: 'none' }}
          >
            {typeLabels[p.row.type] ?? p.row.type ?? '—'}
          </Label>
        ),
      },
      { field: 'object', headerName: 'Objet', flex: 2 },
      {
        field: 'createdAt',
        headerName: 'Créée le',
        width: 130,
        valueFormatter: (v) => formatVionhubDate(v),
      },
      {
        field: 'status',
        headerName: 'Statut',
        width: 220,
        renderCell: (p) => (
          <Label color={statusColor(p.row.status)} variant="soft" sx={{ textTransform: 'none' }}>
            {statusLabels[p.row.status] ?? p.row.status}
          </Label>
        ),
      },
    ];

    if (!showOwner) {
      const ownerIdx = base.findIndex((c) => c.field === 'owner');
      if (ownerIdx >= 0) base.splice(ownerIdx, 1);
    }

    // Aging column for validator queues: green under 3 days, then warning/error.
    if (showAge) {
      base.splice(base.length - 1, 0, {
        field: '__age',
        headerName: 'Durée',
        width: 110,
        renderCell: (p) => {
          const created = parseVionhubDate(p.row.createdAt);
          const days = created ? dayjs().diff(created, 'day') : null;
          if (days == null) return '—';
          const color = days > 7 ? 'error' : days > 3 ? 'warning' : 'default';
          return <Label color={color} variant="soft">{`${days}j`}</Label>;
        },
      });
    }

    base.push({
      field: '__actions',
      headerName: ' ',
      width: 200,
      sortable: false,
      renderCell: (p) => (
        <ActionsCell sx={{ gap: 1 }}>
          <Button
            size="small"
            variant="contained"
            disableElevation
            onClick={() => onDetails?.(p.row)}
            startIcon={<Iconify icon="solar:eye-bold" width={18} />}
            sx={DETAILS_BUTTON_SX}
          >
            Détails
          </Button>
          {renderRowActions?.(p.row)}
        </ActionsCell>
      ),
    });

    return base;
  }, [columnsProp, statusLabels, statusColor, typeLabels, showOwner, showAge, onDetails, renderRowActions]);

  return (
    <DashboardContent maxWidth="xl">
      <CustomBreadcrumbs
        heading={heading}
        links={breadcrumbLinks}
        sx={{ mb: { xs: 3, md: 5 } }}
      />

      <AsyncDataGrid
        columns={columns}
        rows={visibleRows}
        // When a batch is focused, show the local sibling count in the footer.
        // Pagination stays server-controlled — the focus is a visual narrow on
        // the current page, not a server filter.
        total={focusedBatch ? (visibleRows?.length ?? 0) : total}
        page={page}
        pageSize={pageSize}
        search={search}
        loading={loading}
        onPageChange={onPageChange}
        onPageSizeChange={onPageSizeChange}
        onSearchChange={onSearchChange}
        onRowClick={(p) => {
          const row = (visibleRows ?? []).find((r) => String(r.id) === String(p.id));
          if (row) onDetails?.(row);
        }}
        getRowClassName={(p) =>
          p.row?.batchCode && batchMembers.has(p.row.batchCode)
            ? `batch-row batch-row--${batchColor.get(p.row.batchCode)}${
                focusedBatch === p.row.batchCode ? ' batch-row--focused' : ''
              }`
            : ''
        }
        sx={{
          '& .MuiDataGrid-row': { cursor: 'pointer' },
          '& .batch-row': {
            borderLeft: '3px solid',
            borderLeftColor: 'divider',
          },
          '& .batch-row--primary': { borderLeftColor: 'primary.main' },
          '& .batch-row--warning': { borderLeftColor: 'warning.main' },
          '& .batch-row--info': { borderLeftColor: 'info.main' },
          '& .batch-row--success': { borderLeftColor: 'success.main' },
          '& .batch-row--secondary': { borderLeftColor: 'secondary.main' },
          '& .batch-row--error': { borderLeftColor: 'error.main' },
          '& .batch-row--focused': {
            backgroundColor: (theme) => theme.palette.action.hover,
          },
          ...sx,
        }}
        topSlot={
          tabs.length > 0 ? (
            <RequestsTabs tabs={tabs} active={activeTab} counts={tabCounts} onChange={onTabChange} />
          ) : null
        }
        toolbarLeft={
          statusOptions?.length ? (
            <StatusFilter
              value={statusFilter}
              options={statusOptions}
              onChange={onStatusFilterChange}
            />
          ) : null
        }
        belowToolbar={
          focusedBatch ? (
            <Box sx={{ px: 2.5, pb: 1 }}>
              <Stack
                direction="row"
                alignItems="center"
                spacing={1}
                sx={(theme) => ({
                  px: 1.5,
                  py: 1,
                  borderRadius: 1,
                  bgcolor: theme.palette.action.hover,
                  border: `1px solid ${theme.palette.divider}`,
                })}
              >
                <Iconify icon="solar:layers-bold-duotone" width={18} />
                <Typography variant="body2" sx={{ fontWeight: 600 }}>
                  {`Lot ${focusedBatch}`}
                </Typography>
                <Typography variant="caption" color="text.secondary">
                  {`${visibleRows?.length ?? 0} demandes sur cette page · chaque demande reste gérable individuellement`}
                </Typography>
                <Box sx={{ flexGrow: 1 }} />
                <Button
                  size="small"
                  variant="text"
                  color="inherit"
                  startIcon={<Iconify icon="eva:close-fill" width={16} />}
                  onClick={() => setFocusedBatch(null)}
                >
                  Annuler le focus
                </Button>
              </Stack>
            </Box>
          ) : null
        }
        toolbar={
          <>
            {toolbar}
            {onCreate && (
              <Button
                variant="contained"
                color="primary"
                startIcon={<Iconify icon="mingcute:add-line" />}
                onClick={onCreate}
              >
                {createLabel}
              </Button>
            )}
          </>
        }
        checkboxSelection={checkboxSelection}
        rowSelectionModel={rowSelectionModel}
        onRowSelectionModelChange={onRowSelectionModelChange}
        keepNonExistentRowsSelected
      />
    </DashboardContent>
  );
}
