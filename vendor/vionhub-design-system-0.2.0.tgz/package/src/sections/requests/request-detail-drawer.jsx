import { useRef, useState, useLayoutEffect } from 'react';

import {
  Box,
  Tab,
  Card,
  Chip,
  Tabs,
  Alert,
  Stack,
  Drawer,
  Button,
  Divider,
  Tooltip,
  AlertTitle,
  Typography,
  IconButton,
  CardHeader,
  CardContent,
  CircularProgress,
} from '@mui/material';

import { useTabs } from 'src/hooks/use-tabs';

import { sanitizeHtml } from 'src/utils/sanitize-html';

import { Label } from 'src/components/label';
import { Iconify } from 'src/components/iconify';

import { UserChip } from './user-chip';
import { RequestTimeline } from './request-timeline';
import { defaultRequestStatusColor } from './requests-list-view';
import { formatVionhubDate, formatVionhubDateTime } from './date-utils';

// ----------------------------------------------------------------------

// Filled circular action button — same look and feel as the table row action
// buttons (ACTION_BLACK / ACTION_PRIMARY / ACTION_DANGER…): coloured bg, white
// glyph, soft shadow, hover lifts and swaps to black.
const ACTION_COLORS = {
  default: { bg: 'common.black', hover: 'primary.main' },
  primary: { bg: 'primary.main', hover: 'common.black' },
  success: { bg: 'success.main', hover: 'common.black' },
  info: { bg: 'info.main', hover: 'common.black' },
  warning: { bg: '#f5c928', hover: 'common.black', fg: 'common.black' },
  error: { bg: '#cb3b2a', hover: 'common.black' },
};

export const DrawerActionIcon = ({ title, icon, color = 'default', onClick }) => {
  const { bg, hover, fg = 'common.white' } = ACTION_COLORS[color] ?? ACTION_COLORS.default;
  const palette = {
    bgcolor: bg,
    color: fg,
    borderRadius: '50%',
    width: 36,
    height: 36,
    p: 0,
    boxShadow: '0 4px 10px rgba(0,0,0,0.18)',
    transition: 'background-color 0.2s ease, transform 0.15s ease',
    '&:hover': {
      bgcolor: hover,
      color: 'common.white',
      transform: 'translateY(-1px)',
      boxShadow: '0 6px 14px rgba(0,0,0,0.22)',
    },
  };
  return (
    <Tooltip title={title}>
      <IconButton onClick={onClick} sx={palette}>
        <Iconify icon={icon} width={18} />
      </IconButton>
    </Tooltip>
  );
};

const Field = ({ label, children }) => (
  <Stack direction={{ xs: 'column', sm: 'row' }} spacing={{ xs: 0.25, sm: 1.5 }} sx={{ py: 0.75 }}>
    <Typography variant="body2" sx={{ width: 160, color: 'text.secondary', flexShrink: 0 }}>
      {label}
    </Typography>
    <Typography variant="body2" component="div" sx={{ flex: 1, fontWeight: 500 }}>
      {children ?? <Box component="span" sx={{ color: 'text.disabled' }}>—</Box>}
    </Typography>
  </Stack>
);

const Section = ({ title, icon, children }) => (
  <Card variant="outlined" sx={{ borderRadius: 2 }}>
    <CardHeader
      avatar={icon ? <Iconify icon={icon} width={20} sx={{ color: 'primary.main' }} /> : null}
      title={title}
      titleTypographyProps={{ variant: 'subtitle1', fontWeight: 700 }}
      sx={{ pb: 1 }}
    />
    <Divider />
    <CardContent sx={{ pt: 2 }}>{children}</CardContent>
  </Card>
);

const fmtMoney = (v) => (v == null ? null : `${Number(v).toLocaleString('fr-FR')} F CFA`);

const fmtDate = (v) => formatVionhubDate(v) || null;

// Collapsible HTML block — caps the content at a reasonable height with a
// fade-out gradient and a "Voir plus / Voir moins" toggle. The toggle only
// appears when the rendered content actually overflows the cap.
const COLLAPSED_HEIGHT = 140;

export function CollapsibleHtml({ html, label = 'Description' }) {
  const ref = useRef(null);
  const [expanded, setExpanded] = useState(false);
  const [overflows, setOverflows] = useState(false);

  useLayoutEffect(() => {
    const el = ref.current;
    if (!el) return;
    setOverflows(el.scrollHeight > COLLAPSED_HEIGHT + 4);
  }, [html]);

  if (!html) return null;

  return (
    <Box>
      <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 0.5 }}>
        {label}
      </Typography>
      <Box sx={{ position: 'relative' }}>
        <Box
          ref={ref}
          sx={{
            color: 'text.secondary',
            lineHeight: 1.7,
            '& p': { my: 0.75 },
            '& ul, & ol': { pl: 3, my: 0.75 },
            '& a': { color: 'primary.main' },
            '& img': { maxWidth: '100%', borderRadius: 1 },
            maxHeight: expanded ? 'none' : COLLAPSED_HEIGHT,
            overflow: 'hidden',
            transition: 'max-height 0.2s ease',
          }}
          dangerouslySetInnerHTML={{ __html: sanitizeHtml(html) }}
        />
        {!expanded && overflows && (
          <Box
            sx={{
              position: 'absolute',
              left: 0,
              right: 0,
              bottom: 0,
              height: 48,
              pointerEvents: 'none',
              background: (t) =>
                `linear-gradient(180deg, transparent 0%, ${t.palette.background.paper} 100%)`,
            }}
          />
        )}
      </Box>
      {overflows && (
        <Button
          size="small"
          onClick={() => setExpanded((v) => !v)}
          endIcon={
            <Iconify icon={expanded ? 'eva:chevron-up-fill' : 'eva:chevron-down-fill'} width={16} />
          }
          sx={{ mt: 0.5, alignSelf: 'flex-start', textTransform: 'none' }}
        >
          {expanded ? 'Voir moins' : 'Voir plus'}
        </Button>
      )}
    </Box>
  );
}

// Stat tile used at the top of the Budget tab — heading, big amount,
// optional accent colour. Kept tight so three of them tile across the drawer.
const BudgetStat = ({ label, amount, color = 'default', icon }) => (
  <Card
    variant="outlined"
    sx={{
      flex: 1,
      minWidth: 0,
      p: 2,
      borderRadius: 2,
      borderColor: color === 'default' ? 'divider' : `${color}.light`,
      bgcolor: color === 'default' ? 'background.paper' : `${color}.lighter`,
    }}
  >
    <Stack direction="row" alignItems="center" spacing={1} sx={{ mb: 0.5 }}>
      {icon && (
        <Iconify
          icon={icon}
          width={18}
          sx={{ color: color === 'default' ? 'text.secondary' : `${color}.main` }}
        />
      )}
      <Typography variant="caption" sx={{ color: 'text.secondary', fontWeight: 600, textTransform: 'uppercase' }}>
        {label}
      </Typography>
    </Stack>
    <Typography
      variant="h6"
      sx={{ fontWeight: 700, color: color === 'default' ? 'text.primary' : `${color}.dark`, wordBreak: 'break-word' }}
    >
      {amount ?? '—'}
    </Typography>
  </Card>
);

// Visual block for the Budget tab — three balance tiles up top, then the
// account number, libellé and description rows below.
export const BudgetBlock = ({ budget, requestAmount, amountLabel = 'Montant demandé' }) => {
  const initial = budget.initialBudget ?? null;
  const consumed =
    budget.difference ?? (initial != null && budget.budget != null ? initial - budget.budget : null);
  const available = budget.budget ?? null;

  return (
    <Stack spacing={2.5}>
      <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1.5}>
        <BudgetStat label="Solde initial" amount={fmtMoney(initial)} icon="solar:wallet-2-bold" />
        <BudgetStat label="Solde consommé" amount={fmtMoney(consumed)} color="warning" icon="solar:graph-down-bold" />
        <BudgetStat label="Solde disponible" amount={fmtMoney(available)} color="success" icon="flowbite:wallet-outline" />
      </Stack>

      <Card variant="outlined" sx={{ borderRadius: 2 }}>
        <CardHeader
          avatar={<Iconify icon="solar:card-bold" width={20} sx={{ color: 'primary.main' }} />}
          title="Détails de la ligne budgétaire"
          titleTypographyProps={{ variant: 'subtitle1', fontWeight: 700 }}
          sx={{ pb: 1 }}
        />
        <Divider />
        <CardContent sx={{ pt: 2 }}>
          <Field label="Libellé">{budget.name ?? budget.description}</Field>
          <Field label="N° de compte">{budget.accountNumber}</Field>
          {budget.annualBudget?.year && <Field label="Exercice">{budget.annualBudget.year}</Field>}
          <Field label="Description">{budget.description}</Field>
          {requestAmount != null && (
            <Field label={amountLabel}>
              <Box component="span" sx={{ color: 'primary.main', fontWeight: 700 }}>
                {fmtMoney(requestAmount)}
              </Box>
            </Field>
          )}
        </CardContent>
      </Card>
    </Stack>
  );
};

// Picks a file-type icon + tint colour from the file extension.
const fileExtIcon = (filename = '') => {
  const ext = filename.split('.').pop()?.toLowerCase();
  if (ext === 'pdf') return { icon: 'vscode-icons:file-type-pdf2', color: 'error.main' };
  if (['doc', 'docx'].includes(ext)) return { icon: 'vscode-icons:file-type-word', color: 'info.main' };
  if (['xls', 'xlsx'].includes(ext)) return { icon: 'vscode-icons:file-type-excel', color: 'success.main' };
  if (['png', 'jpg', 'jpeg', 'gif', 'webp'].includes(ext)) return { icon: 'solar:gallery-bold', color: 'warning.main' };
  return { icon: 'solar:file-bold', color: 'text.secondary' };
};

// Devis / Pro-forma tab body: uploader chip, upload date, recommended border,
// open-file & download icons. `getFileUrl(att)` resolves the download URL.
export const FilesBlock = ({ attachments = [], canManage, onManage, getFileUrl }) => {
  if (!attachments.length) {
    return (
      <Card variant="outlined" sx={{ borderRadius: 2, p: 4, textAlign: 'center' }}>
        <Iconify icon="solar:file-bold" width={42} sx={{ color: 'text.disabled', mb: 1 }} />
        <Typography variant="body2" color="text.secondary">
          Aucun devis / pro-forma chargé pour cette demande.
        </Typography>
        {canManage && (
          <Button
            variant="contained"
            startIcon={<Iconify icon="solar:upload-bold" />}
            onClick={onManage}
            sx={{ mt: 2 }}
          >
            Charger des devis
          </Button>
        )}
      </Card>
    );
  }

  return (
    <Card variant="outlined" sx={{ borderRadius: 2 }}>
      <CardHeader
        avatar={<Iconify icon="solar:paperclip-bold" width={20} sx={{ color: 'primary.main' }} />}
        title="Devis / Pro-forma"
        titleTypographyProps={{ variant: 'subtitle1', fontWeight: 700 }}
        action={
          canManage ? (
            <Button
              size="small"
              variant="outlined"
              startIcon={<Iconify icon="material-symbols:edit-outline-rounded" />}
              onClick={onManage}
            >
              Modifier
            </Button>
          ) : null
        }
        sx={{ pb: 1 }}
      />
      <Divider />
      <CardContent>
        <Stack spacing={1.25}>
          {attachments.map((att) => {
            const url = getFileUrl?.(att) ?? att.url ?? null;
            const { icon, color } = fileExtIcon(att.name ?? att.file);
            return (
              <Stack
                key={att.file ?? att.name}
                direction="row"
                alignItems="center"
                spacing={1.5}
                sx={{
                  px: 1.5,
                  py: 1.25,
                  borderRadius: 1.5,
                  border: 1,
                  borderColor: att.recommended ? 'success.main' : 'divider',
                  bgcolor: att.recommended ? 'success.lighter' : 'background.neutral',
                }}
              >
                <Iconify icon={icon} width={32} sx={{ color, flexShrink: 0 }} />
                <Box sx={{ flex: 1, minWidth: 0 }}>
                  <Stack direction="row" alignItems="center" spacing={1} sx={{ mb: 0.25 }}>
                    {url ? (
                      <Typography
                        variant="body2"
                        component="a"
                        href={url}
                        target="_blank"
                        rel="noreferrer"
                        sx={{
                          fontWeight: 600,
                          color: 'text.primary',
                          textDecoration: 'none',
                          '&:hover': { color: 'primary.main' },
                          overflow: 'hidden',
                          textOverflow: 'ellipsis',
                          whiteSpace: 'nowrap',
                        }}
                      >
                        {att.name ?? att.file}
                      </Typography>
                    ) : (
                      <Typography variant="body2" sx={{ fontWeight: 600 }}>
                        {att.name ?? att.file}
                      </Typography>
                    )}
                    {att.recommended && (
                      <Tooltip title="Devis recommandé">
                        <Iconify icon="solar:check-circle-bold" width={18} sx={{ color: 'success.main' }} />
                      </Tooltip>
                    )}
                  </Stack>
                  <Stack direction="row" alignItems="center" spacing={1} sx={{ flexWrap: 'wrap' }}>
                    {att.user?.name && <UserChip name={att.user.name} />}
                    {att.date && (
                      <Typography variant="caption" color="text.secondary">
                        {att.date}
                      </Typography>
                    )}
                  </Stack>
                </Box>
                {url && (
                  <Tooltip title="Ouvrir / Télécharger">
                    <IconButton
                      size="small"
                      component="a"
                      href={url}
                      target="_blank"
                      rel="noreferrer"
                      download
                      sx={{ color: 'black' }}
                    >
                      <Iconify icon="solar:download-bold" width={18} />
                    </IconButton>
                  </Tooltip>
                )}
              </Stack>
            );
          })}
        </Stack>
      </CardContent>
    </Card>
  );
};

// Visual block for the Article section — image thumbnail on the left, then
// product name + meta + computed total on the right. When no product is
// linked it renders an empty-state line so the section never looks broken.
export const ArticleBlock = ({ product, quantity, amount, getFileUrl }) => {
  const [imgError, setImgError] = useState(false);

  if (!product) {
    return (
      <Typography variant="body2" color="text.disabled" sx={{ py: 1 }}>
        Aucun article associé à cette demande.
      </Typography>
    );
  }
  const imgUrl = product.imageUrl ?? (product.image ? getFileUrl?.({ file: product.image }) : null);
  const qty = quantity ?? 1;
  const unitPrice = amount ?? product.price;
  const hasDiscount = amount != null && product.price != null && amount !== product.price;
  const total = unitPrice && qty ? unitPrice * qty : null;

  return (
    <Stack spacing={2.5}>
      <Stack direction={{ xs: 'column', sm: 'row' }} spacing={2.5} alignItems={{ sm: 'flex-start' }}>
        <Box
          sx={{
            width: { xs: '100%', sm: 180 },
            aspectRatio: '1 / 1',
            borderRadius: 2,
            overflow: 'hidden',
            bgcolor: 'background.neutral',
            border: 1,
            borderColor: 'divider',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            flexShrink: 0,
          }}
        >
          {imgUrl && !imgError ? (
            <Box
              component="img"
              src={imgUrl}
              alt={product.name}
              loading="lazy"
              onError={() => setImgError(true)}
              sx={{ width: '100%', height: '100%', objectFit: 'cover' }}
            />
          ) : (
            <Iconify icon="solar:gallery-bold" width={40} sx={{ color: 'text.disabled' }} />
          )}
        </Box>

        <Stack spacing={1} sx={{ flex: 1, minWidth: 0 }}>
          {product.category?.name && (
            <Label color="info" variant="soft" sx={{ alignSelf: 'flex-start', textTransform: 'none' }}>
              {product.category.name}
            </Label>
          )}
          <Typography variant="h6" sx={{ fontWeight: 700, lineHeight: 1.3 }}>
            {product.name}
          </Typography>

          {/* Price + quantity metric tiles */}
          <Stack direction="row" spacing={1.25} sx={{ mt: 0.5 }} flexWrap="wrap" useFlexGap>
            <Box
              sx={{
                px: 1.5,
                py: 1,
                borderRadius: 1.5,
                border: 1,
                borderColor: 'divider',
                bgcolor: 'background.neutral',
                minWidth: 110,
              }}
            >
              <Typography variant="caption" sx={{ color: 'text.secondary', fontWeight: 600, textTransform: 'uppercase', display: 'block' }}>
                Prix unitaire
              </Typography>
              {hasDiscount ? (
                <Stack direction="row" alignItems="baseline" spacing={0.75}>
                  <Typography variant="caption" sx={{ color: 'text.disabled', textDecoration: 'line-through' }}>
                    {fmtMoney(product.price) ?? '—'}
                  </Typography>
                  <Typography variant="subtitle2" sx={{ color: 'primary.main', fontWeight: 700 }}>
                    {fmtMoney(amount) ?? '—'}
                  </Typography>
                </Stack>
              ) : (
                <Typography variant="subtitle2" sx={{ fontWeight: 700 }}>
                  {fmtMoney(unitPrice) ?? '—'}
                </Typography>
              )}
            </Box>

            <Box
              sx={{
                px: 1.5,
                py: 1,
                borderRadius: 1.5,
                border: 1,
                borderColor: 'divider',
                bgcolor: 'background.neutral',
                minWidth: 90,
              }}
            >
              <Typography variant="caption" sx={{ color: 'text.secondary', fontWeight: 600, textTransform: 'uppercase', display: 'block' }}>
                Quantité
              </Typography>
              <Typography variant="subtitle2" sx={{ fontWeight: 700 }}>
                {qty}
              </Typography>
            </Box>
          </Stack>

          {total != null && (
            <Stack
              direction="row"
              alignItems="center"
              spacing={1.5}
              sx={{
                mt: 0.5,
                alignSelf: 'flex-start',
                px: 2,
                py: 1.5,
                borderRadius: 1.5,
                bgcolor: 'primary.lighter',
                border: 1,
                borderColor: 'primary.light',
              }}
            >
              <Stack direction="row" alignItems="center" spacing={1}>
                <Iconify icon="solar:tag-price-bold" width={20} sx={{ color: 'primary.main' }} />
                <Typography variant="subtitle2" sx={{ color: 'primary.dark', fontWeight: 600 }}>
                  Montant total :
                </Typography>
              </Stack>
              <Typography variant="h6" sx={{ color: 'primary.dark', fontWeight: 700 }}>
                {fmtMoney(total)}
              </Typography>
            </Stack>
          )}
        </Stack>
      </Stack>
      {/* Catalogue description (rich HTML) — collapsible. */}
      <CollapsibleHtml html={product.description} label="Description de l'article" />
    </Stack>
  );
};

// ----------------------------------------------------------------------
// The v2 request detail drawer, data-agnostic. The consumer fetches and
// passes `data` (request payload) + `history` (action list) + `loading`;
// role-gated header buttons become the `actions` prop:
//   [{ key, title, icon, color: 'default'|'primary'|'success'|'info'|'warning'|'error', onClick }]
// Vocabularies come from `statusLabels` / `typeLabels` / `actionLabels`;
// file/image URLs resolve through `getFileUrl(att)`.

export function RequestDetailDrawer({
  open,
  onClose,
  data,
  history = [],
  loading = false,
  actions = [],
  statusLabels = {},
  statusColor = defaultRequestStatusColor,
  typeLabels = {},
  actionLabels = {},
  getFileUrl,
  canManageFiles = false,
  onManageFiles,
}) {
  const tabs = useTabs('overview');

  const attachments = data?.attachementsList ?? data?.attachmentsList ?? [];

  return (
    <Drawer
      anchor="right"
      open={open}
      onClose={onClose}
      PaperProps={{
        sx: {
          width: { xs: '100%', sm: 560, md: 720, lg: 820 },
          bgcolor: 'background.default',
        },
      }}
    >
      {/* ===== Sticky header: status pill + action icons ===== */}
      <Box
        sx={{
          position: 'sticky',
          top: 0,
          zIndex: 10,
          bgcolor: 'background.paper',
          borderBottom: 1,
          borderColor: 'divider',
        }}
      >
        <Stack direction="row" alignItems="center" sx={{ px: 2.5, py: 2, gap: 1 }}>
          <Stack direction="row" alignItems="center" spacing={1}>
            {data?.status && (
              <Label
                color={statusColor(data.status)}
                variant="soft"
                sx={{ textTransform: 'none', height: 32, px: 1.5, fontSize: 13 }}
              >
                {statusLabels[data.status] ?? data.status}
              </Label>
            )}
          </Stack>

          {actions.length > 0 && (
            <Stack direction="row" alignItems="center" spacing={1} sx={{ mx: 'auto' }}>
              <Stack
                direction="row"
                alignItems="center"
                spacing={1.25}
                sx={{
                  px: 1.25,
                  py: 0.75,
                  borderRadius: 1.5,
                  border: 1,
                  borderColor: 'divider',
                  bgcolor: 'background.neutral',
                }}
              >
                <Typography
                  variant="caption"
                  sx={{
                    color: 'text.secondary',
                    fontWeight: 700,
                    textTransform: 'uppercase',
                    letterSpacing: 0.5,
                    fontSize: 10,
                    flexShrink: 0,
                  }}
                >
                  Actions
                </Typography>
                <Stack
                  direction="row"
                  alignItems="center"
                  spacing={2}
                  flexWrap="wrap"
                  justifyContent="flex-end"
                >
                  {actions.map((action) => (
                    <DrawerActionIcon
                      key={action.key ?? action.title}
                      title={action.title}
                      icon={action.icon}
                      color={action.color}
                      onClick={() => action.onClick?.(data)}
                    />
                  ))}
                </Stack>
              </Stack>
            </Stack>
          )}

          <Tooltip title="Fermer">
            <IconButton onClick={onClose} sx={{ ml: actions.length ? 0 : 'auto' }}>
              <Iconify icon="mingcute:close-line" />
            </IconButton>
          </Tooltip>
        </Stack>

        {/* ===== Tabs ===== */}
        <Tabs
          value={tabs.value}
          onChange={tabs.onChange}
          TabIndicatorProps={{ sx: { display: 'none' } }}
          sx={{
            px: 2.5,
            pt: 1,
            minHeight: 0,
            overflow: 'visible',
            '& .MuiTabs-scroller': { overflow: 'visible !important' },
            '& .MuiTabs-flexContainer': { gap: 1 },
            '& .MuiTab-root': (theme) => ({
              minHeight: 0,
              py: 1,
              px: 2.25,
              mb: 1,
              borderRadius: '999px',
              textTransform: 'none',
              fontWeight: 600,
              fontSize: 14,
              color: 'text.secondary',
              transition: theme.transitions.create(
                ['background-color', 'color', 'box-shadow', 'transform'],
                { duration: theme.transitions.duration.shorter }
              ),
              '&:hover': {
                color: 'common.white',
                bgcolor: 'common.black',
              },
              '&.Mui-selected': {
                color: 'common.white',
                bgcolor: 'primary.main',
                boxShadow: `0 6px 16px -4px ${theme.palette.primary.main}66`,
                '&:hover': { bgcolor: 'common.black' },
              },
              '&.Mui-focusVisible': {
                outline: `2px solid ${theme.palette.primary.main}`,
                outlineOffset: 2,
              },
            }),
          }}
        >
          <Tab
            value="overview"
            label="Aperçu"
            icon={<Iconify icon="solar:info-circle-bold" width={18} />}
            iconPosition="start"
          />
          <Tab
            value="files"
            label={`Devis${attachments.length ? ` (${attachments.length})` : ''}`}
            icon={<Iconify icon="solar:paperclip-bold" width={18} />}
            iconPosition="start"
          />
          <Tab
            value="budget"
            label="Budget"
            icon={<Iconify icon="flowbite:wallet-outline" width={18} />}
            iconPosition="start"
            disabled={!data?.budgetAllocations?.length && !data?.budget}
          />
          <Tab
            value="history"
            label={`Historique${history.length ? ` (${history.length})` : ''}`}
            icon={<Iconify icon="solar:history-bold" width={18} />}
            iconPosition="start"
          />
        </Tabs>
      </Box>

      {/* ===== Body ===== */}
      <Box sx={{ p: 2.5 }}>
        {loading && (
          <Stack alignItems="center" sx={{ py: 8 }}>
            <CircularProgress />
          </Stack>
        )}

        {!loading && data && tabs.value === 'overview' && (
          <Stack spacing={2.5}>
            <Box>
              <Typography variant="h6" sx={{ mb: 0.5 }}>
                {data.object || 'Demande'}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                {data.motivation}
              </Typography>
            </Box>

            <Section title="Détail" icon="solar:info-circle-bold">
              <Stack direction="row" alignItems="center" spacing={1} sx={{ mb: 1.5, flexWrap: 'wrap' }}>
                <Label color="default" variant="soft" sx={{ textTransform: 'none' }}>
                  {typeLabels[data.type] ?? data.type}
                </Label>
                {data.needPurchaseOrder != null && (
                  <Label color={data.needPurchaseOrder ? 'success' : 'default'} variant="soft">
                    {data.needPurchaseOrder ? 'BDC requis' : 'Sans BDC'}
                  </Label>
                )}
              </Stack>
              <Field label="Demandeur">
                {data.owner?.name ? <UserChip name={data.owner.name} /> : null}
              </Field>
              <Field label="Code">
                {data?.code && <Chip label={data.code} size="small" variant="filled" />}
              </Field>
              <Field label="Département">{data.department?.name}</Field>
              <Field label="Créée le">{formatVionhubDateTime(data.createdAt) || null}</Field>
              <Field label="Date de livraison souhaitée">{fmtDate(data.expectedDeliveryDate)}</Field>
              {data.needPurchaseOrder != null && (
                <Stack
                  direction="row"
                  alignItems="center"
                  spacing={1.5}
                  sx={{
                    mt: 1.5,
                    p: 1.5,
                    borderRadius: 1.5,
                    border: 1,
                    borderColor: data.needPurchaseOrder ? 'success.light' : 'grey.300',
                    bgcolor: data.needPurchaseOrder ? 'success.lighter' : 'grey.100',
                  }}
                >
                  <Box
                    sx={{
                      width: 36,
                      height: 36,
                      borderRadius: '50%',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      flexShrink: 0,
                      color: 'common.white',
                      bgcolor: data.needPurchaseOrder ? 'success.main' : 'grey.500',
                    }}
                  >
                    <Iconify
                      icon={
                        data.needPurchaseOrder
                          ? 'solar:clipboard-check-bold'
                          : 'solar:close-circle-bold'
                      }
                      width={20}
                    />
                  </Box>
                  <Box sx={{ flex: 1, minWidth: 0 }}>
                    <Typography variant="caption" color="text.secondary" sx={{ display: 'block' }}>
                      Cette demande fera-t-elle l&apos;objet d&apos;un bon de commande ?
                    </Typography>
                    <Typography
                      variant="subtitle1"
                      sx={{
                        fontWeight: 700,
                        color: data.needPurchaseOrder ? 'success.dark' : 'text.primary',
                      }}
                    >
                      {data.needPurchaseOrder ? 'Oui' : 'Non'}
                    </Typography>
                  </Box>
                </Stack>
              )}
              {data.rejectionReason && (
                <Alert
                  severity="error"
                  variant="outlined"
                  icon={<Iconify icon="solar:danger-triangle-bold" width={22} />}
                  sx={{ mt: 1.5, borderRadius: 1.5, alignItems: 'flex-start' }}
                >
                  <AlertTitle sx={{ fontWeight: 700 }}>Motif de rejet</AlertTitle>
                  {data.rejectionReason}
                </Alert>
              )}
              {data.financeObservation && (
                <Box sx={{ mt: 1.5 }}>
                  <CollapsibleHtml html={data.financeObservation} label="Obs. finance" />
                </Box>
              )}
            </Section>

            <Section title="Article" icon="solar:box-bold">
              <ArticleBlock
                product={data.product}
                quantity={data.quantity}
                amount={data.amount}
                getFileUrl={getFileUrl}
              />
            </Section>
          </Stack>
        )}

        {!loading && data && tabs.value === 'budget' && (
          <>
            {data.budgetAllocations?.length ? (
              <Stack spacing={2.5}>
                {data.budgetAllocations.map((alloc, index) => (
                  <Box key={alloc.id ?? index}>
                    {data.budgetAllocations.length > 1 && (
                      <Typography variant="subtitle2" sx={{ mb: 1, color: 'text.secondary' }}>
                        {`Ligne ${index + 1} · `}
                        <Box component="span" sx={{ color: 'primary.main', fontWeight: 700 }}>
                          {fmtMoney(alloc.amount)}
                        </Box>
                      </Typography>
                    )}
                    <BudgetBlock budget={alloc.budget} requestAmount={alloc.amount} amountLabel="Montant affecté" />
                  </Box>
                ))}
                {data.financeObservation && (
                  <Section title="Obs. finance" icon="solar:notes-bold">
                    <CollapsibleHtml html={data.financeObservation} label="Obs. finance" />
                  </Section>
                )}
              </Stack>
            ) : data.budget ? (
              <Stack spacing={2.5}>
                <BudgetBlock budget={data.budget} requestAmount={data.amount} />
                {data.financeObservation && (
                  <Section title="Obs. finance" icon="solar:notes-bold">
                    <CollapsibleHtml html={data.financeObservation} label="Obs. finance" />
                  </Section>
                )}
              </Stack>
            ) : (
              <Typography variant="body2" color="text.secondary" sx={{ py: 4, textAlign: 'center' }}>
                Aucun budget assigné à cette demande.
              </Typography>
            )}
          </>
        )}

        {!loading && data && tabs.value === 'files' && (
          <Stack spacing={2.5}>
            <FilesBlock
              attachments={attachments}
              canManage={canManageFiles}
              onManage={() => onManageFiles?.(data)}
              getFileUrl={getFileUrl}
            />
            {data.description && (
              <Section title="Notes de la demande" icon="solar:notes-bold">
                <CollapsibleHtml html={data.description} label="Notes de la demande" />
              </Section>
            )}
          </Stack>
        )}

        {!loading && data && tabs.value === 'history' && (
          <Card variant="outlined" sx={{ borderRadius: 2 }}>
            <CardHeader
              avatar={<Iconify icon="solar:history-bold" width={20} sx={{ color: 'primary.main' }} />}
              title="Historique des actions"
              titleTypographyProps={{ variant: 'subtitle1', fontWeight: 700 }}
            />
            <Divider />
            <CardContent>
              <RequestTimeline items={history} actionLabels={actionLabels} />
            </CardContent>
          </Card>
        )}
      </Box>
    </Drawer>
  );
}
