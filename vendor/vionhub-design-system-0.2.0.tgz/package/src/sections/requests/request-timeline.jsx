import { useRef, useState, useLayoutEffect } from 'react';

import {
  Box,
  Stack,
  Button,
  Dialog,
  Typography,
  DialogTitle,
  DialogContent,
  DialogActions,
} from '@mui/material';
import {
  Timeline,
  TimelineDot,
  TimelineItem,
  TimelineContent,
  TimelineSeparator,
  TimelineConnector,
  TimelineOppositeContent,
  timelineOppositeContentClasses,
} from '@mui/lab';

import { sanitizeHtml } from 'src/utils/sanitize-html';

import { Iconify } from 'src/components/iconify';
import { DialogCloseButton } from 'src/components/custom-dialog';

import { UserChip } from './user-chip';
import { formatVionhubDateTime } from './date-utils';

// Maps action codes to (icon, color) — the v2 request-history vocabulary.
// Extend/override per entry with the `actionConfig` prop. 'grey' isn't a
// valid TimelineDot color, falls back to default styling instead.
export const TIMELINE_ACTION_CONFIG = {
  USER_CREATED:               { icon: 'solar:document-add-bold', color: 'info' },
  USER_UPDATED:               { icon: 'solar:pen-2-bold', color: 'info' },
  PENDING:                    { icon: 'solar:pen-2-bold', color: 'grey' },

  SH_APPROVED:                { icon: 'solar:like-bold', color: 'success' },
  DG_APPROVED:                { icon: 'solar:like-bold', color: 'success' },
  DA_APPROVED:                { icon: 'solar:like-bold', color: 'success' },
  PURCHASE_APPROVED:          { icon: 'solar:like-bold', color: 'success' },

  SH_REJECTED:                { icon: 'solar:dislike-bold', color: 'error' },
  DG_REJECTED:                { icon: 'solar:dislike-bold', color: 'error' },
  DA_REJECTED:                { icon: 'solar:dislike-bold', color: 'error' },
  PURCHASE_REJECTED:          { icon: 'solar:dislike-bold', color: 'error' },
  SH_REJECT_REQ_INFO:         { icon: 'solar:dislike-bold', color: 'warning' },

  SENT_BACK_TO_REQUESTER:     { icon: 'solar:undo-left-round-bold', color: 'error' },
  SENT_BACK_TO_SUPERVISOR:    { icon: 'solar:undo-left-round-bold', color: 'error' },
  SENT_BACK_TO_MG:            { icon: 'solar:undo-left-round-bold', color: 'error' },
  SENT_BACK_TO_IT:            { icon: 'solar:undo-left-round-bold', color: 'error' },
  SENT_BACK_TO_FINANCE:       { icon: 'solar:undo-left-round-bold', color: 'error' },

  FILES_LOADED:               { icon: 'solar:file-bold', color: 'info' },

  TRF_FINANCE:                { icon: 'flowbite:wallet-outline', color: 'primary' },
  TRF_IT:                     { icon: 'solar:devices-bold', color: 'primary' },
  TRF_MG:                     { icon: 'solar:copy-bold', color: 'primary' },
  TRF_DG:                     { icon: 'solar:user-id-bold', color: 'primary' },
  PURCHASE_ORDER_TRF_DG:      { icon: 'solar:user-id-bold', color: 'primary' },
  PURCHASE_ORDER_TRF_RESPONSABLE_ACHAT: { icon: 'solar:user-id-bold', color: 'primary' },

  BUDGET_ASSIGNED:            { icon: 'solar:card-bold', color: 'success' },
  PRODUCT_CHANGED:            { icon: 'solar:box-bold', color: 'info' },
  AMOUNT_CHANGED:             { icon: 'solar:dollar-bold', color: 'info' },

  NEED_PURCHASE_ORDER_DEFINED:{ icon: 'solar:question-circle-bold', color: 'info' },

  PURCHASED:                  { icon: 'solar:cart-large-bold', color: 'success' },
  DELIVERED:                  { icon: 'solar:check-circle-bold', color: 'success' },
  DELIVERY_PENDING:           { icon: 'solar:clock-circle-bold', color: 'warning' },
  DELIVERY_FAILED:            { icon: 'solar:close-circle-bold', color: 'error' },
  COMPLETED:                  { icon: 'solar:check-read-bold', color: 'success' },

  HAS_PURCHASE_ORDER:         { icon: 'solar:clipboard-check-bold', color: 'info' },
};

// Rejections AND send-backs (SENT_BACK_TO_*) render their reason in red — both
// are "negative" outcomes the requester/actor needs to notice.
const isRejection = (action = '') => /reject|sent_back/i.test(action);

// Reason can be rich HTML or plain text. Render it as HTML safely; plain text
// stays readable since dangerouslySetInnerHTML doesn't add markup.
const COLLAPSED_HEIGHT = 96;

function ReasonBox({ reason, action, actionLabels }) {
  const ref = useRef(null);
  const [overflows, setOverflows] = useState(false);
  const [open, setOpen] = useState(false);

  useLayoutEffect(() => {
    const el = ref.current;
    if (!el) return;
    setOverflows(el.scrollHeight > COLLAPSED_HEIGHT + 4);
  }, [reason]);

  const palette = isRejection(action)
    ? { bg: 'error.dark', color: 'grey.50' }
    : { bg: 'info.lighter', color: 'info.darker' };

  return (
    <>
      <Box sx={{ mt: 0, position: 'relative' }}>
        <Box
          ref={ref}
          dangerouslySetInnerHTML={{ __html: sanitizeHtml(reason) }}
          sx={{
            px: 1.25,
            py: 0.75,
            borderRadius: 1,
            bgcolor: palette.bg,
            color: palette.color,
            fontSize: 13,
            lineHeight: 1.4,
            wordBreak: 'break-word',
            maxHeight: COLLAPSED_HEIGHT,
            display: 'inline-block',
            overflow: 'hidden',
            '& p': { my: 0.5 },
            '& p:first-of-type': { mt: 0 },
            '& p:last-of-type': { mb: 0 },
            '& ul, & ol': { pl: 2.5, my: 0.5 },
            '& a': { color: 'primary.main' },
          }}
        />
        {overflows && (
          <Box
            sx={{
              position: 'absolute',
              left: 0,
              right: 0,
              bottom: 0,
              height: 32,
              pointerEvents: 'none',
              borderRadius: 1,
              background: (t) =>
                `linear-gradient(180deg, transparent 0%, ${t.palette[isRejection(action) ? 'error' : 'info'].lighter} 100%)`,
            }}
          />
        )}
      </Box>
      {overflows && (
        <Button
          size="small"
          // The drawer wraps the timeline. Clicking the button does not close
          // the drawer because the modal renders in its own portal — both stay
          // mounted, the drawer just sits behind the dialog backdrop.
          onClick={(e) => { e.stopPropagation(); setOpen(true); }}
          endIcon={<Iconify icon="eva:chevron-down-fill" width={16} />}
          sx={{ mt: 0.5, textTransform: 'none', alignSelf: 'flex-start' }}
        >
          Voir plus
        </Button>
      )}

      <Dialog
        open={open}
        onClose={() => setOpen(false)}
        maxWidth="sm"
        fullWidth
        PaperProps={{ sx: { borderRadius: 2 } }}
      >
        <DialogCloseButton onClick={() => setOpen(false)} />
        <DialogTitle>
          <Stack direction="row" alignItems="center" spacing={1.5}>
            <Iconify
              icon={isRejection(action) ? 'solar:dislike-bold' : 'solar:document-text-bold'}
              width={22}
              sx={{ color: isRejection(action) ? 'error.main' : 'primary.main' }}
            />
            <Typography variant="h6" sx={{ lineHeight: 1.2 }}>
              {actionLabels?.[action] ?? 'Détail'}
            </Typography>
          </Stack>
        </DialogTitle>
        <DialogContent dividers>
          <Box
            dangerouslySetInnerHTML={{ __html: sanitizeHtml(reason) }}
            sx={{
              color: 'text.primary',
              lineHeight: 1.7,
              '& p': { my: 1 },
              '& ul, & ol': { pl: 3, my: 1 },
              '& a': { color: 'primary.main' },
              '& img': { maxWidth: '100%', borderRadius: 1 },
              '& table': {
                borderCollapse: 'collapse',
                width: '100%',
                my: 1.5,
                '& th, & td': { border: '1px solid', borderColor: 'divider', p: 0.75 },
                '& th': { bgcolor: 'action.hover', fontWeight: 600, textAlign: 'left' },
              },
              wordBreak: 'break-word',
            }}
          />
        </DialogContent>
        <DialogActions sx={{ px: 3, py: 2 }}>
          <Button onClick={() => setOpen(false)} variant="contained">Fermer</Button>
        </DialogActions>
      </Dialog>
    </>
  );
}

// ----------------------------------------------------------------------
// Action-history timeline. `items`: [{ id, action, reason?, createdAt,
// user: { name } }]. `actionLabels` maps action codes to display text;
// `actionConfig` merges over TIMELINE_ACTION_CONFIG for icons/colors.

export function RequestTimeline({ items = [], actionLabels = {}, actionConfig }) {
  const config = actionConfig
    ? { ...TIMELINE_ACTION_CONFIG, ...actionConfig }
    : TIMELINE_ACTION_CONFIG;

  if (!items.length) {
    return (
      <Typography variant="body2" color="text.secondary" sx={{ py: 2 }}>
        Aucun historique.
      </Typography>
    );
  }

  return (
    <Timeline
      sx={{
        p: 0,
        m: 0,
        [`& .${timelineOppositeContentClasses.root}`]: {
          flex: 0,
          minWidth: 150,
          color: 'text.secondary',
          fontSize: 12,
          pt: 1.5,
        },
      }}
    >
      {items.map((h, i) => {
        const cfg = config[h.action] ?? { icon: 'solar:bell-bing-bold', color: 'grey' };
        const dotColor = cfg.color === 'grey' ? undefined : cfg.color;
        const showReason = h.reason && !String(h.reason).includes('file');
        return (
          <TimelineItem key={h.id ?? i}>
            <TimelineOppositeContent sx={{ m: 'auto 0' }} align="right">
              {formatVionhubDateTime(h.createdAt, 'DD-MM-YYYY HH:mm') || '—'}
            </TimelineOppositeContent>
            <TimelineSeparator>
              {i === 0 ? (
                <TimelineConnector sx={{ visibility: 'hidden' }} />
              ) : (
                <TimelineConnector />
              )}
              <TimelineDot color={dotColor} sx={!dotColor ? { bgcolor: 'grey.400' } : undefined}>
                <Iconify icon={cfg.icon} width={18} sx={{ color: 'common.white' }} />
              </TimelineDot>
              {i === items.length - 1 ? (
                <TimelineConnector sx={{ visibility: 'hidden' }} />
              ) : (
                <TimelineConnector />
              )}
            </TimelineSeparator>
            <TimelineContent sx={{ py: 1.25, px: 2 }}>
              <Stack spacing={0.5}>
                <Box>
                  <UserChip name={h.user?.name} />
                </Box>
                <Typography
                  variant="caption"
                  sx={{
                    textTransform: 'uppercase',
                    color: isRejection(h.action) ? 'error.main' : 'text.secondary',
                  }}
                >
                  {actionLabels[h.action] ?? String(h.action ?? '').replaceAll('_', ' ')}
                </Typography>
                {showReason && (
                  <ReasonBox reason={h.reason} action={h.action} actionLabels={actionLabels} />
                )}
              </Stack>
            </TimelineContent>
          </TimelineItem>
        );
      })}
    </Timeline>
  );
}
