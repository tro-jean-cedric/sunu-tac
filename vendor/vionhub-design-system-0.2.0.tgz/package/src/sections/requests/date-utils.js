import dayjs from 'dayjs';
import customParseFormat from 'dayjs/plugin/customParseFormat';

dayjs.extend(customParseFormat);

// Backend ships VionHub dates as the pre-formatted string "dd-MM-yyyy HH:mm".
// Native Date / default dayjs parsing yields Invalid Date for that shape,
// so try the known format first then fall back.
const VIONHUB_FORMAT = 'DD-MM-YYYY HH:mm';

export function parseVionhubDate(value) {
  if (value == null || value === '') return null;
  if (value instanceof Date) return dayjs(value);
  if (typeof value === 'string') {
    const strict = dayjs(value, VIONHUB_FORMAT, true);
    if (strict.isValid()) return strict;
  }
  const loose = dayjs(value);
  return loose.isValid() ? loose : null;
}

export function formatVionhubDate(value, format = 'DD/MM/YYYY') {
  const d = parseVionhubDate(value);
  return d ? d.format(format) : '';
}

export function formatVionhubDateTime(value, format = 'DD/MM/YYYY HH:mm') {
  return formatVionhubDate(value, format);
}
