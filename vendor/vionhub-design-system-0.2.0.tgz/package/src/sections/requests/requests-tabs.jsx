import { useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';

import { Tab, Box, Tabs, Badge } from '@mui/material';

// ----------------------------------------------------------------------
// URL-synced active tab. Falls back to the first available value if the
// query param is missing or points to a value that isn't offered.

export function useActiveScope(availableScopes, paramName = 'scope') {
  const [searchParams, setSearchParams] = useSearchParams();
  const fromUrl = searchParams.get(paramName);
  const active = availableScopes.includes(fromUrl) ? fromUrl : availableScopes[0];

  useEffect(() => {
    if (fromUrl !== active) {
      const next = new URLSearchParams(searchParams);
      next.set(paramName, active);
      setSearchParams(next, { replace: true });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [active, fromUrl]);

  const setActive = (next) => {
    const params = new URLSearchParams(searchParams);
    params.set(paramName, next);
    setSearchParams(params);
  };

  return [active, setActive];
}

// ----------------------------------------------------------------------
// Pill-shaped scope tabs with count badges — the v2 requests-list header.
// `tabs`: [{ value, label }], `counts`: { [value]: number }.

export function RequestsTabs({ tabs, active, counts, onChange }) {
  if (tabs.length <= 1) return null;

  return (
    <Box sx={{ px: 2.5, pt: 2, borderBottom: 1, borderColor: 'divider' }}>
      <Tabs
        value={active}
        onChange={(_, v) => onChange(v)}
        TabIndicatorProps={{ sx: { display: 'none' } }}
        sx={{
          minHeight: 0,
          overflow: 'visible',
          '& .MuiTabs-scroller': { overflow: 'visible !important' },
          '& .MuiTabs-flexContainer': { gap: 1 },
        }}
      >
        {tabs.map((tab) => {
          const count = counts?.[tab.value] ?? 0;
          const isActive = active === tab.value;
          return (
            <Tab
              key={tab.value}
              value={tab.value}
              disableRipple
              label={
                <Badge
                  color={isActive ? 'default' : 'primary'}
                  badgeContent={count}
                  max={99}
                  invisible={!count}
                  sx={{
                    '& .MuiBadge-badge': {
                      right: -16,
                      top: 0,
                      height: 22,
                      minWidth: 22,
                      fontSize: 12,
                      padding: '0 6px',
                      borderRadius: '11px',
                      ...(isActive && {
                        bgcolor: 'common.white',
                        color: 'primary.main',
                        fontWeight: 700,
                        boxShadow: '0 0 0 2px rgba(255,255,255,0.4)',
                      }),
                    },
                  }}
                >
                  {tab.label}
                </Badge>
              }
              sx={(theme) => ({
                minHeight: 0,
                py: 1,
                pl: 2.25,
                pr: 4,
                mb: 1,
                overflow: 'visible',
                borderRadius: '999px',
                textTransform: 'none',
                fontWeight: 600,
                fontSize: 14,
                color: 'text.secondary',
                transition: theme.transitions.create(
                  ['background-color', 'color', 'box-shadow', 'transform'],
                  { duration: theme.transitions.duration.shorter }
                ),
                '&:hover': {
                  color: 'common.white',
                  bgcolor: 'common.black',
                },
                '&.Mui-selected': {
                  color: 'common.white',
                  bgcolor: 'primary.main',
                  boxShadow: `0 6px 16px -4px ${theme.palette.primary.main}66`,
                  '&:hover': {
                    bgcolor: 'common.black',
                  },
                },
                '&.Mui-focusVisible': {
                  outline: `2px solid ${theme.palette.primary.main}`,
                  outlineOffset: 2,
                },
              })}
            />
          );
        })}
      </Tabs>
    </Box>
  );
}
