import { useState, useEffect, useCallback } from 'react';

// ----------------------------------------------------------------------
// useCrudPaginatedList — drives a server-paginated list from a single
// callback.
//
// `fetchPage({ page, size, search, ...extraParams })` must resolve to
// `{ rows, total }`. Page numbers are 1-based. This is the design-system
// counterpart of the app's use-paginated-resource hook, stripped of the
// VionHub response envelope and the SWR-lite cache: data shape and transport
// are entirely the caller's business. (The cached, DataGrid-oriented
// variant is `usePaginatedList` in components/data-grid-companion.)
// ----------------------------------------------------------------------

export function useCrudPaginatedList({ fetchPage, defaultSize = 10, extraParams }) {
  const [rows, setRows] = useState([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(defaultSize);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetchPage({ page, size: pageSize, search, ...(extraParams ?? {}) });
      setRows(res?.rows ?? []);
      setTotal(res?.total ?? 0);
    } catch (e) {
      setError(e?.message ?? 'Erreur de chargement');
      setRows([]);
      setTotal(0);
    } finally {
      setLoading(false);
    }
    // extraParams is compared by content so inline object literals don't
    // retrigger the fetch on every render.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [fetchPage, page, pageSize, search, JSON.stringify(extraParams ?? {})]);

  useEffect(() => {
    load();
  }, [load]);

  // Searching or resizing the page invalidates the current page index — jump
  // back to page 1 so the fetch can't point past the end of the filtered set.
  const setSearchReset = useCallback((v) => {
    setSearch(v);
    setPage(1);
  }, []);

  const setPageSizeReset = useCallback((v) => {
    setPageSize(v);
    setPage(1);
  }, []);

  return {
    rows,
    total,
    page,
    pageSize,
    search,
    loading,
    error,
    setPage,
    setPageSize: setPageSizeReset,
    setSearch: setSearchReset,
    refresh: load,
  };
}
