import { z as zod } from 'zod';
import { useForm } from 'react-hook-form';
import { useMemo, useEffect } from 'react';
import { zodResolver } from '@hookform/resolvers/zod';

import LoadingButton from '@mui/lab/LoadingButton';
import {
  Box,
  Dialog,
  Button,
  MenuItem,
  DialogTitle,
  DialogContent,
  DialogActions,
} from '@mui/material';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';

import { staticDialog } from 'src/utils/dialog';

import { Form, Field } from 'src/components/hook-form';
import { DialogCloseButton } from 'src/components/custom-dialog';

// ----------------------------------------------------------------------
// CrudFormDialog — the built-in schema-driven create/edit dialog used by
// <CrudListPage> when no custom FormComponent is supplied.
//
// `fields` drives everything: the zod schema, the RHF defaults and the
// rendered inputs. Each entry is
//   { name, label, type?: 'text'|'number'|'textarea'|'select'|'date',
//     required?, gridSpan?: 1|2, disabledOnEdit?,
//     options?: [{ value, label }] | string[] }   // for type 'select'
// ----------------------------------------------------------------------

function buildSchema(fields) {
  const shape = {};
  fields.forEach((f) => {
    let s;
    if (f.type === 'number') {
      // `message`, not `invalid_type_error`: zod 4 dropped `invalid_type_error`
      // (renamed to `error`) and IGNORES it silently, which would replace this
      // French message with zod's generic English one. `message` is honoured by
      // both zod 3 and zod 4, so it is the version-agnostic spelling.
      //
      // On zod 3, `message` also covers the required error, which
      // `invalid_type_error` did not — but not observably here: `zod.coerce`
      // turns `undefined` into `NaN`, so a missing value is already an
      // `invalid_type` issue under both spellings, and the "requis" message
      // comes from the `.refine()` below. Checked by running both spellings
      // through this schema on the installed zod 3.25.76 — identical output for
      // `''`, `undefined` and `'abc'`.
      s = zod.coerce.number({ message: `${f.label} doit être un nombre` });
      if (f.required) {
        s = s.refine((v) => !Number.isNaN(v), { message: `${f.label} requis` });
      } else {
        s = s.optional();
      }
    } else if (f.type === 'select') {
      // Select values can be strings or numbers — validate presence only.
      s = zod.any();
      if (f.required) {
        s = s.refine((v) => v !== '' && v !== null && v !== undefined, {
          message: `${f.label} requis`,
        });
      }
    } else {
      s = zod.string();
      s = f.required ? s.min(1, { message: `${f.label} requis` }) : s.optional();
    }
    shape[f.name] = s;
  });
  return zod.object(shape);
}

function buildDefaults(fields, initial, empty) {
  const out = { ...empty };
  fields.forEach((f) => {
    out[f.name] = initial?.[f.name] ?? empty?.[f.name] ?? '';
  });
  return out;
}

function normalizeOptions(options = []) {
  return options.map((opt) =>
    typeof opt === 'object' && opt !== null ? opt : { value: opt, label: String(opt) }
  );
}

export function CrudFormDialog({ open, onClose, initialValue, emptyValues, fields, title, onSubmit }) {
  const isEdit = !!initialValue;
  // DatePicker needs a LocalizationProvider ancestor. Provide one locally so
  // the dialog stays drop-in even in apps that don't mount it globally —
  // nested providers inherit the outer one's props, so this is a no-op when
  // the host app already has its own.
  const hasDateField = fields.some((f) => f.type === 'date');

  const schema = useMemo(() => buildSchema(fields), [fields]);
  const methods = useForm({
    resolver: zodResolver(schema),
    defaultValues: buildDefaults(fields, initialValue, emptyValues),
  });

  useEffect(() => {
    methods.reset(buildDefaults(fields, initialValue, emptyValues));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [initialValue, open]);

  const submit = methods.handleSubmit(onSubmit);

  const renderField = (f) => {
    const disabled = isEdit && !!f.disabledOnEdit;
    if (f.type === 'textarea') {
      return <Field.Text name={f.name} label={f.label} multiline rows={3} disabled={disabled} />;
    }
    if (f.type === 'number') {
      return <Field.Number name={f.name} label={f.label} disabled={disabled} />;
    }
    if (f.type === 'select') {
      return (
        <Field.Select name={f.name} label={f.label} disabled={disabled}>
          {normalizeOptions(f.options).map((opt) => (
            <MenuItem key={opt.value} value={opt.value}>
              {opt.label}
            </MenuItem>
          ))}
        </Field.Select>
      );
    }
    if (f.type === 'date') {
      return <Field.DatePicker name={f.name} label={f.label} disabled={disabled} />;
    }
    return <Field.Text name={f.name} label={f.label} disabled={disabled} />;
  };

  const dialog = (
    <Dialog fullWidth maxWidth="sm" open={open} onClose={staticDialog(onClose)}>
      <DialogCloseButton onClick={onClose} />
      <Form methods={methods} onSubmit={submit}>
        <DialogTitle>{title}</DialogTitle>
        <DialogContent>
          <Box
            sx={{
              display: 'grid',
              gridTemplateColumns: { xs: '1fr', sm: 'repeat(2, 1fr)' },
              gap: 2,
              py: 1,
            }}
          >
            {fields.map((f) => (
              <Box key={f.name} sx={{ gridColumn: { sm: f.gridSpan === 2 ? 'span 2' : 'span 1' } }}>
                {renderField(f)}
              </Box>
            ))}
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={onClose} color="inherit">
            Annuler
          </Button>
          <LoadingButton type="submit" variant="contained" loading={methods.formState.isSubmitting}>
            {isEdit ? 'Modifier' : 'Enregistrer'}
          </LoadingButton>
        </DialogActions>
      </Form>
    </Dialog>
  );

  return hasDateField ? (
    <LocalizationProvider dateAdapter={AdapterDayjs}>{dialog}</LocalizationProvider>
  ) : (
    dialog
  );
}
