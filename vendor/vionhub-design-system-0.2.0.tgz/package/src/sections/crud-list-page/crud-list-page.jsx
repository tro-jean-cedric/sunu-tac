import { useMemo, useState, useCallback } from 'react';

import { Button, Tooltip, IconButton } from '@mui/material';

import { useBoolean } from 'src/hooks/use-boolean';

import { DashboardContent } from 'src/layouts/dashboard';

import { toast } from 'src/components/snackbar';
import { Iconify } from 'src/components/iconify';
import { ConfirmDialog } from 'src/components/custom-dialog';
import { CustomBreadcrumbs } from 'src/components/custom-breadcrumbs';
import {
  ActionsCell,
  ACTION_BLACK,
  AsyncDataGrid,
  ACTION_DANGER,
} from 'src/components/async-data-grid';

import { CrudFormDialog } from './crud-form-dialog';
import { useCrudPaginatedList } from './use-paginated-list';

// ----------------------------------------------------------------------
// The v2 admin CRUD screen, data-agnostic: breadcrumbs + searchable
// server-paginated grid + "Add" button + auto-appended edit/delete row
// actions + delete confirm + schema-driven create/edit dialog. The app
// instantiated this exact shape in ~10 modules (categories, departments,
// companies, suppliers, budgets…) at ~30 lines each.
//
// Props:
//   title            — entity name used in dialog titles ("Catégorie"…).
//   heading          — page heading (defaults to `title`).
//   breadcrumbs      — [{ name, href? }] passed to CustomBreadcrumbs links.
//   columns          — DataGrid GridColDef[]; the actions column is appended.
//   fetchPage        — async ({ page, size, search, ...extraParams }) =>
//                      { rows, total }. Page is 1-based.
//   onCreate(values), onUpdate(values, row), onDelete(row)
//                    — async mutation callbacks. Resolve = success (toast +
//                      refresh), throw = failure (error toast; the thrown
//                      error's `message` wins over the default label).
//   fields           — form description for the built-in dialog:
//                      [{ name, label, type: 'text'|'number'|'textarea'|
//                         'select'|'date', required?, gridSpan?: 1|2,
//                         disabledOnEdit?, options? }].
//   emptyValues      — default values for a new record.
//   mapBeforeSave    — (values, editingRow) => payload sent to onCreate /
//                      onUpdate. Default merges { ...editingRow, ...values }.
//   FormComponent    — replaces the built-in dialog. Receives
//                      { open, onClose, initial, onSubmit }.
//   canCreate / canEdit / canDelete — role gates (default true).
//   addLabel         — toolbar button label (default 'Ajouter').
//   labels           — { deleteTitle, deleteMessage(row), deleteConfirm,
//                        saved, deleted, saveFailed, deleteFailed,
//                        actionFailed, confirmTitle, confirmMessage,
//                        confirmLabel, editTitle(title), createTitle(title) }
//                      — each overridable, French defaults.
//   rowActions       — (row, { openEdit, askDelete, askConfirm, refresh }) =>
//                      node rendered in the actions cell before edit/delete
//                      (extra history/toggle buttons…). `askConfirm(row, kind,
//                      run)` opens the confirm dialog for a non-delete action;
//                      `run(row)` executes on confirm, then the list refreshes.
//   confirmContent   — (pendingAction: { row, kind }) => { title, content,
//                      confirmLabel, color } copy for non-delete confirms.
//   slots            — { container, toolbar, toolbarLeft, topSlot,
//                        belowToolbar }. `container: false` drops the
//                      DashboardContent wrapper; a component replaces it.
//                      The rest pass through to AsyncDataGrid (`toolbar`
//                      renders before the Add button).
//   extraParams      — extra params merged into every fetchPage call.
// ----------------------------------------------------------------------

const DEFAULT_LABELS = {
  deleteTitle: 'Confirmer la suppression',
  deleteMessage: () => 'Êtes-vous sûr de vouloir supprimer cet élément ?',
  deleteConfirm: 'Supprimer',
  saved: 'Enregistré',
  deleted: 'Supprimé',
  saveFailed: "Échec de l'enregistrement",
  deleteFailed: 'Échec de la suppression',
  actionFailed: 'Échec de l’opération',
  confirmTitle: 'Confirmer',
  confirmMessage: 'Confirmer cette opération ?',
  confirmLabel: 'Confirmer',
  editTitle: (title) => `Modifier ${title.toLowerCase()}`,
  createTitle: (title) => `Nouveau ${title.toLowerCase()}`,
};

export function CrudListPage({
  title,
  heading,
  breadcrumbs = [],
  columns,
  fetchPage,
  onCreate,
  onUpdate,
  onDelete,
  fields,
  emptyValues = {},
  mapBeforeSave,
  FormComponent,
  canCreate = true,
  canEdit = true,
  canDelete = true,
  addLabel = 'Ajouter',
  labels: labelsProp,
  rowActions,
  confirmContent,
  slots = {},
  extraParams,
}) {
  const labels = useMemo(() => ({ ...DEFAULT_LABELS, ...labelsProp }), [labelsProp]);

  const formOpen = useBoolean();
  const confirmOpen = useBoolean();
  const [editing, setEditing] = useState(null);
  // { row, kind: 'delete' | string, run? } — `run` is set by askConfirm for
  // non-delete confirmable actions (close/open a budget, archive…).
  const [pendingAction, setPendingAction] = useState(null);

  const { rows, total, page, pageSize, search, loading, setPage, setPageSize, setSearch, refresh } =
    useCrudPaginatedList({ fetchPage, extraParams });

  const openCreate = () => {
    setEditing(null);
    formOpen.onTrue();
  };

  const openEdit = useCallback(
    (row) => {
      setEditing(row);
      formOpen.onTrue();
    },
    [formOpen]
  );

  const askDelete = useCallback(
    (row) => {
      setPendingAction({ row, kind: 'delete' });
      confirmOpen.onTrue();
    },
    [confirmOpen]
  );

  const askConfirm = useCallback(
    (row, kind, run) => {
      setPendingAction({ row, kind, run });
      confirmOpen.onTrue();
    },
    [confirmOpen]
  );

  // NOTE: pendingAction is intentionally NOT cleared here — keeping it lets
  // <ConfirmDialog open={false}> stay mounted and play its exit transition.
  // askDelete/askConfirm overwrite it on the next open anyway.
  const closeConfirm = () => {
    confirmOpen.onFalse();
  };

  const runPendingAction = async () => {
    if (!pendingAction) return;
    const { row, kind, run } = pendingAction;
    try {
      if (kind === 'delete') {
        await onDelete?.(row);
        toast.success(labels.deleted);
      } else {
        await run?.(row);
      }
      refresh();
    } catch (e) {
      toast.error(
        kind === 'delete' ? (e?.message ?? labels.deleteFailed) : (e?.message ?? labels.actionFailed)
      );
    }
    closeConfirm();
  };

  const handleSubmit = async (values) => {
    const payload = mapBeforeSave ? mapBeforeSave(values, editing) : { ...(editing ?? {}), ...values };
    try {
      if (editing) {
        await onUpdate?.(payload, editing);
      } else {
        await onCreate?.(payload);
      }
      toast.success(labels.saved);
      formOpen.onFalse();
      refresh();
    } catch (e) {
      toast.error(e?.message ?? labels.saveFailed);
    }
  };

  const enrichedColumns = useMemo(() => {
    if (!canEdit && !canDelete && !rowActions) return columns;
    const actionCol = {
      field: '__actions',
      headerName: ' ',
      sortable: false,
      // With extra row actions the column self-sizes (flex + minWidth from
      // AsyncDataGrid defaults); otherwise keep the app's fixed 130px.
      ...(rowActions ? { minWidth: 130 } : { width: 130 }),
      renderCell: (params) => (
        <ActionsCell sx={{ gap: 1 }}>
          {rowActions?.(params.row, { openEdit, askDelete, askConfirm, refresh })}
          {canEdit && (
            <Tooltip title="Modifier">
              <IconButton size="small" sx={ACTION_DANGER} onClick={() => openEdit(params.row)}>
                <Iconify icon="solar:pen-bold" width={20} />
              </IconButton>
            </Tooltip>
          )}
          {canDelete && (
            <Tooltip title="Supprimer">
              <IconButton size="small" sx={ACTION_BLACK} onClick={() => askDelete(params.row)}>
                <Iconify icon="solar:trash-bin-trash-bold" width={20} />
              </IconButton>
            </Tooltip>
          )}
        </ActionsCell>
      ),
    };
    return [...columns, actionCol];
  }, [columns, canEdit, canDelete, rowActions, openEdit, askDelete, askConfirm, refresh]);

  const confirmCopy = useMemo(() => {
    if (!pendingAction) return null;
    if (pendingAction.kind !== 'delete') {
      if (confirmContent) return confirmContent(pendingAction);
      // Neutral fallback — never dress a custom action up as a delete.
      return {
        title: labels.confirmTitle,
        content: labels.confirmMessage,
        confirmLabel: labels.confirmLabel,
        color: 'primary',
      };
    }
    return {
      title: labels.deleteTitle,
      content: labels.deleteMessage(pendingAction.row),
      confirmLabel: labels.deleteConfirm,
      color: 'error',
    };
  }, [pendingAction, confirmContent, labels]);

  const renderContainer = (children) => {
    if (slots.container === false || slots.container === null) return children;
    const Container = slots.container ?? DashboardContent;
    return <Container maxWidth="xl">{children}</Container>;
  };

  const addButton = canCreate && (
    <Button
      variant="contained"
      color="primary"
      startIcon={<Iconify icon="mingcute:add-line" />}
      onClick={openCreate}
    >
      {addLabel}
    </Button>
  );

  return (
    <>
      {renderContainer(
        <>
          <CustomBreadcrumbs
            heading={heading ?? title}
            links={breadcrumbs}
            sx={{ mb: { xs: 3, md: 5 } }}
          />

          <AsyncDataGrid
            columns={enrichedColumns}
            rows={rows}
            total={total}
            page={page}
            pageSize={pageSize}
            search={search}
            loading={loading}
            onPageChange={setPage}
            onPageSizeChange={setPageSize}
            onSearchChange={setSearch}
            topSlot={slots.topSlot}
            belowToolbar={slots.belowToolbar}
            toolbarLeft={slots.toolbarLeft}
            toolbar={
              slots.toolbar || addButton ? (
                <>
                  {slots.toolbar}
                  {addButton}
                </>
              ) : undefined
            }
          />
        </>
      )}

      {FormComponent ? (
        <FormComponent
          open={formOpen.value}
          onClose={formOpen.onFalse}
          initial={editing}
          onSubmit={handleSubmit}
        />
      ) : (
        !!fields && (
          <CrudFormDialog
            open={formOpen.value}
            onClose={formOpen.onFalse}
            initialValue={editing}
            emptyValues={emptyValues}
            fields={fields}
            title={editing ? labels.editTitle(title) : labels.createTitle(title)}
            onSubmit={handleSubmit}
          />
        )
      )}

      {confirmCopy && (
        <ConfirmDialog
          open={confirmOpen.value}
          onClose={closeConfirm}
          title={confirmCopy.title}
          content={confirmCopy.content}
          action={
            <Button variant="contained" color={confirmCopy.color ?? 'error'} onClick={runPendingAction}>
              {confirmCopy.confirmLabel}
            </Button>
          }
        />
      )}
    </>
  );
}
