import Box from '@mui/material/Box';
import Card from '@mui/material/Card';
import Stack from '@mui/material/Stack';
import Typography from '@mui/material/Typography';
import { alpha, useTheme } from '@mui/material/styles';

import { fNumber } from 'src/utils/format-number';

import { Iconify } from 'src/components/iconify';
import { Chart, useChart } from 'src/components/chart';

// ----------------------------------------------------------------------
// One color-coded tile in the personal KPI row. Visual identity per metric
// — distinct icon, accent color, top stripe, soft tinted icon disc — so
// the four cards no longer read as the same widget repeated four times.

export function KpiTile({
  label,
  value,
  icon = 'solar:graph-up-bold-duotone',
  color = 'primary',
  series = [],
  caption,
}) {
  const theme = useTheme();
  const paletteColor = theme.palette[color]?.main ?? theme.palette.primary.main;

  const sparklineOptions = useChart({
    chart: { sparkline: { enabled: true } },
    colors: [paletteColor],
    stroke: { width: 2, curve: 'smooth' },
    fill: {
      type: 'gradient',
      gradient: {
        shadeIntensity: 1,
        opacityFrom: 0.35,
        opacityTo: 0,
        stops: [0, 100],
      },
    },
    tooltip: {
      enabled: true,
      y: { formatter: (v) => fNumber(v), title: { formatter: () => '' } },
      marker: { show: false },
    },
  });

  const hasSeries = Array.isArray(series) && series.some((n) => n > 0);

  return (
    <Card
      sx={{
        position: 'relative',
        height: '100%',
        p: 3,
        overflow: 'hidden',
        transition: 'transform 200ms ease, box-shadow 200ms ease',
        '&:hover': {
          transform: 'translateY(-2px)',
          boxShadow: (t) => `0 12px 30px -12px ${alpha(paletteColor, 0.4)}`,
        },
      }}
    >
      {/* Top accent stripe */}
      <Box
        aria-hidden
        sx={{
          position: 'absolute',
          top: 0,
          left: 0,
          right: 0,
          height: 4,
          bgcolor: paletteColor,
        }}
      />

      {/* Soft tinted glow in the top-right */}
      <Box
        aria-hidden
        sx={{
          position: 'absolute',
          top: -60,
          right: -60,
          width: 160,
          height: 160,
          borderRadius: '50%',
          bgcolor: alpha(paletteColor, 0.08),
          pointerEvents: 'none',
        }}
      />

      <Stack direction="row" alignItems="center" justifyContent="space-between" sx={{ mb: 2 }}>
        <Box
          sx={{
            width: 44,
            height: 44,
            borderRadius: '50%',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: paletteColor,
            bgcolor: alpha(paletteColor, 0.14),
          }}
        >
          <Iconify icon={icon} width={22} />
        </Box>

        {hasSeries && (
          <Box sx={{ width: 84, opacity: 0.9 }}>
            <Chart
              type="area"
              series={[{ data: series }]}
              options={sparklineOptions}
              width="100%"
              height={48}
            />
          </Box>
        )}
      </Stack>

      <Typography variant="body2" sx={{ color: 'text.secondary', mb: 0.5, fontWeight: 500 }}>
        {label}
      </Typography>
      <Typography variant="h3" sx={{ fontWeight: 700, lineHeight: 1.1, color: paletteColor }}>
        {fNumber(value ?? 0)}
      </Typography>

      {caption && (
        <Typography variant="caption" sx={{ color: 'text.disabled', display: 'block', mt: 0.75 }}>
          {caption}
        </Typography>
      )}
    </Card>
  );
}
