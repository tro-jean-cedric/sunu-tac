import Box from '@mui/material/Box';
import Card from '@mui/material/Card';
import Stack from '@mui/material/Stack';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import { alpha, useTheme } from '@mui/material/styles';

import { useRouter } from 'src/routes/hooks';

import { fToNow } from 'src/utils/format-time';

import { Label } from 'src/components/label';
import { Iconify } from 'src/components/iconify';

// ----------------------------------------------------------------------

const ROLE_VISUAL = {
  DG: { icon: 'solar:crown-bold-duotone' },
  SUPERIEUR_HIERARCHIQUE: { icon: 'solar:user-check-bold-duotone' },
  FINANCE: { icon: 'solar:wallet-money-bold-duotone' },
  MOYEN_GENERAUX: { icon: 'solar:cart-large-2-bold-duotone' },
  IT: { icon: 'solar:laptop-minimalistic-bold-duotone' },
  RESPONSABLE_ACHAT: { icon: 'solar:bag-check-bold-duotone' },
};

const SEVERITY_PALETTE = {
  INFO: 'info',
  SUCCESS: 'success',
  WARNING: 'warning',
  ERROR: 'error',
  DANGER: 'error', // alias — backend may emit either
  PRIMARY: 'primary',
};

const defaultStatusColor = (status) => {
  if (!status) return 'default';
  if (
    status.endsWith('_APPROVED') ||
    status === 'COMPLETED' ||
    status === 'DELIVERED' ||
    status === 'PURCHASED'
  )
    return 'success';
  if (status.endsWith('_REJECTED') || status === 'DELIVERY_FAILED' || status === 'PURCHASE_DELETED')
    return 'error';
  if (status === 'DRAFT') return 'default';
  return 'warning';
};

// ----------------------------------------------------------------------
// Items may carry `statusLabel` / `statusColor` to control the chip; otherwise
// `statusLabels[status]` (prop) then the raw status string is displayed, with
// a suffix-based color heuristic. Clicks default to router.push(item.link) /
// router.push(viewAllLink) — override with onItemClick / onViewAll.

export function RoleWidgetCard({
  role,
  icon,
  title,
  subtitle,
  count,
  items = [],
  viewAllLink,
  severity = 'INFO',
  statusLabels,
  onItemClick,
  onViewAll,
}) {
  const theme = useTheme();
  const router = useRouter();

  const paletteColor = theme.palette[SEVERITY_PALETTE[severity] ?? 'info']?.main;
  const visualIcon = icon ?? ROLE_VISUAL[role]?.icon ?? 'solar:bell-bing-bold-duotone';

  const itemStatusLabel = (item) => item.statusLabel ?? statusLabels?.[item.status] ?? item.status;

  const itemStatusColor = (item) => item.statusColor ?? defaultStatusColor(item.status);

  const handleItemClick = (item) => {
    if (onItemClick) {
      onItemClick(item);
    } else if (item.link) {
      router.push(item.link);
    }
  };

  const handleViewAll = () => {
    if (onViewAll) {
      onViewAll();
    } else if (viewAllLink) {
      router.push(viewAllLink);
    }
  };

  return (
    <Card sx={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      <Stack direction="row" alignItems="center" spacing={1.5} sx={{ p: 2.5, pb: 1.5 }}>
        <Box
          sx={{
            width: 44,
            height: 44,
            borderRadius: 1.5,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: paletteColor,
            bgcolor: alpha(paletteColor, 0.12),
            flexShrink: 0,
          }}
        >
          <Iconify icon={visualIcon} width={24} />
        </Box>

        <Box sx={{ flex: 1, minWidth: 0 }}>
          <Typography variant="subtitle1" sx={{ fontWeight: 700, lineHeight: 1.2 }} noWrap>
            {title}
          </Typography>
          {subtitle && (
            <Typography variant="caption" color="text.secondary" noWrap>
              {subtitle}
            </Typography>
          )}
        </Box>

        <Box
          sx={{
            px: 1.25,
            py: 0.5,
            borderRadius: 999,
            color: paletteColor,
            bgcolor: alpha(paletteColor, 0.16),
            fontWeight: 700,
            fontSize: 14,
            minWidth: 36,
            textAlign: 'center',
          }}
        >
          {count ?? 0}
        </Box>
      </Stack>

      {/* Body */}
      {items.length === 0 ? (
        <Box sx={{ p: 3, textAlign: 'center', color: 'text.disabled', flex: 1 }}>
          <Iconify icon="solar:check-circle-bold-duotone" width={36} sx={{ mb: 0.5 }} />
          <Typography variant="body2">Rien en attente</Typography>
        </Box>
      ) : (
        <Stack
          divider={<Box sx={{ borderTop: '1px dashed', borderColor: 'divider' }} />}
          sx={{ flex: 1 }}
        >
          {items.map((item) => (
            <Stack
              key={`${item.entityType}-${item.id}`}
              direction="row"
              alignItems="center"
              spacing={1.5}
              sx={{
                px: 2.5,
                py: 1.5,
                cursor: 'pointer',
                '&:hover': { bgcolor: 'action.hover' },
              }}
              onClick={() => handleItemClick(item)}
            >
              <Box sx={{ flex: 1, minWidth: 0 }}>
                <Stack direction="row" spacing={1} alignItems="center" sx={{ mb: 0.25 }}>
                  <Typography
                    variant="subtitle2"
                    sx={{ fontFamily: 'monospace', color: 'text.secondary' }}
                  >
                    {item.code}
                  </Typography>
                  <Label color={itemStatusColor(item)} variant="soft" sx={{ height: 18 }}>
                    {itemStatusLabel(item)}
                  </Label>
                </Stack>
                <Typography variant="body2" noWrap sx={{ fontWeight: 500 }}>
                  {item.label || '—'}
                </Typography>
                <Stack
                  direction="row"
                  alignItems="center"
                  sx={{ typography: 'caption', color: 'text.disabled', mt: 0.25 }}
                  divider={
                    <Box
                      sx={{
                        width: 2,
                        height: 2,
                        bgcolor: 'currentColor',
                        mx: 0.5,
                        borderRadius: '50%',
                      }}
                    />
                  }
                >
                  {item.ownerName && <span>{item.ownerName}</span>}
                  <span>{fToNow(item.createdAt)}</span>
                </Stack>
              </Box>
              <Iconify
                icon="eva:arrow-ios-forward-fill"
                width={18}
                sx={{ color: 'text.disabled' }}
              />
            </Stack>
          ))}
        </Stack>
      )}

      {/* Footer */}
      {viewAllLink && (
        <Box sx={{ p: 1.5, borderTop: '1px dashed', borderColor: 'divider' }}>
          <Button
            fullWidth
            onClick={handleViewAll}
            endIcon={<Iconify icon="eva:arrow-ios-forward-fill" />}
            sx={{ justifyContent: 'space-between', color: 'text.secondary' }}
          >
            Voir tout {count > items.length ? `(${count})` : ''}
          </Button>
        </Box>
      )}
    </Card>
  );
}
