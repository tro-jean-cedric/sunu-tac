import { useMemo } from 'react';

import Box from '@mui/material/Box';
import Card from '@mui/material/Card';
import Stack from '@mui/material/Stack';
import Button from '@mui/material/Button';
import Skeleton from '@mui/material/Skeleton';
import Grid from '@mui/material/Unstable_Grid2';
import { useTheme } from '@mui/material/styles';
import Typography from '@mui/material/Typography';
import CardHeader from '@mui/material/CardHeader';

import { useRouter } from 'src/routes/hooks';
import { RouterLink } from 'src/routes/components';

import { fToNow } from 'src/utils/format-time';

import { DashboardContent } from 'src/layouts/dashboard';

import { Iconify } from 'src/components/iconify';
import { Chart, useChart } from 'src/components/chart';

import { KpiTile } from './kpi-tile';
import { DashboardHero } from './dashboard-hero';
import { RoleWidgetCard } from './role-widget-card';

// ----------------------------------------------------------------------
// The v2 dashboard page, data-agnostic. `data` shape:
// {
//   displayName,
//   personal: { draftCount, pendingCount, approvedCount, rejectedCount,
//               recentRequests: [{ id, code, label, createdAt, link }] },
//   trend: { labels: [...], myRequestsByMonth: [...], myApprovedByMonth: [...] },
//   roleWidgets: [{ role, title, subtitle, count, items, viewAllLink, severity }],
// }

export function DashboardOverviewView({
  data,
  loading = false,
  viewAllHref = '/dashboard/requests',
  heroProps,
  roleWidgetProps,
  onRecentItemClick,
}) {
  const theme = useTheme();
  const router = useRouter();

  const displayName = data?.displayName ?? 'Utilisateur';

  // ---- Welcome banner copy adapts to whether the user has pending actions ----
  const awaitingCount = useMemo(
    () =>
      (data?.roleWidgets ?? []).reduce(
        (acc, w) => acc + (typeof w.count === 'number' ? w.count : 0),
        0
      ),
    [data]
  );
  // ---- Personal KPI cards ----
  const personal = data?.personal;
  const trendSeries = data?.trend?.myRequestsByMonth ?? [0, 0, 0, 0, 0, 0];
  const approvedSeries = data?.trend?.myApprovedByMonth ?? [0, 0, 0, 0, 0, 0];
  const trendLabels = data?.trend?.labels ?? ['Jan', 'Fév', 'Mar', 'Avr', 'Mai', 'Juin'];

  // ---- Trend line chart ----
  const trendChartOptions = useChart({
    chart: { toolbar: { show: false } },
    stroke: { curve: 'smooth', width: 3 },
    legend: { position: 'top', horizontalAlign: 'right', offsetY: -8 },
    xaxis: { categories: trendLabels },
    yaxis: { labels: { formatter: (v) => Math.round(v) } },
    tooltip: { y: { formatter: (v) => `${v}` } },
    colors: [theme.palette.primary.main, theme.palette.success.main],
  });

  const handleRecentItemClick = (item) => {
    if (onRecentItemClick) {
      onRecentItemClick(item);
    } else if (item.link) {
      router.push(item.link);
    }
  };

  return (
    <DashboardContent maxWidth="xl">
      <Grid container spacing={3}>
        {/* ============ HERO ============ */}
        <Grid xs={12}>
          <DashboardHero displayName={displayName} awaitingCount={awaitingCount} {...heroProps} />
        </Grid>

        {/* ============ PERSONAL KPI ROW ============ */}
        <Grid xs={12} sm={6} md={3}>
          <KpiTile
            label="Mes brouillons"
            value={personal?.draftCount}
            icon="solar:document-bold-duotone"
            color="info"
            series={trendSeries}
            caption="Demandes pas encore soumises"
          />
        </Grid>

        <Grid xs={12} sm={6} md={3}>
          <KpiTile
            label="En cours de traitement"
            value={personal?.pendingCount}
            icon="solar:refresh-circle-bold-duotone"
            color="warning"
            series={trendSeries}
            caption="En attente d'une validation"
          />
        </Grid>

        <Grid xs={12} sm={6} md={3}>
          <KpiTile
            label="Validées"
            value={personal?.approvedCount}
            icon="solar:verified-check-bold-duotone"
            color="success"
            series={approvedSeries}
            caption="Approuvées et au-delà"
          />
        </Grid>

        <Grid xs={12} sm={6} md={3}>
          <KpiTile
            label="Rejetées"
            value={personal?.rejectedCount}
            icon="solar:close-circle-bold-duotone"
            color="error"
            series={[]}
            caption="Rejets sur l'ensemble"
          />
        </Grid>

        {/* ============ TREND CHART ============ */}
        <Grid xs={12}>
          <Card>
            <CardHeader
              title="Activité de mes demandes"
              subheader="6 derniers mois"
              sx={{ pb: 1 }}
            />
            <Box sx={{ p: 3, pt: 1 }}>
              <Chart
                type="line"
                series={[
                  { name: 'Créées', data: trendSeries },
                  { name: 'Validées', data: approvedSeries },
                ]}
                options={trendChartOptions}
                height={280}
              />
            </Box>
          </Card>
        </Grid>

        {/* ============ ROLE WIDGETS ============ */}
        {loading && (
          <>
            <Grid xs={12} md={6}>
              <Skeleton variant="rounded" height={280} />
            </Grid>
            <Grid xs={12} md={6}>
              <Skeleton variant="rounded" height={280} />
            </Grid>
          </>
        )}

        {!loading && (data?.roleWidgets ?? []).map((w, idx) => (
          <Grid xs={12} md={6} key={`${w.role}-${idx}`}>
            <RoleWidgetCard
              role={w.role}
              title={w.title}
              subtitle={w.subtitle}
              count={w.count}
              items={w.items}
              viewAllLink={w.viewAllLink}
              severity={w.severity}
              {...roleWidgetProps}
            />
          </Grid>
        ))}

        {/* ============ RECENT ACTIVITY ============ */}
        <Grid xs={12}>
          <Card>
            <CardHeader
              title="Activité récente"
              subheader="Mes 5 dernières demandes"
              action={
                <Button
                  component={RouterLink}
                  href={viewAllHref}
                  color="inherit"
                  endIcon={<Iconify icon="eva:arrow-ios-forward-fill" />}
                >
                  Voir tout
                </Button>
              }
            />
            {loading && (
              <Box sx={{ p: 2 }}>
                {[0, 1, 2].map((i) => (
                  <Skeleton key={i} variant="text" height={48} />
                ))}
              </Box>
            )}
            {!loading && (personal?.recentRequests?.length ?? 0) === 0 && (
              <Box sx={{ p: 4, textAlign: 'center', color: 'text.disabled' }}>
                <Iconify icon="solar:inbox-out-bold-duotone" width={40} sx={{ mb: 0.5 }} />
                <Typography variant="body2">Aucune demande récente</Typography>
              </Box>
            )}
            {!loading && (personal?.recentRequests ?? []).length > 0 && (
              <Stack
                divider={<Box sx={{ borderTop: '1px dashed', borderColor: 'divider' }} />}
              >
                {personal.recentRequests.map((r) => (
                  <Stack
                    key={`recent-${r.id}`}
                    direction="row"
                    alignItems="center"
                    spacing={2}
                    sx={{
                      px: 3,
                      py: 1.5,
                      cursor: 'pointer',
                      '&:hover': { bgcolor: 'action.hover' },
                    }}
                    onClick={() => handleRecentItemClick(r)}
                  >
                    <Typography
                      variant="subtitle2"
                      sx={{ fontFamily: 'monospace', color: 'text.secondary', width: 160 }}
                      noWrap
                    >
                      {r.code}
                    </Typography>
                    <Typography variant="body2" sx={{ flex: 1, fontWeight: 500 }} noWrap>
                      {r.label}
                    </Typography>
                    <Typography
                      variant="caption"
                      color="text.disabled"
                      sx={{ display: { xs: 'none', sm: 'block' } }}
                    >
                      {fToNow(r.createdAt)}
                    </Typography>
                    <Iconify
                      icon="eva:arrow-ios-forward-fill"
                      width={18}
                      sx={{ color: 'text.disabled' }}
                    />
                  </Stack>
                ))}
              </Stack>
            )}
          </Card>
        </Grid>
      </Grid>
    </DashboardContent>
  );
}
