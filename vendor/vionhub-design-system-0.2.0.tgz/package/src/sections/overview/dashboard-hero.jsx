import Box from '@mui/material/Box';
import Card from '@mui/material/Card';
import Stack from '@mui/material/Stack';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import { alpha, useTheme } from '@mui/material/styles';

import { RouterLink } from 'src/routes/components';

import { SeoIllustration } from 'src/assets/illustrations';

import { Iconify } from 'src/components/iconify';

// ----------------------------------------------------------------------

/**
 * A hero call-to-action button. Pass `null` to hide the button.
 *
 * @typedef {object} DashboardHeroAction
 * @property {string} label
 * @property {string} href
 */

/**
 * @typedef {object} DashboardHeroProps
 * @property {string} [displayName] Name shown in the greeting.
 * @property {number} [awaitingCount] Items awaiting the user's action (default `0`).
 * @property {import('react').ReactNode} [eyebrow]
 * @property {DashboardHeroAction | null} [primaryAction]
 * @property {DashboardHeroAction | null} [secondaryAction]
 * @property {import('react').ReactNode} [illustration]
 */

/**
 * @param {DashboardHeroProps} props
 * @returns {import('react').JSX.Element}
 */
export function DashboardHero({
  displayName,
  awaitingCount = 0,
  eyebrow = 'Tableau de bord',
  primaryAction = { label: 'Voir mes demandes', href: '/dashboard/requests' },
  secondaryAction = { label: 'Notifications', href: '/dashboard/notifications' },
  illustration = <SeoIllustration hideBackground />,
}) {
  const theme = useTheme();

  const hasPending = awaitingCount > 0;
  const accentColor = hasPending ? theme.palette.warning.main : theme.palette.success.main;

  return (
    <Card
      sx={{
        position: 'relative',
        overflow: 'hidden',
        p: { xs: 3, md: 5 },
        color: 'common.white',
        background: (t) =>
          `linear-gradient(135deg, ${t.palette.primary.dark} 0%, ${t.palette.primary.main} 55%, ${alpha(
            t.palette.primary.light,
            0.95
          )} 100%)`,
      }}
    >
      {/* Decorative blurred shapes */}
      <Box
        aria-hidden
        sx={{
          position: 'absolute',
          top: -120,
          right: -80,
          width: 320,
          height: 320,
          borderRadius: '50%',
          bgcolor: (t) => alpha(t.palette.common.white, 0.08),
          filter: 'blur(6px)',
          pointerEvents: 'none',
        }}
      />
      <Box
        aria-hidden
        sx={{
          position: 'absolute',
          bottom: -100,
          left: '40%',
          width: 240,
          height: 240,
          borderRadius: '50%',
          bgcolor: (t) => alpha(t.palette.common.white, 0.06),
          filter: 'blur(4px)',
          pointerEvents: 'none',
        }}
      />

      <Stack
        direction={{ xs: 'column', md: 'row' }}
        spacing={{ xs: 3, md: 4 }}
        alignItems={{ xs: 'flex-start', md: 'center' }}
        sx={{ position: 'relative', zIndex: 1 }}
      >
        <Stack spacing={2.5} sx={{ flex: 1, minWidth: 0 }}>
          <Typography variant="caption" sx={{ letterSpacing: 1.2, textTransform: 'uppercase', opacity: 0.75 }}>
            {eyebrow}
          </Typography>

          <Typography
            variant="h3"
            sx={{ lineHeight: 1.15, fontWeight: 700, color: 'common.white' }}
          >
            Bonjour, {displayName} <Box component="span" sx={{ display: 'inline-block' }}>👋</Box>
          </Typography>

          {/* Awaiting stat pill */}
          <Stack
            direction="row"
            alignItems="center"
            spacing={2}
            sx={{
              display: 'inline-flex',
              alignSelf: 'flex-start',
              px: 2.5,
              py: 1.5,
              borderRadius: 999,
              bgcolor: alpha(theme.palette.common.white, 0.15),
              backdropFilter: 'blur(8px)',
              border: `1px solid ${alpha(theme.palette.common.white, 0.25)}`,
            }}
          >
            <Box
              sx={{
                width: 36,
                height: 36,
                borderRadius: '50%',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                bgcolor: alpha(accentColor, 0.95),
                color: 'common.white',
              }}
            >
              <Iconify icon={hasPending ? 'solar:bell-bing-bold-duotone' : 'solar:check-circle-bold-duotone'} width={20} />
            </Box>
            <Box>
              <Typography variant="h5" sx={{ fontWeight: 700, color: 'common.white', lineHeight: 1.1 }}>
                {awaitingCount}
              </Typography>
              <Typography variant="caption" sx={{ opacity: 0.85 }}>
                {hasPending
                  ? `élément${awaitingCount > 1 ? 's' : ''} en attente de votre action`
                  : 'tout est à jour'}
              </Typography>
            </Box>
          </Stack>

          <Stack direction="row" spacing={1.5} sx={{ pt: 0.5 }}>
            {primaryAction && (
              <Button
                component={RouterLink}
                href={primaryAction.href}
                variant="contained"
                sx={{
                  bgcolor: 'common.white',
                  color: 'primary.main',
                  fontWeight: 700,
                  '&:hover': { bgcolor: alpha(theme.palette.common.white, 0.9) },
                }}
                endIcon={<Iconify icon="eva:arrow-ios-forward-fill" />}
              >
                {primaryAction.label}
              </Button>
            )}
            {secondaryAction && (
              <Button
                component={RouterLink}
                href={secondaryAction.href}
                variant="outlined"
                sx={{
                  color: 'common.white',
                  borderColor: alpha(theme.palette.common.white, 0.4),
                  '&:hover': {
                    borderColor: 'common.white',
                    bgcolor: alpha(theme.palette.common.white, 0.08),
                  },
                }}
              >
                {secondaryAction.label}
              </Button>
            )}
          </Stack>
        </Stack>

        <Box
          sx={{
            display: { xs: 'none', md: 'block' },
            flexShrink: 0,
            width: 260,
            maxWidth: '40%',
          }}
        >
          {illustration}
        </Box>
      </Stack>
    </Card>
  );
}
