import {
  Table,
  Paper,
  Tooltip,
  TableRow,
  TableBody,
  TableCell,
  TableHead,
  TextField,
  IconButton,
  Typography,
  TableContainer,
} from '@mui/material';

import { fNumber } from 'src/utils/format-number';

import { Iconify } from 'src/components/iconify';
import { NumberFormatInput } from 'src/components/number-format-input';

// ----------------------------------------------------------------------
// The lighter, always-editing sibling of EditableLineItemsTable — every cell
// is an editor from the start. Made for import previews (Excel budget lines…)
// and small batch entry: sticky-header container capped at `maxHeight`, an
// index column, per-cell editors by type and a per-row remove button.
//
// Fully controlled: `rows` in, `onRowsChange(nextRows)` out.
//
// Props:
// - columns: [{ key, label, type: 'text'|'number', width?, align?, editable? }]
//     `editable` defaults to true; a non-editable cell renders plain text
//     (numbers formatted through fNumber).
// - rows / onRowsChange: the data and its change emitter.
// - removable: show the trash column (default true).
// - showIndex: show the "#" column (default true).
// - maxHeight: scroll cap of the sticky-header container (default 360).
// - renderCell?(row, column, index): custom cell node; return undefined to
//     fall back to the default editor.
// - labels?: { remove } French defaults.
// - size: MUI table size (default 'small').

const DEFAULT_LABELS = { remove: 'Retirer' };

export function EditableRowsTable({
  columns = [],
  rows = [],
  onRowsChange,
  removable = true,
  showIndex = true,
  maxHeight = 360,
  renderCell,
  labels: labelsProp,
  size = 'small',
}) {
  const labels = { ...DEFAULT_LABELS, ...labelsProp };

  const updateRow = (index, key, value) => {
    const next = rows.map((row, i) => (i === index ? { ...row, [key]: value } : row));
    onRowsChange?.(next);
  };

  const removeRow = (index) => {
    onRowsChange?.(rows.filter((_, i) => i !== index));
  };

  const renderDefaultCell = (row, column, index) => {
    if (column.editable === false) {
      return (
        <Typography variant="body2">
          {column.type === 'number' ? fNumber(row[column.key]) : row[column.key]}
        </Typography>
      );
    }
    if (column.type === 'number') {
      return (
        <NumberFormatInput
          size="small"
          value={row[column.key] ?? ''}
          onChange={(val) => updateRow(index, column.key, val)}
          inputProps={{ style: { textAlign: 'right' } }}
          sx={{ width: 140 }}
        />
      );
    }
    return (
      <TextField
        size="small"
        fullWidth
        value={row[column.key] ?? ''}
        onChange={(e) => updateRow(index, column.key, e.target.value)}
      />
    );
  };

  return (
    <TableContainer component={Paper} variant="outlined" sx={{ borderRadius: 1.5, maxHeight }}>
      <Table size={size} stickyHeader>
        <TableHead>
          <TableRow>
            {showIndex && <TableCell sx={{ width: 50, fontWeight: 700 }}>#</TableCell>}
            {columns.map((column) => (
              <TableCell
                key={column.key}
                align={column.align}
                sx={{ fontWeight: 700, ...(column.width && { width: column.width }) }}
              >
                {column.label}
              </TableCell>
            ))}
            {removable && <TableCell sx={{ width: 60 }} />}
          </TableRow>
        </TableHead>
        <TableBody>
          {rows.map((row, index) => (
            // eslint-disable-next-line react/no-array-index-key
            <TableRow key={index} hover>
              {showIndex && <TableCell>{index + 1}</TableCell>}
              {columns.map((column) => {
                const custom = renderCell?.(row, column, index);
                return (
                  <TableCell key={column.key} align={column.align}>
                    {custom !== undefined ? custom : renderDefaultCell(row, column, index)}
                  </TableCell>
                );
              })}
              {removable && (
                <TableCell>
                  <Tooltip title={labels.remove}>
                    <IconButton size="small" color="error" onClick={() => removeRow(index)}>
                      <Iconify icon="solar:trash-bin-trash-bold" width={18} />
                    </IconButton>
                  </Tooltip>
                </TableCell>
              )}
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
}
