import { useState } from 'react';

import {
  Box,
  Table,
  Paper,
  Button,
  Tooltip,
  TableRow,
  Checkbox,
  TableBody,
  TableCell,
  TableHead,
  TextField,
  IconButton,
  Typography,
  TableContainer,
} from '@mui/material';

import { fNumber } from 'src/utils/format-number';

import { Iconify } from 'src/components/iconify';
import { NumberFormatInput } from 'src/components/number-format-input';

// ----------------------------------------------------------------------
// The invoice / purchase-order line editor: a compact outlined table whose
// rows toggle between a read view and an inline edit mode (pencil <-> save
// icons), with optional multi-select + merge of similar rows.
//
// Fully controlled — `items` is the single source of truth. Every field
// commit runs `computeRow` (e.g. qty * price -> subtotal), then emits the
// next array through `onChange`. The only internal state is UI state (which
// rows are in edit mode / selected).
//
// Props:
// - items: array of row objects.
// - onChange(nextItems): fired after any edit, delete or merge.
// - onDeleteItem?(nextItems, removedRow): extra hook on row removal.
// - columns: [{ key, label, align?, width?, editable?: 'text'|'number'|'currency',
//     readOnly?, stripHtml?, render?: (row) => node }]. `render` overrides the
//     read view; `editable` picks the editor shown while the row is in edit mode
//     (TextField for text, NumberFormatInput for number / currency);
//     `readOnly` (or no `editable`) keeps the cell static even while editing;
//     `stripHtml: true` strips HTML tags from the cell's string value in both
//     the read view and the text editor (for rich-text columns like description).
// - computeRow?(row) => row: derives computed fields after each field commit.
// - mergeConfig?: { validate: (rows) => string|null, merge: (rows) => row,
//     label? } — enables the contextual "Fusionner (n)" toolbar button when
//     2+ rows are selected. `validate` returns an error string (-> onError)
//     or null; `merge` returns the replacement row.
// - selectable: show the checkbox column (default false, forced on by mergeConfig).
// - emptyMessage: text of the empty-state row.
// - getRowKey?(row, index): stable row identity (default: row.id, or a key
//     generated per row object so identity survives deletes / merges).
// - onError?(message): surfaced instead of toasts (merge validation…).
// - formatAmount?(value): read-view formatter for 'currency' columns (default fNumber).
// - labels?: { edit, save, delete, actions, merge } French defaults.
// - size: MUI table size (default 'small').

// Description-ish cells may carry HTML (rich text pasted from a request).
// Strip every tag, like PHP's strip_tags(), so the table shows plain text.
// Opt-in per column via `stripHtml: true` — other text columns keep their
// raw value (which may legitimately contain angle brackets).
export const stripHtml = (value) => String(value ?? '').replace(/<[^>]*>/g, '');

const DEFAULT_LABELS = {
  edit: 'Modifier',
  save: 'Enregistrer',
  delete: 'Supprimer',
  actions: 'Actions',
  merge: 'Fusionner',
};

// Default identity: row.id when present, else a generated key tied to the
// row object's identity (a WeakMap survives filter/map of sibling rows), so
// edit-mode / selection never jump to a different row after a delete or merge
// shifts indexes — index-based keys would.
const generatedKeys = new WeakMap();
let nextGeneratedKey = 0;

const defaultRowKey = (row, index) => {
  if (row?.id != null) return row.id;
  if (row == null || typeof row !== 'object') return index;
  if (!generatedKeys.has(row)) {
    nextGeneratedKey += 1;
    generatedKeys.set(row, `__row_${nextGeneratedKey}`);
  }
  return generatedKeys.get(row);
};

export function EditableLineItemsTable({
  items = [],
  onChange,
  onDeleteItem,
  columns = [],
  computeRow,
  mergeConfig,
  selectable = false,
  emptyMessage = 'Aucun élément',
  getRowKey = defaultRowKey,
  onError,
  formatAmount = fNumber,
  labels: labelsProp,
  size = 'small',
}) {
  const labels = { ...DEFAULT_LABELS, ...labelsProp };
  const withCheckbox = selectable || !!mergeConfig;

  // UI-only state: rows currently in edit mode / selected, tracked by key.
  const [editingKeys, setEditingKeys] = useState([]);
  const [selectedKeys, setSelectedKeys] = useState([]);

  const keyOf = (row, index) => getRowKey(row, index);

  const commitField = (index, key, value) => {
    const next = items.map((row, i) => {
      if (i !== index) return row;
      const patched = { ...row, [key]: value };
      return computeRow ? computeRow(patched) : patched;
    });
    onChange?.(next);
  };

  const toggleEdit = (rowKey) => {
    setEditingKeys((prev) =>
      prev.includes(rowKey) ? prev.filter((k) => k !== rowKey) : [...prev, rowKey]
    );
  };

  const removeRow = (index) => {
    const removed = items[index];
    const removedKey = keyOf(removed, index);
    const next = items.filter((_, i) => i !== index);
    setSelectedKeys((prev) => prev.filter((k) => k !== removedKey));
    setEditingKeys((prev) => prev.filter((k) => k !== removedKey));
    onChange?.(next);
    onDeleteItem?.(next, removed);
  };

  const toggleSelect = (rowKey) => {
    setSelectedKeys((prev) =>
      prev.includes(rowKey) ? prev.filter((k) => k !== rowKey) : [...prev, rowKey]
    );
  };

  const selectedIndexes = items
    .map((row, i) => (selectedKeys.includes(keyOf(row, i)) ? i : -1))
    .filter((i) => i !== -1);

  const merge = () => {
    if (!mergeConfig) return;
    const rows = selectedIndexes.map((i) => items[i]);
    const error = mergeConfig.validate?.(rows);
    if (error) {
      onError?.(error);
      return;
    }
    const mergedRaw = mergeConfig.merge(rows);
    const merged = computeRow ? computeRow(mergedRaw) : mergedRaw;
    const firstIdx = Math.min(...selectedIndexes);
    const remaining = items.filter((_, i) => !selectedIndexes.includes(i));
    const insertAt = Math.min(firstIdx, remaining.length);
    const next = [...remaining.slice(0, insertAt), merged, ...remaining.slice(insertAt)];
    setSelectedKeys([]);
    // Merged-away rows must not leave the resulting row in edit mode.
    setEditingKeys((prev) => prev.filter((k) => !selectedKeys.includes(k)));
    onChange?.(next);
  };

  const colCount = columns.length + 1 + (withCheckbox ? 1 : 0);

  const renderView = (column, row) => {
    if (column.render) return column.render(row);
    const value = row[column.key];
    if (column.editable === 'currency') {
      return (
        <Typography variant="body2" sx={{ fontWeight: 500 }}>
          {formatAmount(value)}
        </Typography>
      );
    }
    return (
      <Typography variant="body2">
        {column.stripHtml && typeof value === 'string' ? stripHtml(value) : value}
      </Typography>
    );
  };

  const renderEditor = (column, row, index) => {
    if (column.editable === 'text') {
      return (
        <TextField
          size="small"
          fullWidth
          multiline
          defaultValue={column.stripHtml ? stripHtml(row[column.key]) : row[column.key] ?? ''}
          onBlur={(e) => commitField(index, column.key, e.target.value)}
        />
      );
    }
    if (column.editable === 'number' || column.editable === 'currency') {
      return (
        <NumberFormatInput
          size="small"
          value={row[column.key] ?? ''}
          onChange={(val) => commitField(index, column.key, val)}
          inputProps={{ style: { textAlign: 'right' } }}
          sx={{ width: column.editable === 'currency' ? 120 : 90 }}
        />
      );
    }
    return renderView(column, row);
  };

  return (
    <Box>
      {mergeConfig && selectedIndexes.length >= 2 && (
        <Box sx={{ display: 'flex', justifyContent: 'flex-end', mb: 1 }}>
          <Button
            variant="contained"
            size="small"
            startIcon={<Iconify icon="solar:link-bold" />}
            onClick={merge}
          >
            {mergeConfig.label ?? labels.merge} ({selectedIndexes.length})
          </Button>
        </Box>
      )}

      <TableContainer component={Paper} variant="outlined" sx={{ borderRadius: 1.5 }}>
        <Table size={size}>
          <TableHead>
            <TableRow>
              {withCheckbox && <TableCell padding="checkbox" />}
              {columns.map((column) => (
                <TableCell
                  key={column.key}
                  align={column.align}
                  sx={{ fontWeight: 700, ...(column.width && { width: column.width }) }}
                >
                  {column.label}
                </TableCell>
              ))}
              <TableCell align="center" sx={{ fontWeight: 700 }}>
                {labels.actions}
              </TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {items.length === 0 && (
              <TableRow>
                <TableCell
                  colSpan={colCount}
                  align="center"
                  sx={{ py: 4, color: 'text.secondary', fontStyle: 'italic' }}
                >
                  {emptyMessage}
                </TableCell>
              </TableRow>
            )}
            {items.map((row, index) => {
              const rowKey = keyOf(row, index);
              const isEditing = editingKeys.includes(rowKey);
              const isSelected = selectedKeys.includes(rowKey);
              return (
                <TableRow key={rowKey} selected={isSelected} hover>
                  {withCheckbox && (
                    <TableCell padding="checkbox">
                      <Checkbox
                        size="small"
                        checked={isSelected}
                        onChange={() => toggleSelect(rowKey)}
                      />
                    </TableCell>
                  )}
                  {columns.map((column) => {
                    const editable = column.editable && !column.readOnly;
                    return (
                      <TableCell
                        key={column.key}
                        align={column.align}
                        sx={{ wordBreak: 'break-word' }}
                      >
                        {isEditing && editable
                          ? renderEditor(column, row, index)
                          : renderView(column, row)}
                      </TableCell>
                    );
                  })}
                  <TableCell align="center">
                    <Tooltip title={isEditing ? labels.save : labels.edit}>
                      <IconButton
                        size="small"
                        onClick={() => toggleEdit(rowKey)}
                        color={isEditing ? 'success' : 'default'}
                      >
                        <Iconify
                          icon={isEditing ? 'solar:diskette-bold' : 'solar:pen-2-bold'}
                          width={18}
                        />
                      </IconButton>
                    </Tooltip>
                    <Tooltip title={labels.delete}>
                      <IconButton size="small" color="error" onClick={() => removeRow(index)}>
                        <Iconify icon="solar:trash-bin-trash-bold" width={18} />
                      </IconButton>
                    </Tooltip>
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </TableContainer>
    </Box>
  );
}
