import {
  Box,
  Chip,
  Stack,
  Alert,
  Button,
  TextField,
  IconButton,
  Typography,
  Autocomplete,
  InputAdornment,
} from '@mui/material';

import { fNumber } from 'src/utils/format-number';

import { Iconify } from 'src/components/iconify';
import { NumberFormatInput } from 'src/components/number-format-input';

// ----------------------------------------------------------------------
// Split a fixed total across one or several options (budget lines, cost
// centres…). Each row pairs an Autocomplete — with a two-line option
// rendering (label / secondary + balance) — with a formatted amount field,
// plus a remove button and an "add row" action. A live Alert keeps the
// Total / Allocated / Remaining summary in view with success / warning /
// error colouring and soft chips flagging under- or over-allocation.
//
// Fully controlled: `value` is [{ optionId, amount }] and every edit emits
// the next array through `onChange`. Options already picked by sibling rows
// are excluded from each row's choices. No toasts inside — run the exported
// `validateAllocations(rows, total)` on submit and surface its errors.
//
// Props:
// - total: the amount the allocations must add up to.
// - options: [{ id, label, secondary?, balance? }].
// - value / onChange: [{ optionId, amount }] rows (amount = digit string or number).
// - currency: adornment / summary suffix (e.g. 'F CFA', default '').
// - formatAmount?(value): display formatter (default fNumber).
// - getOptionDisabled?(option): extra per-option disabling.
// - renderOption?(props, option): overrides the two-line option rendering.
// - labels?: French defaults — { add, total, allocated, remaining, balance,
//     optionPlaceholder, amountPlaceholder, remove, under, over };
//     `under` / `over` are templates where '{amount}' is substituted.
// - disabled: freeze all inputs and actions (default false).

const DEFAULT_LABELS = {
  add: 'Ajouter une ligne',
  total: 'Montant total',
  allocated: 'Affecté',
  remaining: 'Restant',
  balance: 'Solde',
  optionPlaceholder: 'Rechercher une ligne',
  amountPlaceholder: 'Montant',
  remove: 'Supprimer',
  under: 'Il reste {amount} à affecter',
  over: 'Dépassement de {amount}',
};

const EMPTY_ROW = { optionId: null, amount: '' };

const fillTemplate = (template, amount) => String(template).replace('{amount}', amount);

// ----------------------------------------------------------------------
// Pure validation of allocation rows against the expected total. Returns
// { ok, errors: [{ index?, code, message }] } — codes: OPTION_REQUIRED,
// AMOUNT_INVALID, DUPLICATE_OPTION, SUM_MISMATCH.

export function validateAllocations(rows = [], total = 0) {
  const errors = [];

  rows.forEach((row, index) => {
    if (row.optionId == null) {
      errors.push({
        index,
        code: 'OPTION_REQUIRED',
        message: 'Veuillez sélectionner une ligne pour chaque affectation',
      });
    }
    if (!(Number(row.amount) > 0)) {
      errors.push({
        index,
        code: 'AMOUNT_INVALID',
        message: 'Chaque montant affecté doit être supérieur à zéro',
      });
    }
  });

  const ids = rows.map((row) => row.optionId).filter((id) => id != null);
  if (new Set(ids).size !== ids.length) {
    errors.push({
      code: 'DUPLICATE_OPTION',
      message: 'Une même ligne ne peut être sélectionnée deux fois',
    });
  }

  const allocated = rows.reduce((sum, row) => sum + (Number(row.amount) || 0), 0);
  if (allocated !== Number(total)) {
    errors.push({
      code: 'SUM_MISMATCH',
      message: `La somme des montants (${fNumber(allocated)}) doit être égale au montant total (${fNumber(total)})`,
    });
  }

  return { ok: errors.length === 0, errors };
}

// ----------------------------------------------------------------------

export function AmountAllocationEditor({
  total = 0,
  options = [],
  value,
  onChange,
  currency = '',
  formatAmount = fNumber,
  getOptionDisabled,
  renderOption,
  labels: labelsProp,
  disabled = false,
}) {
  const labels = { ...DEFAULT_LABELS, ...labelsProp };

  const rows = value?.length ? value : [EMPTY_ROW];

  const fmt = (v) => `${formatAmount(v)}${currency ? ` ${currency}` : ''}`;

  const findOption = (id) => (id == null ? null : options.find((o) => o.id === id) ?? null);

  const allocated = rows.reduce((sum, row) => sum + (Number(row.amount) || 0), 0);
  const remaining = Number(total) - allocated;
  const balanced = remaining === 0;

  const emit = (next) => onChange?.(next);

  const setRow = (index, patch) =>
    emit(rows.map((row, i) => (i === index ? { ...row, ...patch } : row)));

  const addRow = () => emit([...rows, EMPTY_ROW]);

  const removeRow = (index) => {
    if (rows.length > 1) emit(rows.filter((_, i) => i !== index));
  };

  const getOptionLabel = (option) =>
    option ? `${option.label}${option.secondary ? ` — ${option.secondary}` : ''}` : '';

  const defaultRenderOption = (props, option) => (
    <li {...props} key={option.id}>
      <Box sx={{ display: 'flex', flexDirection: 'column', py: 0.5 }}>
        <Typography variant="body2" sx={{ fontWeight: 600 }}>
          {option.label} {option.secondary && `— ${option.secondary}`}
        </Typography>
        {option.balance != null && (
          <Typography variant="caption" color="text.secondary">
            {labels.balance} : {fmt(option.balance)}
          </Typography>
        )}
      </Box>
    </li>
  );

  return (
    <Box>
      <Alert
        severity={balanced ? 'success' : remaining < 0 ? 'error' : 'warning'}
        icon={<Iconify icon="solar:calculator-bold" />}
        sx={{ alignItems: 'center', mb: 2 }}
      >
        <Stack direction="row" flexWrap="wrap" spacing={2} sx={{ rowGap: 0.5 }}>
          <span>
            {labels.total} : <b>{fmt(total)}</b>
          </span>
          <span>
            {labels.allocated} : <b>{fmt(allocated)}</b>
          </span>
          <span>
            {labels.remaining} :{' '}
            <Box
              component="b"
              sx={{
                color: balanced ? 'success.main' : remaining < 0 ? 'error.main' : 'warning.main',
              }}
            >
              {fmt(remaining)}
            </Box>
          </span>
        </Stack>
      </Alert>

      <Stack spacing={1.5}>
        {rows.map((row, index) => {
          const takenIds = rows
            .filter((_, i) => i !== index)
            .map((r) => r.optionId)
            .filter((id) => id != null);
          const rowOptions = options.filter((o) => !takenIds.includes(o.id));
          return (
            // eslint-disable-next-line react/no-array-index-key
            <Stack
              key={index}
              direction={{ xs: 'column', sm: 'row' }}
              spacing={1}
              alignItems="flex-start"
            >
              <Autocomplete
                sx={{ flex: 1, minWidth: 0, width: '100%' }}
                options={rowOptions}
                disabled={disabled}
                value={findOption(row.optionId)}
                getOptionLabel={getOptionLabel}
                getOptionDisabled={getOptionDisabled}
                isOptionEqualToValue={(opt, val) => opt?.id === val?.id}
                onChange={(_, v) => setRow(index, { optionId: v?.id ?? null })}
                renderOption={renderOption ?? defaultRenderOption}
                renderInput={(params) => (
                  <TextField {...params} placeholder={labels.optionPlaceholder} />
                )}
              />
              <NumberFormatInput
                value={row.amount ?? ''}
                onChange={(val) => setRow(index, { amount: val })}
                placeholder={labels.amountPlaceholder}
                disabled={disabled}
                sx={{ width: { xs: '100%', sm: 200 } }}
                InputProps={{
                  endAdornment: currency ? (
                    <InputAdornment position="end">{currency}</InputAdornment>
                  ) : null,
                }}
              />
              <IconButton
                aria-label={labels.remove}
                color="error"
                disabled={disabled || rows.length === 1}
                onClick={() => removeRow(index)}
                sx={{ mt: { xs: 0, sm: 0.5 } }}
              >
                <Iconify icon="solar:trash-bin-trash-bold" />
              </IconButton>
            </Stack>
          );
        })}
      </Stack>

      <Button
        size="small"
        startIcon={<Iconify icon="mingcute:add-line" />}
        onClick={addRow}
        disabled={disabled}
        sx={{ mt: 1.5 }}
      >
        {labels.add}
      </Button>

      {remaining > 0 && (
        <Chip
          size="small"
          variant="soft"
          color="warning"
          label={fillTemplate(labels.under, fmt(remaining))}
          sx={{ mt: 1.5, ml: 1 }}
        />
      )}
      {remaining < 0 && (
        <Chip
          size="small"
          variant="soft"
          color="error"
          label={fillTemplate(labels.over, fmt(-remaining))}
          sx={{ mt: 1.5, ml: 1 }}
        />
      )}
    </Box>
  );
}
