// ----------------------------------------------------------------------
// Editable-input helpers (inlined from the app's utils/format-number).
// These are used by number text fields so that a value shows with a SPACE
// thousand separator while being typed (10000 -> "10 000"), yet is stored /
// submitted as plain digits ("10000"). The separator is always a plain space,
// independent of the display locale.

export const THOUSAND_SEPARATOR = ' ';

/**
 * Strip a display value back to a plain numeric string: keep digits, a single
 * decimal point and an optional leading minus. "10 000,50" -> "10000.50".
 * Returns '' when there is nothing numeric to keep.
 */
export function unformatNumber(value) {
  if (value == null) return '';
  let s = String(value).replace(/\s/g, '');
  const negative = s.startsWith('-');

  // Resolve the comma: it is a decimal separator (fr locale) only when it is
  // the sole grouping char; when a dot is present or there are several commas
  // the commas are thousand separators and must be dropped. This keeps pasted
  // "1,234,567.89" -> "1234567.89" instead of mangling it.
  const commaCount = (s.match(/,/g) || []).length;
  if (s.includes('.')) {
    s = s.replace(/,/g, '');
  } else if (commaCount > 1) {
    s = s.replace(/,/g, '');
  } else if (commaCount === 1) {
    s = s.replace(',', '.');
  }

  s = s.replace(/[^\d.]/g, '');
  const firstDot = s.indexOf('.');
  if (firstDot !== -1) {
    // keep only the first decimal point
    s = s.slice(0, firstDot + 1) + s.slice(firstDot + 1).replace(/\./g, '');
  }
  return negative && s !== '' ? `-${s}` : s;
}

/**
 * Format a raw value (number or in-progress string) with space thousand
 * separators, preserving a trailing/partial decimal so typing "10." or "10.50"
 * is not clobbered. "10000" -> "10 000", "1234.5" -> "1 234.5".
 */
export function formatNumberInput(value) {
  const raw = unformatNumber(value);
  if (raw === '' || raw === '-') return raw;

  const negative = raw.startsWith('-');
  const body = negative ? raw.slice(1) : raw;
  const [intPart, ...decRest] = body.split('.');
  const grouped = intPart.replace(/\B(?=(\d{3})+(?!\d))/g, THOUSAND_SEPARATOR);
  const out = body.includes('.') ? `${grouped}.${decRest.join('')}` : grouped;

  return negative ? `-${out}` : out;
}
