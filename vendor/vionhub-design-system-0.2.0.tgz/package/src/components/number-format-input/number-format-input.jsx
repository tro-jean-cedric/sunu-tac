import { useRef, useState, useEffect, useLayoutEffect } from 'react';

import TextField from '@mui/material/TextField';

import { unformatNumber, formatNumberInput } from './utils';

// ----------------------------------------------------------------------
// A controlled MUI TextField that displays its value with a space thousand
// separator (10000 -> "10 000") while emitting the plain, unformatted numeric
// string through `onChange` so callers store / submit digits only ("10000").
//
//   <NumberFormatInput value={amount} onChange={setAmount} label="Montant" />
//
// `value` may be a number, a numeric string, '' or null. `onChange` receives a
// clean string ('' when empty). All other props are forwarded to TextField.
// ----------------------------------------------------------------------

function isEmpty(raw) {
  return raw === '' || raw === '-' || raw === '.';
}

// True when two values represent the same number (so an in-progress "10." or
// "10.50" typed by the user is not overwritten by an echoed numeric value),
// while genuinely different / cleared values still resync the display.
function sameValue(a, b) {
  const ra = unformatNumber(a);
  const rb = unformatNumber(b);
  if (ra === rb) return true;
  if (isEmpty(ra) || isEmpty(rb)) return false;
  return Number(ra) === Number(rb);
}

// Count digit characters in `str` up to (but excluding) index `pos`.
function countDigits(str, pos) {
  let n = 0;
  for (let i = 0; i < pos && i < str.length; i += 1) {
    if (str[i] >= '0' && str[i] <= '9') n += 1;
  }
  return n;
}

// Index just after the `count`-th digit in `str` — used to keep the caret next
// to the same digit after separators are (re)inserted.
function caretAfterDigits(str, count) {
  if (count <= 0) return 0;
  let seen = 0;
  for (let i = 0; i < str.length; i += 1) {
    if (str[i] >= '0' && str[i] <= '9') {
      seen += 1;
      if (seen === count) return i + 1;
    }
  }
  return str.length;
}

export function NumberFormatInput({ value, onChange, inputRef, ...other }) {
  const nodeRef = useRef(null);
  const caretRef = useRef(null);
  const [display, setDisplay] = useState(() => formatNumberInput(value));

  const setNode = (node) => {
    nodeRef.current = node;
    if (typeof inputRef === 'function') inputRef(node);
    else if (inputRef) inputRef.current = node;
  };

  // Resync the display when the value changes from outside (reset, autofill,
  // programmatic set) but not while the user is mid-edit on the same number.
  useEffect(() => {
    if (!sameValue(value, display)) {
      setDisplay(formatNumberInput(value));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [value]);

  // Restore the caret after a user-driven reformat inserts/removes separators.
  useLayoutEffect(() => {
    if (caretRef.current != null && nodeRef.current) {
      const pos = caretRef.current;
      caretRef.current = null;
      nodeRef.current.setSelectionRange(pos, pos);
    }
  });

  const handleChange = (event) => {
    const el = event.target;
    const digitsLeft = countDigits(el.value, el.selectionStart ?? el.value.length);
    const formatted = formatNumberInput(el.value);
    caretRef.current = caretAfterDigits(formatted, digitsLeft);
    setDisplay(formatted);
    onChange?.(unformatNumber(formatted));
  };

  const { inputProps, ...rest } = other;

  return (
    <TextField
      {...rest}
      value={display}
      onChange={handleChange}
      inputRef={setNode}
      type="text"
      inputProps={{ inputMode: 'decimal', ...inputProps }}
    />
  );
}
