import { Box, Button, Tooltip, IconButton } from '@mui/material';

import { Iconify } from 'src/components/iconify';
import { usePopover, CustomPopover } from 'src/components/custom-popover';
import { ActionsCell, ACTION_PRIMARY } from 'src/components/async-data-grid';

import { ActionIconButton } from './action-icon-button';
import { useActionConfirm } from './use-action-confirm';

// ----------------------------------------------------------------------

/**
 * DataGrid row-actions cell — the users-list pattern: one or two prominent
 * inline circular buttons plus an optional overflow trigger opening a
 * CustomPopover with a vertical list of labeled buttons. Wraps everything in
 * the design-system ActionsCell so buttons respond on the first click inside
 * MUI DataGrid cells.
 *
 * Props:
 * - `row`           : the grid row, passed to every onClick.
 * - `inlineActions` : [{ key?, icon, title, color?, sx?, hidden?, disabled?,
 *                       onClick(row) }] — rendered as ActionIconButtons.
 *                     `color` defaults to 'error' (the app's red pencil,
 *                     ACTION_DANGER); `sx` merges over the preset.
 * - `menuActions`   : ActionDef[] — { key, label, icon, color?, hidden?,
 *                     disabled?, confirm?, onClick(row) }. When at least one
 *                     is visible, an ACTION_PRIMARY trigger opens the popover.
 * - `menuIcon`      : Iconify name of the trigger glyph (default kebab
 *                     'material-symbols:menu-rounded').
 * - `menuTooltip`   : tooltip on the trigger (default "Plus d'actions").
 * - `sx`            : sx forwarded to the ActionsCell wrapper.
 *
 * Behaviour: the popover auto-closes before invoking; `confirm` on a menu
 * action routes through the confirm dialog (app <ConfirmProvider> when
 * mounted, self-contained fallback otherwise). Renders null when every action
 * is hidden.
 */
/**
 * One prominent inline circular action.
 *
 * @template R Type of the grid row handed to `onClick`.
 * @typedef {object} RowActionsCellInlineAction
 * @property {string} [key] React key. Falls back to `title`.
 * @property {string} icon Iconify icon name.
 * @property {import('react').ReactNode} [title] Tooltip / accessible name.
 * @property {'default' | 'primary' | 'success' | 'info' | 'warning' | 'error'} [color] Defaults to `'error'`.
 * @property {import('@mui/material').SxProps<import('@mui/material').Theme>} [sx] Merged over the preset.
 * @property {boolean} [hidden]
 * @property {boolean} [disabled]
 * @property {(row: R) => void | Promise<unknown>} [onClick]
 */

/**
 * One labelled action of the overflow popover.
 *
 * @template R Type of the grid row handed to `onClick`.
 * @typedef {object} RowActionsCellMenuAction
 * @property {string} [key] React key. Falls back to `label`.
 * @property {import('react').ReactNode} label
 * @property {string} [icon] Iconify icon name.
 * @property {'default' | 'primary' | 'success' | 'info' | 'warning' | 'error'} [color]
 * @property {boolean} [hidden]
 * @property {boolean} [disabled]
 * @property {import('./detail-header-actions').ActionButtonConfirmOptions} [confirm]
 * @property {(row: R) => void | Promise<unknown>} [onClick]
 */

/**
 * Props of {@link RowActionsCell}.
 *
 * Both action arrays accept falsy holes so call sites can write
 * `cond && { ... }` inline.
 *
 * @template R Type of the grid row.
 * @typedef {object} RowActionsCellProps
 * @property {R} [row] The grid row, passed to every `onClick`.
 * @property {(RowActionsCellInlineAction<R> | false | null | undefined)[]} [inlineActions] Defaults to `[]`.
 * @property {(RowActionsCellMenuAction<R> | false | null | undefined)[]} [menuActions] Defaults to `[]`.
 * @property {string} [menuIcon] Iconify name of the overflow trigger. Defaults to the kebab glyph.
 * @property {import('react').ReactNode} [menuTooltip] Defaults to `"Plus d'actions"`.
 * @property {import('@mui/material').SxProps<import('@mui/material').Theme>} [sx] Forwarded to the `ActionsCell` wrapper.
 */

/**
 * DataGrid row-actions cell: inline circular buttons plus an optional overflow
 * popover. Returns `null` when every action is hidden.
 *
 * @template R
 * @param {RowActionsCellProps<R>} props
 * @returns {import('react').JSX.Element | null}
 */
export function RowActionsCell({
  row,
  inlineActions = [],
  menuActions = [],
  menuIcon = 'material-symbols:menu-rounded',
  menuTooltip = "Plus d'actions",
  sx,
}) {
  const popover = usePopover();
  const { confirmAction, confirmDialog } = useActionConfirm();

  const inline = inlineActions.filter((action) => action && !action.hidden);
  const menu = menuActions.filter((action) => action && !action.hidden);

  if (inline.length === 0 && menu.length === 0) return null;

  const handleMenuClick = (action) => async () => {
    popover.onClose();
    if (action.confirm) {
      const ok = await confirmAction(action.confirm);
      if (!ok) return;
    }
    await action.onClick?.(row);
  };

  return (
    <ActionsCell sx={{ gap: 1, ...sx }}>
      {inline.map((action) => (
        <ActionIconButton
          key={action.key ?? action.title}
          title={action.title}
          icon={action.icon}
          color={action.color ?? 'error'}
          iconWidth={20}
          disabled={action.disabled}
          sx={action.sx}
          onClick={() => action.onClick?.(row)}
        />
      ))}

      {menu.length > 0 && (
        <>
          <Tooltip title={menuTooltip}>
            <IconButton sx={ACTION_PRIMARY} onClick={popover.onOpen}>
              <Iconify icon={menuIcon} width={20} />
            </IconButton>
          </Tooltip>

          <CustomPopover
            open={popover.open}
            anchorEl={popover.anchorEl}
            onClose={popover.onClose}
            arrow="right-top"
            sx={{ width: 'auto', minWidth: 240, '& .MuiButton-root': { whiteSpace: 'nowrap' } }}
          >
            <Box sx={{ p: 0.5, display: 'flex', flexDirection: 'column' }}>
              {menu.map((action) => (
                <Button
                  key={action.key ?? action.label}
                  fullWidth
                  color={action.color && action.color !== 'default' ? action.color : 'inherit'}
                  disabled={action.disabled}
                  sx={{ justifyContent: 'flex-start' }}
                  startIcon={action.icon ? <Iconify icon={action.icon} /> : null}
                  onClick={handleMenuClick(action)}
                >
                  {action.label}
                </Button>
              ))}
            </Box>
          </CustomPopover>
        </>
      )}

      {confirmDialog}
    </ActionsCell>
  );
}
