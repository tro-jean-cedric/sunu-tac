import { Tooltip, IconButton } from '@mui/material';

import { Iconify } from 'src/components/iconify';

import { actionIconSx } from './action-colors';

// ----------------------------------------------------------------------

/**
 * Filled circular tooltip'd action button — the v2 signature action chrome
 * (drawer headers, DataGrid rows). Coloured background, soft shadow, hover
 * lifts and swaps to black (black swaps to primary).
 *
 * Props:
 * - `title`      : tooltip text (also the accessible name). Optional.
 * - `icon`       : Iconify icon name, e.g. 'solar:pen-2-bold'.
 * - `color`      : 'default' | 'primary' | 'success' | 'info' | 'warning' | 'error'
 *                  ('default' = black; unknown values fall back to it).
 * - `size`       : button diameter in px (default 36).
 * - `iconWidth`  : glyph size in px (default size / 2, i.e. 18 for 36).
 * - `onClick`    : click handler.
 * - `disabled`   : disables the button (grey chrome, tooltip still shown).
 * - `sx`         : extra sx merged over the palette preset.
 */

/**
 * Colour presets of the filled circular action buttons.
 *
 * @typedef {'default' | 'primary' | 'success' | 'info' | 'warning' | 'error'} ActionButtonColor
 */

/**
 * Own props of {@link ActionIconButton}. Everything else — including the
 * polymorphic `component` prop and its target's props (e.g.
 * `component={RouterLink} to="/import"`) — is forwarded to MUI's `IconButton`.
 *
 * @typedef {object} ActionIconButtonOwnProps
 * @property {import('react').ReactNode} [title] Tooltip text and accessible name. Without it no tooltip is rendered.
 * @property {string} icon Iconify icon name, e.g. `'solar:pen-2-bold'`.
 * @property {ActionButtonColor} [color] Defaults to `'default'` (black).
 * @property {number} [size] Button diameter in px. Defaults to `36`.
 * @property {number} [iconWidth] Glyph size in px. Defaults to `size / 2`.
 * @property {boolean} [disabled] Defaults to `false`.
 * @property {import('@mui/material').SxProps<import('@mui/material').Theme>} [sx] Merged over the palette preset.
 */

/**
 * @template {import('react').ElementType} [C='button']
 * @typedef {ActionIconButtonOwnProps &
 *   Omit<import('@mui/material').IconButtonProps<C, { component?: C }>, 'color' | 'size' | 'title' | 'sx'>} ActionIconButtonProps
 */

/**
 * Filled circular tooltip'd action button.
 *
 * @template {import('react').ElementType} [C='button']
 * @param {ActionIconButtonProps<C>} props
 * @returns {import('react').JSX.Element}
 */
export function ActionIconButton({
  title,
  icon,
  color = 'default',
  size = 36,
  iconWidth,
  onClick,
  disabled = false,
  sx,
  ...other
}) {
  const button = (
    <IconButton
      onClick={onClick}
      disabled={disabled}
      sx={{ ...actionIconSx(color, size), ...sx }}
      {...other}
    >
      <Iconify icon={icon} width={iconWidth ?? Math.round(size / 2)} />
    </IconButton>
  );

  if (!title) return button;

  // A disabled button fires no events, so Tooltip needs a live wrapper.
  return (
    <Tooltip title={title}>
      {disabled ? <span style={{ display: 'inline-flex' }}>{button}</span> : button}
    </Tooltip>
  );
}
