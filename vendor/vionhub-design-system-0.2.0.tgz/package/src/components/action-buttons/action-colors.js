// Named palette for the filled circular action buttons — the same look and
// feel as the async-data-grid row action constants (ACTION_BLACK /
// ACTION_PRIMARY / ACTION_WARNING / ACTION_DANGER): coloured bg, white glyph,
// soft shadow, hover lifts (translateY(-1px)) and swaps to black — except
// 'default' (black) which hovers to primary. 'warning' keeps a black glyph on
// the yellow background.

export const ACTION_COLORS = {
  default: { bg: 'common.black', hover: 'primary.main' },
  primary: { bg: 'primary.main', hover: 'common.black' },
  success: { bg: 'success.main', hover: 'common.black' },
  info: { bg: 'info.main', hover: 'common.black' },
  warning: { bg: '#f5c928', hover: 'common.black', fg: 'common.black' },
  error: { bg: '#cb3b2a', hover: 'common.black' },
};

// Builds the sx for one circular action button. Unknown colors fall back to
// 'default' (black). `size` is the button diameter in px (36 in the app).
export function actionIconSx(color = 'default', size = 36) {
  const { bg, hover, fg = 'common.white' } = ACTION_COLORS[color] ?? ACTION_COLORS.default;
  return {
    bgcolor: bg,
    color: fg,
    borderRadius: '50%',
    width: size,
    height: size,
    p: 0,
    boxShadow: '0 4px 10px rgba(0,0,0,0.18)',
    transition: 'background-color 0.2s ease, transform 0.15s ease',
    '&:hover': {
      bgcolor: hover,
      color: 'common.white',
      transform: 'translateY(-1px)',
      boxShadow: '0 6px 14px rgba(0,0,0,0.22)',
    },
    '&.Mui-disabled': {
      bgcolor: 'action.disabledBackground',
      color: 'action.disabled',
      boxShadow: 'none',
    },
  };
}
