import { useState } from 'react';

import {
  Menu,
  Tooltip,
  Divider,
  MenuItem,
  IconButton,
  ListItemIcon,
  ListItemText,
} from '@mui/material';

import { Iconify } from 'src/components/iconify';
import { ACTION_PRIMARY } from 'src/components/async-data-grid';

import { useActionConfirm } from './use-action-confirm';

// ----------------------------------------------------------------------

/**
 * Row overflow menu — the v2 "Plus d'actions" dropdown used on request and
 * purchase-order rows. One declarative ActionDef list replaces the app's
 * hand-written MenuItem + Divider chains: dividers are inserted automatically
 * between non-empty groups, hidden items are skipped, and the whole trigger
 * renders null when nothing remains.
 *
 * ActionDef: { key, label, icon,
 *              color?: 'default'|'primary'|'success'|'info'|'warning'|'error',
 *              hidden?, disabled?,
 *              confirm?: { title, message, confirmText, cancelText, color },
 *              onClick: (context) => void|Promise }
 *
 * Props:
 * - `context`        : opaque value (usually the row) passed to every onClick.
 * - `groups`         : ActionDef[][] — one array per menu section (a flat
 *                      ActionDef[] is accepted and treated as one group).
 * - `triggerIcon`    : Iconify name of the trigger glyph (default kebab
 *                      'material-symbols:menu-rounded').
 * - `triggerTooltip` : tooltip on the trigger (default "Plus d'actions").
 * - `triggerSx`      : extra sx merged over the ACTION_PRIMARY preset.
 *
 * Behaviour: clicking an item closes the menu first, then (if `confirm` is
 * set) routes through the confirm dialog — the app-level <ConfirmProvider>
 * when mounted, a self-contained fallback otherwise — then calls
 * onClick(context). Items with a non-default `color` are tinted (label +
 * glyph), matching the app's error/success items.
 */
export function RowActionsMenu({
  context,
  groups = [],
  triggerIcon = 'material-symbols:menu-rounded',
  triggerTooltip = "Plus d'actions",
  triggerSx,
}) {
  const [anchor, setAnchor] = useState(null);
  const { confirmAction, confirmDialog } = useActionConfirm();

  // Accept a flat list as a single group, drop hidden items and empty groups.
  const groupList = (groups.some(Array.isArray) ? groups : [groups])
    .map((group) => (group ?? []).filter((action) => action && !action.hidden))
    .filter((group) => group.length > 0);

  if (groupList.length === 0) return null;

  const open = Boolean(anchor);
  const close = () => setAnchor(null);

  const handleClick = (action) => async () => {
    close();
    if (action.confirm) {
      const ok = await confirmAction(action.confirm);
      if (!ok) return;
    }
    await action.onClick?.(context);
  };

  const items = [];
  groupList.forEach((group, groupIndex) => {
    if (groupIndex > 0) items.push(<Divider key={`divider-${groupIndex}`} />);
    group.forEach((action) => {
      const tint =
        action.color && action.color !== 'default' ? `${action.color}.main` : undefined;
      items.push(
        <MenuItem
          key={action.key ?? action.label}
          onClick={handleClick(action)}
          disabled={action.disabled}
          sx={tint ? { color: tint } : undefined}
        >
          <ListItemIcon>
            <Iconify icon={action.icon} width={18} sx={tint ? { color: tint } : undefined} />
          </ListItemIcon>
          <ListItemText>{action.label}</ListItemText>
        </MenuItem>
      );
    });
  });

  return (
    <>
      <Tooltip title={triggerTooltip}>
        <IconButton sx={{ ...ACTION_PRIMARY, ...triggerSx }} onClick={(e) => setAnchor(e.currentTarget)}>
          <Iconify icon={triggerIcon} width={18} />
        </IconButton>
      </Tooltip>

      <Menu anchorEl={anchor} open={open} onClose={close}>
        {items}
      </Menu>

      {confirmDialog}
    </>
  );
}
