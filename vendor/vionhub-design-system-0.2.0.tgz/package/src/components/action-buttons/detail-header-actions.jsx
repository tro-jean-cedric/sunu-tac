import { Stack, Button } from '@mui/material';

import { Iconify } from 'src/components/iconify';

import { ActionIconButton } from './action-icon-button';
import { useActionConfirm } from './use-action-confirm';

// ----------------------------------------------------------------------

/**
 * Horizontal action row for detail headers — the same ActionDef array rendered
 * either as small contextual Buttons (the purchase-order details dialog
 * toolbar) or, with `asIcons`, as filled circular ActionIconButtons (the
 * request detail drawer header).
 *
 * ActionDef: { key, label, icon,
 *              color?: 'default'|'primary'|'success'|'info'|'warning'|'error',
 *              variant?: 'contained'|'outlined'|'text'  (buttons mode only,
 *                        default 'contained'),
 *              hidden?, disabled?,
 *              confirm?: { title, message, confirmText, cancelText, color },
 *              onClick: (context) => void|Promise }
 *
 * Props:
 * - `actions`      : ActionDef[] — hidden ones are skipped; renders null when
 *                    none remain.
 * - `context`      : opaque value (usually the entity) passed to onClick.
 * - `beforeAction` : (action, context) => void, run before each onClick —
 *                    default no-op; callers pass onClose for the
 *                    close-then-delegate pattern of the app's headers.
 * - `size`         : Button size in buttons mode (default 'small').
 * - `asIcons`      : render ActionIconButtons instead of Buttons.
 * - `spacing`      : Stack spacing (default 2 with asIcons — the drawer — and
 *                    1 in buttons mode — the dialog toolbar).
 * - `sx`           : sx forwarded to the Stack.
 *
 * Behaviour: when an action carries `confirm`, the confirm dialog is resolved
 * first (app <ConfirmProvider> when mounted, self-contained fallback
 * otherwise); a cancel skips both beforeAction and onClick, so e.g. a drawer
 * only closes once the user has confirmed. Contained buttons without a color
 * take the dark grey.900 look of the app's "Télécharger" button.
 */

const noop = () => {};

const DARK_BUTTON_SX = { bgcolor: 'grey.900', '&:hover': { bgcolor: 'grey.800' } };

/**
 * Confirmation dialog descriptor carried by an action.
 *
 * @typedef {object} ActionButtonConfirmOptions
 * @property {import('react').ReactNode} [title]
 * @property {import('react').ReactNode} [message]
 * @property {string} [confirmText]
 * @property {string} [cancelText]
 * @property {'default' | 'primary' | 'success' | 'info' | 'warning' | 'error'} [color]
 */

/**
 * One action of {@link DetailHeaderActions}.
 *
 * @template C Type of the opaque `context` value handed to `onClick`.
 * @typedef {object} DetailHeaderAction
 * @property {string} [key] React key. Falls back to `label`.
 * @property {import('react').ReactNode} label
 * @property {string} [icon] Iconify icon name.
 * @property {'default' | 'primary' | 'success' | 'info' | 'warning' | 'error'} [color]
 * @property {'contained' | 'outlined' | 'text'} [variant] Buttons mode only. Defaults to `'contained'`.
 * @property {boolean} [hidden] Hidden actions are skipped entirely.
 * @property {boolean} [disabled]
 * @property {ActionButtonConfirmOptions} [confirm] When set, the action is confirmed before running.
 * @property {(context: C) => void | Promise<unknown>} [onClick]
 */

/**
 * Props of {@link DetailHeaderActions}.
 *
 * @template C Type of the opaque `context` value handed to each `onClick`.
 * @typedef {object} DetailHeaderActionsProps
 * @property {(DetailHeaderAction<C> | false | null | undefined)[]} [actions] Defaults to `[]`; falsy holes and hidden actions are skipped.
 * @property {C} [context] Opaque value (usually the entity) passed to `onClick` and `beforeAction`.
 * @property {(action: DetailHeaderAction<C>, context: C) => void} [beforeAction] Runs before each `onClick`. Defaults to a no-op.
 * @property {'small' | 'medium' | 'large'} [size] Button size in buttons mode. Defaults to `'small'`.
 * @property {boolean} [asIcons] Render `ActionIconButton`s instead of `Button`s. Defaults to `false`.
 * @property {number} [spacing] Stack spacing. Defaults to `2` with `asIcons`, `1` otherwise.
 * @property {import('@mui/material').SxProps<import('@mui/material').Theme>} [sx] Forwarded to the `Stack`.
 */

/**
 * Horizontal action row for detail headers.
 *
 * @template C
 * @param {DetailHeaderActionsProps<C>} props
 * @returns {import('react').JSX.Element | null}
 */
export function DetailHeaderActions({
  actions = [],
  context,
  beforeAction = noop,
  size = 'small',
  asIcons = false,
  spacing,
  sx,
}) {
  const { confirmAction, confirmDialog } = useActionConfirm();

  const visible = actions.filter((action) => action && !action.hidden);

  if (visible.length === 0) return null;

  const handleClick = (action) => async () => {
    if (action.confirm) {
      const ok = await confirmAction(action.confirm);
      if (!ok) return;
    }
    beforeAction(action, context);
    await action.onClick?.(context);
  };

  return (
    <>
      <Stack
        direction="row"
        alignItems="center"
        flexWrap="wrap"
        spacing={spacing ?? (asIcons ? 2 : 1)}
        sx={sx}
      >
        {visible.map((action) =>
          asIcons ? (
            <ActionIconButton
              key={action.key ?? action.label}
              title={action.label}
              icon={action.icon}
              color={action.color}
              disabled={action.disabled}
              onClick={handleClick(action)}
            />
          ) : (
            <Button
              key={action.key ?? action.label}
              size={size}
              variant={action.variant ?? 'contained'}
              color={action.color && action.color !== 'default' ? action.color : 'inherit'}
              disabled={action.disabled}
              startIcon={action.icon ? <Iconify icon={action.icon} /> : null}
              onClick={handleClick(action)}
              sx={
                (action.variant ?? 'contained') === 'contained' &&
                (!action.color || action.color === 'default')
                  ? DARK_BUTTON_SX
                  : undefined
              }
            >
              {action.label}
            </Button>
          )
        )}
      </Stack>

      {confirmDialog}
    </>
  );
}
