// Colocated: styles travel with the component so subpath consumers
// (`@vionhub/design-system/components`) get them without importing global.css.
import './styles.css';

import ApexChart from 'react-apexcharts';

import Box from '@mui/material/Box';

// ----------------------------------------------------------------------

/**
 * Renderer accepted by ApexCharts.
 *
 * @typedef {'line' | 'area' | 'bar' | 'pie' | 'donut' | 'radialBar' | 'scatter'
 *   | 'bubble' | 'heatmap' | 'candlestick' | 'boxPlot' | 'radar' | 'polarArea'
 *   | 'rangeBar' | 'rangeArea' | 'treemap'} ChartType
 */

/**
 * Series data. Three shapes are in real use:
 *   - `{ name, data: (number | null)[] }[]` — axis series with gaps (a `null`
 *     reads as "no value", never as zero);
 *   - `{ name, data: number[] }[]` — plain axis series;
 *   - `number[]` — non-axis series, for `pie` / `donut` / `radialBar` / `polarArea`.
 * The upstream union also covers `{ x, y }` points and tuple pairs.
 *
 * @typedef {NonNullable<import('apexcharts').ApexOptions['series']>} ChartSeries
 */

/**
 * @typedef {object} ChartOwnProps
 * @property {ChartType} type Which renderer to use.
 * @property {ChartSeries} series Data to plot.
 * @property {import('./use-chart').ChartOptions} [options] Usually the result of
 *   `useChart()`. Genuinely optional: omit it and the chart renders with
 *   ApexCharts' own defaults (see the merge in the body — ApexCharts itself
 *   requires an options object carrying `chart.type`, so the component always
 *   builds one).
 * @property {number | string} [width] Width of the wrapper. Defaults to `'100%'`.
 * @property {number | string} [height] Height of the wrapper.
 */

/**
 * Wrapper props. The wrapper is a `Box`, so `sx` and every other Box prop pass
 * through; `width`/`height` are taken over by the own props above because the
 * chart needs concrete values, not responsive system values.
 *
 * @typedef {ChartOwnProps & Omit<import('@mui/material').BoxProps, 'width' | 'height' | 'children'>} ChartProps
 */

/**
 * @param {ChartProps} props
 * @returns {import('react').JSX.Element}
 */
export function Chart({ sx, type, series, height, options, width = '100%', ...other }) {
  // `options` is optional on this component but NOT optional to ApexCharts:
  // react-apexcharts declares it a required object prop and merges it with
  // `{ chart: { type, height, width } }` through a merge that bails out when
  // the left-hand side is not an object — so `options={undefined}` reaches
  // apexcharts as a config with no `chart`, and it throws
  // "Cannot read properties of undefined (reading 'type')".
  //
  // `options = {}` is not enough either, for the same reason the merge is
  // there: apexcharts wants `chart.type`. So build the object here — the
  // caller's options win, and `chart.type` is filled in from the `type` prop
  // when the caller has not set one.
  const chartOptions = {
    ...options,
    chart: { type, ...options?.chart },
  };

  return (
    <Box
      dir="ltr"
      sx={{
        width,
        height,
        flexShrink: 0,
        borderRadius: 1.5,
        position: 'relative',
        ...sx,
      }}
      {...other}
    >
      <ApexChart type={type} series={series} options={chartOptions} width="100%" height="100%" />
    </Box>
  );
}
