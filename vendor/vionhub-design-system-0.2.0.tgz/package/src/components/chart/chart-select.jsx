import MenuItem from '@mui/material/MenuItem';
import MenuList from '@mui/material/MenuList';
import ButtonBase from '@mui/material/ButtonBase';

import { varAlpha } from 'src/theme/styles';

import { Iconify } from 'src/components/iconify';

import { usePopover, CustomPopover } from '../custom-popover';

// ----------------------------------------------------------------------

/**
 * @typedef {object} ChartSelectOwnProps
 * @property {string[]} options Values offered in the popover menu. Required,
 *   but an empty array is tolerated — the popover then opens empty rather than
 *   throwing, which is what a not-yet-loaded option list looks like.
 * @property {string} [value] Currently selected value, rendered on the button.
 * @property {(newValue: string) => void} onChange Called with the picked option.
 * @property {{
 *   button?: import('@mui/material').SxProps<import('@mui/material').Theme>,
 *   popover?: import('@mui/material').SxProps<import('@mui/material').Theme>,
 * }} [slotProps]
 */

/** @typedef {ChartSelectOwnProps & Omit<import('@mui/material').ButtonBaseProps, 'onChange' | 'children'>} ChartSelectProps */

/**
 * @param {ChartSelectProps} props
 * @returns {import('react').JSX.Element}
 */
export function ChartSelect({ options = [], value, onChange, slotProps, ...other }) {
  const popover = usePopover();

  return (
    <>
      <ButtonBase
        onClick={popover.onOpen}
        sx={{
          pr: 1,
          pl: 1.5,
          gap: 1.5,
          height: 34,
          borderRadius: 1,
          typography: 'subtitle2',
          border: (theme) => `solid 1px ${varAlpha(theme.vars.palette.grey['500Channel'], 0.24)}`,
          ...slotProps?.button,
        }}
        {...other}
      >
        {value}

        <Iconify
          width={16}
          icon={popover.open ? 'eva:arrow-ios-upward-fill' : 'eva:arrow-ios-downward-fill'}
        />
      </ButtonBase>

      <CustomPopover open={popover.open} anchorEl={popover.anchorEl} onClose={popover.onClose}>
        <MenuList sx={slotProps?.popover}>
          {options.map((option) => (
            <MenuItem
              key={option}
              selected={option === value}
              onClick={() => {
                popover.onClose();
                onChange(option);
              }}
            >
              {option}
            </MenuItem>
          ))}
        </MenuList>
      </CustomPopover>
    </>
  );
}
