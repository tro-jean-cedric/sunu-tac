import useMediaQuery from '@mui/material/useMediaQuery';
import { useTheme } from '@mui/material/styles';

import { varAlpha } from 'src/theme/styles';
import { chart as chartPalette } from 'src/theme/core/palette';
// Deep import on purpose: the `src/components/animate` barrel pulls in
// framer-motion, and a chart must not carry that. `variants/transition` has no
// imports of its own.
import { motionDurations } from 'src/components/animate/variants/transition';

// ----------------------------------------------------------------------

/**
 * ApexCharts animation timings.
 *
 * `speed` and `animateGradually.delay` are the values this library has always
 * shipped and are deliberately unchanged — they are chart-specific and have no
 * equivalent in `motionDurations` (the closest token, `progress` 600ms, is a
 * bar filling from zero, not a series draw-in). FOLLOW-UP: fold a `chart` entry
 * into `motionDurations` and delete these two constants, so a consumer retiming
 * motion retimes charts with it.
 *
 * The reduced-motion speed IS a token: `motionDurations.micro`, the same 180ms
 * the rest of the system uses for a data swap.
 */
const CHART_ANIMATION = {
  speed: 360,
  graduallyDelay: 120,
  reducedSpeed: motionDurations.micro,
};

/**
 * Context object ApexCharts passes as the second argument to axis and tooltip
 * formatters. Only the members that callers actually read are described; the
 * chart instance (`w`) is opaque third-party state.
 *
 * @typedef {object} ChartFormatterContext
 * @property {number} dataPointIndex Index of the hovered/rendered point.
 * @property {number} [seriesIndex] Index of the series the point belongs to.
 * @property {unknown} [w] Internal ApexCharts state — treat as opaque.
 */

/**
 * Tooltip y-value formatter block.
 *
 * The upstream `ApexTooltipY['formatter']` declares the value as `number`, but
 * ApexCharts really passes `null` for gaps in a series (a month with no
 * objective, an un-closed period, …) and call sites must be able to render
 * those as text. The value is therefore widened to `number | null`.
 *
 * The formatters are declared with method syntax on purpose: like upstream,
 * that keeps their parameters bivariant, so a call site that only handles
 * `number` is still accepted.
 *
 * @typedef {{
 *   title?: { formatter?(seriesName: string): string },
 *   formatter?(value: number | null, opts?: ChartFormatterContext): string,
 * }} ChartTooltipY
 */

/**
 * Tooltip x-value formatter block.
 *
 * ApexCharts passes the raw category — a string for a category axis, a number
 * for a numeric/datetime axis — so both shapes are accepted.
 *
 * @typedef {{
 *   show?: boolean,
 *   format?: string,
 *   formatter?(value: string | number, opts?: ChartFormatterContext): string,
 * }} ChartTooltipX
 */

/**
 * Tooltip options: the upstream `ApexTooltip` with `x` and `y` replaced by the
 * widened formatter blocks above. Everything else is unchanged.
 *
 * @typedef {Omit<NonNullable<import('apexcharts').ApexOptions['tooltip']>, 'x' | 'y'> & {
 *   x?: ChartTooltipX,
 *   y?: ChartTooltipY | ChartTooltipY[],
 * }} ChartTooltipOptions
 */

/**
 * The full ApexCharts option surface accepted by {@link useChart} and by the
 * `options` prop of `Chart`, with the tooltip formatters widened (see
 * {@link ChartTooltipOptions}).
 *
 * @typedef {Omit<import('apexcharts').ApexOptions, 'tooltip'> & {
 *   tooltip?: ChartTooltipOptions,
 * }} ChartOptions
 */

/**
 * Merge caller options over the design system's ApexCharts defaults.
 *
 * Every block is merged shallowly per section, so a caller that passes
 * `chart.animations` overrides only the animation defaults and keeps the rest.
 *
 * @param {ChartOptions} [options] Caller options, merged over the defaults.
 * @returns {ChartOptions} Options ready to hand to the `Chart` component.
 */
export function useChart(options) {
  const theme = useTheme();

  // Reactive: a chart already on screen restarts honouring the new preference
  // when the OS setting flips. `useMediaQuery` returns false during SSR and in
  // a non-DOM environment, i.e. animations stay on — the same default as before.
  const reducedMotion = useMediaQuery('(prefers-reduced-motion: reduce)');

  // `theme.palette` is already resolved to the active color scheme by
  // CssVarsProvider, so `palette.chart` is the right ramp for the current mode.
  // The fallback covers a consumer who passes a theme built without this
  // library's palette: read the mode off that theme and pick the ramp directly.
  const chartTokens =
    theme.palette.chart ?? (theme.palette.mode === 'dark' ? chartPalette.dark : chartPalette.light);

  const LABEL_TOTAL = {
    show: true,
    label: 'Total',
    color: theme.vars.palette.text.secondary,
    fontSize: theme.typography.subtitle2.fontSize,
    fontWeight: theme.typography.subtitle2.fontWeight,
  };

  const LABEL_VALUE = {
    offsetY: 8,
    color: theme.vars.palette.text.primary,
    fontSize: theme.typography.h4.fontSize,
    fontWeight: theme.typography.h4.fontWeight,
  };

  const RESPONSIVE = [
    {
      breakpoint: theme.breakpoints.values.sm, // sm ~ 600
      options: {
        plotOptions: {
          bar: {
            borderRadius: 3,
            columnWidth: '80%',
          },
        },
      },
    },
    {
      breakpoint: theme.breakpoints.values.md, // md ~ 900
      options: {
        plotOptions: {
          bar: {
            columnWidth: '60%',
          },
        },
      },
    },
    ...(options?.responsive ?? []),
  ];

  return {
    ...options,

    /** **************************************
     * Chart
     *************************************** */
    chart: {
      toolbar: {
        show: false,
      },
      zoom: {
        enabled: false,
      },
      parentHeightOffset: 0,
      fontFamily: theme.typography.fontFamily,
      foreColor: theme.vars.palette.text.disabled,
      ...options?.chart,
      // Reduced motion: the series draw-in and the per-series stagger are the
      // parts that actually move, so both are switched off and the chart paints
      // in its final state. A caller's own `chart.animations` still wins — the
      // spread is last — which is how you force motion back on.
      animations: reducedMotion
        ? {
            enabled: false,
            speed: CHART_ANIMATION.reducedSpeed,
            animateGradually: { enabled: false, delay: 0 },
            dynamicAnimation: { enabled: false, speed: CHART_ANIMATION.reducedSpeed },
            ...options?.chart?.animations,
          }
        : {
            enabled: true,
            speed: CHART_ANIMATION.speed,
            animateGradually: { enabled: true, delay: CHART_ANIMATION.graduallyDelay },
            dynamicAnimation: { enabled: true, speed: CHART_ANIMATION.speed },
            ...options?.chart?.animations,
          },
    },

    /** **************************************
     * Colors
     *************************************** */
    // The CATEGORICAL ramp, not the role palette. A series index carries
    // identity, not meaning: colouring series 4 with `error.main` told every
    // reader something was wrong when nothing was. See `ThemeChartPalette` in
    // src/theme/core/palette.js for the measurements behind the five hues.
    //
    // Five slots, in fixed order, never cycled. ApexCharts wraps a sixth series
    // back to index 0 — if you have six series, fold the tail into "Other" or
    // split the chart rather than relying on that wrap.
    // Copied, not passed by reference: `chartTokens.categorical` is a
    // module-level array shared by every chart on the page, and ApexCharts is
    // third-party code we do not want holding a handle on it.
    colors: options?.colors ?? [...chartTokens.categorical],

    /** **************************************
     * States
     *************************************** */
    states: {
      ...options?.states,
      hover: {
        ...options?.states?.hover,
        filter: {
          type: 'darken',
          value: 0.88,
          ...options?.states?.hover?.filter,
        },
      },
      active: {
        ...options?.states?.active,
        filter: {
          type: 'darken',
          value: 0.88,
          ...options?.states?.active?.filter,
        },
      },
    },

    /** **************************************
     * Fill
     *************************************** */
    fill: {
      opacity: 1,
      ...options?.fill,
      gradient: {
        type: 'vertical',
        shadeIntensity: 0,
        opacityFrom: 0.4,
        opacityTo: 0,
        stops: [0, 100],
        ...options?.fill?.gradient,
      },
    },

    /** **************************************
     * Data labels
     *************************************** */
    dataLabels: {
      enabled: false,
      ...options?.dataLabels,
    },

    /** **************************************
     * Stroke
     *************************************** */
    stroke: {
      width: 2.5,
      curve: 'smooth',
      lineCap: 'round',
      ...options?.stroke,
    },

    /** **************************************
     * Grid
     *************************************** */
    grid: {
      strokeDashArray: 3,
      borderColor: theme.vars.palette.divider,
      ...options?.grid,
      padding: {
        top: 0,
        right: 0,
        bottom: 0,
        ...options?.grid?.padding,
      },
      xaxis: {
        lines: {
          show: false,
        },
        ...options?.grid?.xaxis,
      },
    },

    /** **************************************
     * Axis
     *************************************** */
    xaxis: {
      axisBorder: {
        show: false,
      },
      axisTicks: {
        show: false,
      },
      ...options?.xaxis,
    },
    yaxis: {
      tickAmount: 5,
      ...options?.yaxis,
    },

    /** **************************************
     * Markers
     *************************************** */
    markers: {
      size: 0,
      strokeColors: theme.vars.palette.background.paper,
      ...options?.markers,
    },

    /** **************************************
     * Tooltip
     *************************************** */
    tooltip: {
      theme: 'false',
      fillSeriesColor: false,
      x: {
        show: true,
      },
      ...options?.tooltip,
    },

    /** **************************************
     * Legend
     *************************************** */
    legend: {
      show: false,
      position: 'top',
      fontWeight: 500,
      fontSize: '13px',
      horizontalAlign: 'right',
      markers: { radius: 12 },
      labels: {
        colors: theme.vars.palette.text.primary,
      },
      ...options?.legend,
      itemMargin: {
        horizontal: 8,
        vertical: 8,
        ...options?.legend?.itemMargin,
      },
    },

    /** **************************************
     * plotOptions
     *************************************** */
    plotOptions: {
      ...options?.plotOptions,
      // plotOptions: Bar
      bar: {
        borderRadius: 4,
        columnWidth: '48%',
        borderRadiusApplication: 'end',
        ...options?.plotOptions?.bar,
      },

      // plotOptions: Pie + Donut
      pie: {
        ...options?.plotOptions?.pie,
        donut: {
          ...options?.plotOptions?.pie?.donut,
          labels: {
            show: true,
            ...options?.plotOptions?.pie?.donut?.labels,
            value: {
              ...LABEL_VALUE,
              ...options?.plotOptions?.pie?.donut?.labels?.value,
            },
            total: {
              ...LABEL_TOTAL,
              ...options?.plotOptions?.pie?.donut?.labels?.total,
            },
          },
        },
      },

      // plotOptions: Radialbar
      radialBar: {
        ...options?.plotOptions?.radialBar,
        hollow: {
          margin: -8,
          size: '100%',
          ...options?.plotOptions?.radialBar?.hollow,
        },
        track: {
          margin: -8,
          strokeWidth: '50%',
          background: varAlpha(theme.vars.palette.grey['500Channel'], 0.16),
          ...options?.plotOptions?.radialBar?.track,
        },
        dataLabels: {
          ...options?.plotOptions?.radialBar?.dataLabels,
          value: {
            ...LABEL_VALUE,
            ...options?.plotOptions?.radialBar?.dataLabels?.value,
          },
          total: {
            ...LABEL_TOTAL,
            ...options?.plotOptions?.radialBar?.dataLabels?.total,
          },
        },
      },

      // plotOptions: Radar
      radar: {
        ...options?.plotOptions?.radar,
        polygons: {
          fill: {
            colors: ['transparent'],
          },
          strokeColors: theme.vars.palette.divider,
          connectorColors: theme.vars.palette.divider,
          ...options?.plotOptions?.radar?.polygons,
        },
      },

      // plotOptions: polarArea
      polarArea: {
        rings: {
          strokeColor: theme.vars.palette.divider,
        },
        spokes: {
          connectorColors: theme.vars.palette.divider,
        },
        ...options?.plotOptions?.polarArea,
      },

      // plotOptions: heatmap
      heatmap: {
        distributed: true,
        ...options?.plotOptions?.heatmap,
      },
    },

    /** **************************************
     * Responsive
     *************************************** */
    responsive: RESPONSIVE.reduce((acc, cur) => {
      if (!acc.some((item) => item.breakpoint === cur.breakpoint)) {
        acc.push(cur);
      }
      return acc;
    }, []),
  };
}
