import {DotLottieReact} from '@lottiefiles/dotlottie-react';

import Box from '@mui/material/Box';
import Stack from '@mui/material/Stack';
import Typography from '@mui/material/Typography';

import {varAlpha} from 'src/theme/styles';


// ----------------------------------------------------------------------

// Default animation shown when no `lottieSrc` is provided. Remote URL — hosts
// with strict CSP/offline constraints should pass their own `lottieSrc`.
const DEFAULT_LOTTIE_SRC =
  'https://lottie.host/e9ff2501-3ff2-4c94-ab1b-6f8e470ed18d/oZiv65IsQA.lottie';

export function EmptyContent({
                               sx, imgUrl, action, filled, slotProps, description, title = 'No data', lottieSrc = DEFAULT_LOTTIE_SRC, ...other
                             }) {
  return (<Stack
    flexGrow={1}
    alignItems="center"
    justifyContent="center"
    sx={{
      px: 3, height: 1,
      ...(filled && {
        borderRadius: 2, bgcolor: (theme) => varAlpha(theme.vars.palette.grey['500Channel'], 0.04), border: (theme) => `dashed 1px ${varAlpha(theme.vars.palette.grey['500Channel'], 0.08)}`,
      }), ...sx,
    }}
    {...other}
  >
    <Box sx={{height: '20em'}}>
      <DotLottieReact src={lottieSrc} loop autoplay />
    </Box>

    {title && (<Typography
      variant="h6"
      component="span"
      sx={{
        mt: 1, textAlign: 'center', ...slotProps?.title, color: 'text.disabled',
      }}
    >
      {title}
    </Typography>)}

    {description && (<Typography
      variant="caption"
      sx={{
        mt: 1, textAlign: 'center', color: 'text.disabled', ...slotProps?.description,
      }}
    >
      {description}
    </Typography>)}

    {action && action}
  </Stack>);
}
