// Colocated: styles travel with the component so subpath consumers
// (`@vionhub/design-system/components`) get them without importing global.css.
import './styles.css';

import { forwardRef } from 'react';
import SimpleBar from 'simplebar-react';

import Box from '@mui/material/Box';

import { scrollbarClasses } from './classes';

// ----------------------------------------------------------------------

/**
 * Style overrides for the internal SimpleBar slots. Each entry is merged into the
 * root `sx` under the matching `.simplebar-*` selector, so it must be a plain
 * style object (not an array and not a callback).
 *
 * @typedef {object} ScrollbarSlotProps
 * @property {import('@mui/system').SystemStyleObject<import('@mui/material').Theme>} [wrapper]
 * @property {import('@mui/system').SystemStyleObject<import('@mui/material').Theme>} [contentWrapper]
 * @property {import('@mui/system').SystemStyleObject<import('@mui/material').Theme>} [content]
 */

/**
 * Own props of `<Scrollbar />`. Every prop is optional.
 *
 * @typedef {object} ScrollbarOwnProps
 * @property {ScrollbarSlotProps} [slotProps]
 * @property {import('react').ReactNode} [children]
 * @property {boolean} [fillContent] Makes the content area a full-height flex column.
 * @property {boolean} [naturalScroll] Opt out of the custom scrollbar look.
 * @property {import('@mui/material').SxProps<import('@mui/material').Theme>} [sx]
 */

/** @typedef {ScrollbarOwnProps & Omit<import('@mui/material').BoxProps, 'children' | 'ref'>} ScrollbarProps */

/**
 * Custom scrollbar container (SimpleBar) styled with the MUI system.
 *
 * @type {import('react').ForwardRefExoticComponent<ScrollbarProps & import('react').RefAttributes<HTMLDivElement>>}
 */
export const Scrollbar = forwardRef(
  ({ slotProps, children, fillContent, naturalScroll, sx, ...other }, ref) => (
    <Box
      component={SimpleBar}
      scrollableNodeProps={{ ref }}
      clickOnTrack={false}
      className={scrollbarClasses.root}
      sx={{
        minWidth: 0,
        minHeight: 0,
        flexGrow: 1,
        display: 'flex',
        flexDirection: 'column',
        '& .simplebar-wrapper': slotProps?.wrapper,
        '& .simplebar-content-wrapper': slotProps?.contentWrapper,
        '& .simplebar-content': {
          ...(fillContent && {
            minHeight: 1,
            display: 'flex',
            flex: '1 1 auto',
            flexDirection: 'column',
          }),

          ...slotProps?.content,
        },
        ...sx,
      }}
      {...other}
    >
      {children}
    </Box>
  )
);
