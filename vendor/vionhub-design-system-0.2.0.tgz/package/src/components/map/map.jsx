// Colocated: styles travel with the component so subpath consumers
// (`@vionhub/design-system/components`) get them without importing global.css.
import './styles.css';

import MapGL from 'react-map-gl';
import { forwardRef } from 'react';

// ----------------------------------------------------------------------

// The app version hard-coded `mapboxAccessToken={CONFIG.mapbox.apiKey}`.
// In the design-system package the token must be provided by the host app,
// either via the `mapboxAccessToken` prop or the VITE_MAPBOX_API_KEY env var.
const DEFAULT_MAPBOX_TOKEN = import.meta.env?.VITE_MAPBOX_API_KEY ?? '';

export const Map = forwardRef(({ mapboxAccessToken = DEFAULT_MAPBOX_TOKEN, ...other }, ref) => (
  <MapGL ref={ref} mapLib={import('mapbox-gl')} mapboxAccessToken={mapboxAccessToken} {...other} />
));
