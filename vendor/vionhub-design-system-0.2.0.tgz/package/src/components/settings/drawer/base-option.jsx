import Box from '@mui/material/Box';
import Stack from '@mui/material/Stack';
import Switch from '@mui/material/Switch';
import Tooltip from '@mui/material/Tooltip';
import ButtonBase from '@mui/material/ButtonBase';

import { CONFIG } from 'src/config-global';
import { varAlpha } from 'src/theme/styles';

import { Iconify } from 'src/components/iconify';

import { SvgColor } from '../../svg-color';

// ----------------------------------------------------------------------

export function BaseOption({ icon, label, description, tooltip, selected, ...other }) {
  return (
    <ButtonBase
      disableRipple
      sx={(theme) => ({
        p: 2,
        gap: 2,
        height: 1,
        width: 1,
        borderRadius: 2,
        cursor: 'pointer',
        flexDirection: 'column',
        alignItems: 'flex-start',
        justifyContent: 'space-between',
        transition: theme.transitions.create(
          ['background-color', 'border-color', 'box-shadow', 'transform'],
          { duration: theme.transitions.duration.shorter }
        ),
        border: `solid 1px ${varAlpha(theme.vars.palette.grey['500Channel'], 0.16)}`,
        bgcolor: varAlpha(theme.vars.palette.background.defaultChannel, 0.6),
        '&:hover': {
          borderColor: varAlpha(theme.vars.palette.primary.mainChannel, 0.32),
          bgcolor: varAlpha(theme.vars.palette.primary.mainChannel, 0.04),
        },
        ...(selected && {
          borderColor: theme.vars.palette.primary.main,
          bgcolor: varAlpha(theme.vars.palette.primary.mainChannel, 0.08),
          boxShadow: `0 4px 12px -4px ${varAlpha(theme.vars.palette.primary.mainChannel, 0.32)}`,
        }),
      })}
      {...other}
    >
      <Box
        display="flex"
        alignItems="center"
        justifyContent="space-between"
        sx={{ width: 1 }}
      >
        <Box
          sx={(theme) => ({
            width: 36,
            height: 36,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            borderRadius: 1.5,
            color: selected ? 'primary.main' : 'text.secondary',
            bgcolor: selected
              ? varAlpha(theme.vars.palette.primary.mainChannel, 0.12)
              : varAlpha(theme.vars.palette.grey['500Channel'], 0.08),
            transition: theme.transitions.create(['background-color', 'color']),
          })}
        >
          <SvgColor
            src={`${CONFIG.site.basePath}/assets/icons/setting/ic-${icon}.svg`}
            sx={{ width: 20, height: 20 }}
          />
        </Box>
        <Switch
          name={label}
          size="small"
          color="primary"
          checked={selected}
          sx={{ mr: -0.75 }}
        />
      </Box>

      <Stack spacing={0.25} sx={{ width: 1 }}>
        <Box
          display="flex"
          alignItems="center"
          justifyContent="space-between"
          sx={{ width: 1 }}
        >
          <Box
            component="span"
            sx={{
              lineHeight: '20px',
              fontWeight: 'fontWeightSemiBold',
              fontSize: (theme) => theme.typography.pxToRem(13),
              color: 'text.primary',
            }}
          >
            {label}
          </Box>

          {tooltip && (
            <Tooltip
              arrow
              title={tooltip}
              slotProps={{
                tooltip: { sx: { maxWidth: 240, mr: 0.5 } },
              }}
            >
              <Iconify
                width={16}
                icon="eva:info-outline"
                sx={{ cursor: 'pointer', color: 'text.disabled' }}
              />
            </Tooltip>
          )}
        </Box>

        {description && (
          <Box
            component="span"
            sx={{
              textAlign: 'left',
              lineHeight: '16px',
              color: 'text.secondary',
              fontSize: (theme) => theme.typography.pxToRem(11),
            }}
          >
            {description}
          </Box>
        )}
      </Stack>
    </ButtonBase>
  );
}
