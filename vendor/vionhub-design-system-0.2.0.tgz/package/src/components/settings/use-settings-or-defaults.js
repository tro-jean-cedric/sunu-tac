import { useMemo, useContext, useSyncExternalStore } from 'react';

import { defaultSettings } from 'src/settings/config-settings';
import { SettingsContext } from 'src/settings/context/settings-provider';

// ----------------------------------------------------------------------

/**
 * Why this exists.
 *
 * `useSettingsContext()` THROWS when there is no `<SettingsProvider>` above it.
 * Three components call it — `SettingsDrawer`, `DashboardLayout` /
 * `DashboardContent` and the header's `SettingsButton` — and a throw inside a
 * layout is not a recoverable error in React: it unmounts the whole tree, so a
 * consumer who forgot one provider gets a **blank white page** whose only trace
 * is a console stack. `ThemeProvider` already degrades in exactly this
 * situation (`settingsProp ?? settingsContext ?? defaultSettings`); this module
 * gives the remaining consumers the same behaviour, so that a missing provider
 * costs you persistence, not your application.
 *
 * The fallback is a real, mutable store rather than a frozen object: the drawer
 * has toggles, the gear button opens the drawer, and a default that renders
 * dead controls would be its own kind of lie. It is module-level and shared, so
 * the gear button and the drawer still talk to each other without a provider.
 *
 * What you lose without a provider, and what the warning says:
 *   - nothing is persisted to `localStorage` (the state resets on reload);
 *   - `ThemeProvider` reads the *context*, so it keeps using `defaultSettings`
 *     — contrast / nav-colour changes made here do not reach the theme.
 * `<SettingsProvider>` remains the supported way to use these components.
 */

/** @typedef {import('src/settings/config-settings').SettingsState} SettingsState */
/** @typedef {import('src/settings/context/settings-provider').SettingsContextValue} SettingsContextValue */

/** @type {{ settings: SettingsState, openDrawer: boolean }} */
let snapshot = { settings: defaultSettings, openDrawer: false };

/** @type {Set<() => void>} */
const listeners = new Set();

function emit() {
  listeners.forEach((listener) => listener());
}

/** @param {() => void} listener */
function subscribe(listener) {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
}

function getSnapshot() {
  return snapshot;
}

/** @param {Partial<{ settings: SettingsState, openDrawer: boolean }>} patch */
function update(patch) {
  snapshot = { ...snapshot, ...patch };
  emit();
}

const standaloneActions = {
  onReset: () => update({ settings: defaultSettings }),
  /** @param {Partial<SettingsState>} updateValue */
  onUpdate: (updateValue) => update({ settings: { ...snapshot.settings, ...updateValue } }),
  /**
   * @param {keyof SettingsState} name
   * @param {SettingsState[keyof SettingsState]} updateValue
   */
  onUpdateField: (name, updateValue) =>
    update({ settings: { ...snapshot.settings, [name]: updateValue } }),
  onToggleDrawer: () => update({ openDrawer: !snapshot.openDrawer }),
  onCloseDrawer: () => update({ openDrawer: false }),
};

let warned = false;

function warnOnce() {
  if (warned) return;
  warned = true;
  // Deliberately a warning and not a throw: see the note at the top of the file.
  console.warn(
    '[@vionhub/design-system] A settings-aware component (SettingsDrawer, DashboardLayout, ' +
      'DashboardContent or the header settings button) was rendered outside <SettingsProvider>. ' +
      'Falling back to in-memory default settings: the controls work, but nothing is persisted ' +
      'to localStorage and ThemeProvider keeps using defaultSettings, so appearance changes do ' +
      'not reach the theme. Wrap your app in <SettingsProvider> to fix this.'
  );
}

/**
 * Reads the settings context, falling back to a shared in-memory store when
 * there is no `<SettingsProvider>` — instead of throwing and blanking the app.
 * Internal: not part of the published surface. Applications should use the
 * exported `useSettingsContext()`, which still throws, because in application
 * code the missing provider is a bug worth failing on.
 *
 * @returns {SettingsContextValue}
 */
export function useSettingsOrDefaults() {
  const context = useContext(SettingsContext);

  // Called unconditionally — hooks cannot be skipped — and cheap when a
  // provider is present: nothing ever mutates the store in that case.
  const store = useSyncExternalStore(subscribe, getSnapshot, getSnapshot);

  if (!context) warnOnce();

  const fallback = useMemo(
    () => ({
      ...store.settings,
      canReset: /** @type {(keyof SettingsState)[]} */ (Object.keys(defaultSettings)).some(
        (key) => store.settings[key] !== defaultSettings[key]
      ),
      openDrawer: store.openDrawer,
      ...standaloneActions,
    }),
    [store]
  );

  return context ?? fallback;
}
