export * from './drawer';

// The context/config layer now lives in `src/settings`: it must not sit under
// `src/components`, because `src/theme` depends on it (that was the theme <->
// components cycle). Re-exported here so `SettingsProvider`,
// `useSettingsContext` and `defaultSettings` keep shipping from the components
// barrel — and therefore from the package root.
export * from 'src/settings';
