import Tab from '@mui/material/Tab';
import Box from '@mui/material/Box';
import Card from '@mui/material/Card';
import Tabs from '@mui/material/Tabs';

import { Iconify } from 'src/components/iconify';

// ----------------------------------------------------------------------
// ProfileHeaderCard — Card à hauteur fixe contenant la couverture du profil
// (généralement un <ProfileCover />) avec une barre d'onglets épinglée en bas
// (fond papier, alignée à droite sur desktop, centrée sur mobile). Les
// panneaux d'onglets restent rendus par l'appelant — se combine avec le hook
// useTabs du design system :
//
//   const tabs = useTabs('profile');
//   <ProfileHeaderCard
//     cover={<ProfileCover name="..." role="..." coverUrl="..." />}
//     tabs={TABS}
//     value={tabs.value}
//     onChange={tabs.onChange}
//   />
//   {tabs.value === 'profile' && <ProfileAbout ... />}
//
// Props :
// - height?   : number — hauteur de la Card (défaut 290).
// - cover     : ReactNode — contenu de couverture (occupe toute la hauteur).
// - tabs      : [{ value, label, icon? }] — icon accepte un nom Iconify
//               (string, rendu en 24px) ou un ReactNode.
// - value     : string — onglet actif.
// - onChange  : (event, newValue) => void.
// - slotProps?: { tabs? } — props additionnelles du composant Tabs.
// - sx?       : sx de la Card.

export function ProfileHeaderCard({
  height = 290,
  cover,
  tabs = [],
  value,
  onChange,
  slotProps,
  sx,
  ...other
}) {
  return (
    <Card sx={{ height, ...sx }} {...other}>
      {cover}

      <Box
        display="flex"
        justifyContent={{ xs: 'center', md: 'flex-end' }}
        sx={{
          width: 1,
          bottom: 0,
          zIndex: 9,
          px: { md: 3 },
          position: 'absolute',
          bgcolor: 'background.paper',
        }}
      >
        <Tabs value={value} onChange={onChange} {...slotProps?.tabs}>
          {tabs.map((tab) => (
            <Tab
              key={tab.value}
              value={tab.value}
              label={tab.label}
              icon={
                typeof tab.icon === 'string' ? <Iconify icon={tab.icon} width={24} /> : tab.icon
              }
            />
          ))}
        </Tabs>
      </Box>
    </Card>
  );
}
