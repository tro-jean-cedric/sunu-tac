import { m } from 'framer-motion';
import { cloneElement, isValidElement } from 'react';

import Box from '@mui/material/Box';
import Stack from '@mui/material/Stack';
import Drawer from '@mui/material/Drawer';
import MenuItem from '@mui/material/MenuItem';
import { useTheme } from '@mui/material/styles';
import Typography from '@mui/material/Typography';
import IconButton from '@mui/material/IconButton';
import LoadingButton from '@mui/lab/LoadingButton';

import { RouterLink } from 'src/routes/components';

import { varAlpha } from 'src/theme/styles';

import { useBoolean } from 'src/hooks/use-boolean';

import { Iconify } from 'src/components/iconify';
import { Scrollbar } from 'src/components/scrollbar';
import { varHover, AnimateAvatar } from 'src/components/animate';

// ----------------------------------------------------------------------
// AccountDrawer — tiroir de compte (ancré à droite) ouvert par un déclencheur
// (par défaut : IconButton avatar animé avec initiales en fallback) : grand
// AnimateAvatar 96px sous un dégradé primaire, nom + email centrés, section
// de menu bordée en pointillés, slot `extraSection` (les apps y injectent par
// exemple un <PersonCardGrid variant="list" /> chargé à l'ouverture via
// `onOpenChange`), et bouton de déconnexion "soft error" en pied avec son
// propre état de chargement.
//
// Props :
// - user          : { displayName, email, photoURL? }.
// - menuItems?    : [{ label, icon?, onClick?, href?, component? }] — icon
//                   accepte un nom Iconify (string) ou un ReactNode ; le tiroir
//                   se ferme avant d'appeler onClick. Un item avec `href` est
//                   rendu via RouterLink (navigation SPA) ; `component` permet
//                   de forcer un autre rendu (par ex. 'a' pour un lien externe).
// - onSignOut     : async () => void — action de déconnexion (état de
//                   chargement interne) ; le tiroir se ferme en cas de succès.
// - onError?      : (error) => void — appelé si onSignOut rejette ; le tiroir
//                   reste ouvert et l'état de chargement est réinitialisé.
// - signOutLabel? : string — libellé du bouton (défaut "Déconnexion").
// - onOpenChange? : (open: bool) => void — notifié à l'ouverture / fermeture
//                   (pratique pour charger des données à l'ouverture).
// - extraSection? : ReactNode — contenu additionnel rendu sous le menu,
//                   dans la zone scrollable.
// - trigger?      : ReactNode — élément déclencheur personnalisé (son onClick
//                   est chaîné avec l'ouverture du tiroir).
// - sx?           : sx du déclencheur par défaut.

export function getInitials(name) {
  if (!name) return '';
  const parts = String(name).trim().split(/\s+/).filter(Boolean);
  if (parts.length === 0) return '';
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
  return (parts[0][0] + parts[1][0]).toUpperCase();
}

export function AccountDrawer({
  user,
  menuItems = [],
  onSignOut,
  onError,
  signOutLabel = 'Déconnexion',
  onOpenChange,
  extraSection,
  trigger,
  sx,
  ...other
}) {
  const theme = useTheme();

  const open = useBoolean();
  const signingOut = useBoolean();

  const handleOpen = () => {
    open.onTrue();
    onOpenChange?.(true);
  };

  const handleClose = () => {
    open.onFalse();
    onOpenChange?.(false);
  };

  const handleSignOut = async () => {
    signingOut.onTrue();
    try {
      await onSignOut?.();
      handleClose();
    } catch (error) {
      onError?.(error);
    } finally {
      signingOut.onFalse();
    }
  };

  const gradient = `linear-gradient(135deg, ${varAlpha(theme.vars.palette.primary.mainChannel, 0)} 25%, ${theme.vars.palette.primary.main} 100%)`;

  const renderTrigger =
    trigger && isValidElement(trigger) ? (
      cloneElement(trigger, {
        onClick: (event) => {
          trigger.props.onClick?.(event);
          handleOpen();
        },
      })
    ) : (
      <IconButton
        component={m.button}
        whileTap="tap"
        whileHover="hover"
        variants={varHover(1.05)}
        onClick={handleOpen}
        sx={{ p: 0, ...sx }}
        {...other}
      >
        <AnimateAvatar
          slotProps={{
            avatar: { src: user?.photoURL, alt: user?.displayName },
            overlay: { border: 1, spacing: 2, color: gradient },
          }}
        >
          {getInitials(user?.displayName)}
        </AnimateAvatar>
      </IconButton>
    );

  return (
    <>
      {renderTrigger}

      <Drawer
        open={open.value}
        onClose={handleClose}
        anchor="right"
        slotProps={{ backdrop: { invisible: true } }}
        PaperProps={{ sx: { width: 320 } }}
      >
        <IconButton
          onClick={handleClose}
          sx={{ top: 12, left: 12, zIndex: 9, position: 'absolute' }}
        >
          <Iconify icon="mingcute:close-line" />
        </IconButton>

        <Scrollbar>
          <Stack alignItems="center" sx={{ pt: 8 }}>
            <AnimateAvatar
              width={96}
              slotProps={{
                avatar: { src: user?.photoURL, alt: user?.displayName },
                overlay: { border: 2, spacing: 3, color: gradient },
              }}
            >
              {getInitials(user?.displayName)}
            </AnimateAvatar>

            <Typography variant="subtitle1" noWrap sx={{ mt: 2 }}>
              {user?.displayName}
            </Typography>

            <Typography variant="body2" sx={{ color: 'text.secondary', mt: 0.5 }} noWrap>
              {user?.email}
            </Typography>
          </Stack>

          {menuItems.length > 0 && (
            <Box
              sx={{
                mt: 3,
                px: 2.5,
                py: 1.5,
                borderTop: `dashed 1px ${theme.vars.palette.divider}`,
                borderBottom: `dashed 1px ${theme.vars.palette.divider}`,
              }}
            >
              {menuItems.map((item) => (
                <MenuItem
                  key={item.label}
                  component={item.component ?? (item.href ? RouterLink : 'li')}
                  href={item.href}
                  onClick={() => {
                    handleClose();
                    item.onClick?.();
                  }}
                  sx={{
                    py: 1,
                    color: 'text.secondary',
                    '& svg': { width: 24, height: 24 },
                    '&:hover': { color: 'text.primary' },
                  }}
                >
                  {typeof item.icon === 'string' ? <Iconify icon={item.icon} /> : item.icon}
                  <Box component="span" sx={{ ml: 2 }}>
                    {item.label}
                  </Box>
                </MenuItem>
              ))}
            </Box>
          )}

          {extraSection}
        </Scrollbar>

        <Box sx={{ p: 2.5 }}>
          <LoadingButton
            fullWidth
            variant="soft"
            size="large"
            color="error"
            loading={signingOut.value}
            onClick={handleSignOut}
          >
            {signOutLabel}
          </LoadingButton>
        </Box>
      </Drawer>
    </>
  );
}
