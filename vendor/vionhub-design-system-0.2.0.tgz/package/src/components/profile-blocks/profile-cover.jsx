import Box from '@mui/material/Box';
import Stack from '@mui/material/Stack';
import Avatar from '@mui/material/Avatar';
import { useTheme } from '@mui/material/styles';
import ListItemText from '@mui/material/ListItemText';

import { varAlpha, bgGradient } from 'src/theme/styles';

// ----------------------------------------------------------------------
// ProfileCover — bandeau de couverture du profil (image sous un dégradé
// primary-dark) avec grand Avatar bordé (initiale en fallback), nom en h4 et
// rôle en sous-titre. Colonne centrée sur mobile, ancré en bas à gauche sur
// desktop. À placer dans un conteneur à hauteur fixe (voir ProfileHeaderCard).
//
// Props :
// - name           : string — nom affiché (h4) + initiale de l'avatar.
// - avatarUrl?     : string — URL (résolue) de la photo ; initiale sinon.
// - role?          : string — sous-titre (rôle, fonction...).
// - coverUrl?      : string — URL (résolue) de l'image de couverture.
// - gradientColor? : string — remplace le dégradé par défaut
//                    (`0deg, rgba(primary.darker, .8), rgba(primary.darker, .8)`).
// - slotProps?     : { avatar?, title?, subtitle? } — props additionnelles
//                    fusionnées sur l'Avatar et les typographies nom / rôle.
// - children?      : ReactNode — slot d'actions rendu après le bloc nom
//                    (boutons "Modifier", "Partager"...).
// - sx?            : sx du conteneur racine.

export function ProfileCover({
  name,
  avatarUrl,
  role,
  coverUrl,
  gradientColor,
  slotProps,
  children,
  sx,
  ...other
}) {
  const theme = useTheme();

  const { sx: avatarSx, ...avatarProps } = slotProps?.avatar ?? {};

  return (
    <Box
      sx={{
        ...bgGradient({
          color:
            gradientColor ??
            `0deg, ${varAlpha(theme.vars.palette.primary.darkerChannel, 0.8)}, ${varAlpha(theme.vars.palette.primary.darkerChannel, 0.8)}`,
          imgUrl: coverUrl,
        }),
        height: 1,
        color: 'common.white',
        ...sx,
      }}
      {...other}
    >
      <Stack
        direction={{ xs: 'column', md: 'row' }}
        sx={{
          left: { md: 24 },
          bottom: { md: 24 },
          zIndex: { md: 10 },
          pt: { xs: 6, md: 0 },
          position: { md: 'absolute' },
        }}
      >
        <Avatar
          alt={name}
          src={avatarUrl}
          sx={{
            mx: 'auto',
            width: { xs: 64, md: 128 },
            height: { xs: 64, md: 128 },
            border: `solid 2px ${theme.vars.palette.common.white}`,
            fontSize: { xs: 24, md: 48 },
            ...avatarSx,
          }}
          {...avatarProps}
        >
          {name?.charAt(0).toUpperCase()}
        </Avatar>

        <ListItemText
          sx={{ mt: 3, ml: { md: 3 }, textAlign: { xs: 'center', md: 'unset' } }}
          primary={name}
          secondary={role}
          primaryTypographyProps={{ typography: 'h4', ...slotProps?.title }}
          secondaryTypographyProps={{
            mt: 0.5,
            color: 'inherit',
            component: 'span',
            typography: 'body2',
            sx: { opacity: 0.48 },
            ...slotProps?.subtitle,
          }}
        />

        {children}
      </Stack>
    </Box>
  );
}
