import Box from '@mui/material/Box';
import Card from '@mui/material/Card';
import Stack from '@mui/material/Stack';
import Avatar from '@mui/material/Avatar';
import Skeleton from '@mui/material/Skeleton';
import CardHeader from '@mui/material/CardHeader';
import Typography from '@mui/material/Typography';
import ListItemText from '@mui/material/ListItemText';

import { EmptyContent } from 'src/components/empty-content';

// ----------------------------------------------------------------------
// PersonCardGrid — liste de personnes en lignes bordées (Avatar avec
// initiale en fallback, nom subtitle2 noWrap, texte secondaire en caption) :
// grille responsive 1/2/3 colonnes (variant "grid", ex. onglet
// "Collaborateurs" du profil) ou liste verticale compacte (variant "list",
// ex. section collaborateurs de l'AccountDrawer). Lignes Skeleton pendant le
// chargement, EmptyContent (ou texte simple en variante liste) quand vide.
// Avec `title`, le tout est enveloppé dans une Card + CardHeader ; sans
// titre, rendu nu — pratique pour l'intégrer dans un tiroir.
//
// Props :
// - title?        : string — titre de la Card (pas de Card si omis).
// - subheader?    : string — sous-titre de la Card.
// - items         : [{ id, name, secondary?, avatarUrl? }].
// - loading?      : bool — affiche des lignes Skeleton.
// - skeletonCount?: number — nombre de lignes Skeleton (défaut 3).
// - emptyText?    : string — message quand la liste est vide
//                   (défaut "Aucune personne").
// - variant?      : 'grid' (défaut) | 'list' — grille spacieuse ou liste
//                   compacte (avatar 36px).
// - onItemClick?  : (item) => void — rend les lignes cliquables.
// - sx?           : sx du conteneur (Card ou contenu nu).

const getInitial = (name) => (name ?? '?').charAt(0).toUpperCase();

function PersonRow({ item, compact, onItemClick }) {
  return (
    <Stack
      direction="row"
      spacing={compact ? 1.5 : 2}
      alignItems="center"
      onClick={onItemClick ? () => onItemClick(item) : undefined}
      sx={{
        p: compact ? 1 : 2,
        borderRadius: compact ? 1 : 1.5,
        border: (theme) => `solid 1px ${theme.palette.divider}`,
        ...(onItemClick && {
          cursor: 'pointer',
          transition: (theme) => theme.transitions.create(['background-color']),
          '&:hover': { bgcolor: 'action.hover' },
        }),
      }}
    >
      <Avatar
        src={item.avatarUrl}
        alt={item.name}
        sx={compact ? { width: 36, height: 36 } : undefined}
      >
        {getInitial(item.name)}
      </Avatar>
      <ListItemText
        primary={item.name}
        secondary={item.secondary}
        primaryTypographyProps={{ typography: 'subtitle2', noWrap: true }}
        secondaryTypographyProps={{
          typography: 'caption',
          color: 'text.secondary',
          noWrap: true,
        }}
      />
    </Stack>
  );
}

export function PersonCardGrid({
  title,
  subheader,
  items,
  loading = false,
  skeletonCount = 3,
  emptyText = 'Aucune personne',
  variant = 'grid',
  onItemClick,
  sx,
  ...other
}) {
  const compact = variant === 'list';
  const list = Array.isArray(items) ? items : [];

  let content;

  if (loading) {
    content = (
      <Stack spacing={compact ? 1.5 : 2} sx={compact ? undefined : { p: 3 }}>
        {[...Array(skeletonCount)].map((_, idx) => (
          <Stack key={idx} direction="row" spacing={compact ? 1.5 : 2} alignItems="center">
            <Skeleton
              variant="circular"
              width={compact ? 36 : 40}
              height={compact ? 36 : 40}
            />
            <Skeleton
              variant="rectangular"
              sx={{ flexGrow: 1, borderRadius: 1 }}
              height={compact ? 32 : 40}
            />
          </Stack>
        ))}
      </Stack>
    );
  } else if (list.length === 0) {
    content = compact ? (
      <Typography variant="body2" color="text.secondary" sx={{ textAlign: 'center', py: 2 }}>
        {emptyText}
      </Typography>
    ) : (
      <EmptyContent title={emptyText} sx={{ py: 5 }} />
    );
  } else if (compact) {
    content = (
      <Stack spacing={1.25}>
        {list.map((item) => (
          <PersonRow
            key={item.id ?? item.name}
            item={item}
            compact
            onItemClick={onItemClick}
          />
        ))}
      </Stack>
    );
  } else {
    content = (
      <Box
        sx={{
          p: 3,
          display: 'grid',
          gap: 2,
          gridTemplateColumns: { xs: '1fr', sm: 'repeat(2, 1fr)', md: 'repeat(3, 1fr)' },
        }}
      >
        {list.map((item) => (
          <PersonRow key={item.id ?? item.name} item={item} onItemClick={onItemClick} />
        ))}
      </Box>
    );
  }

  if (!title) {
    return (
      <Box sx={sx} {...other}>
        {content}
      </Box>
    );
  }

  return (
    <Card sx={sx} {...other}>
      <CardHeader title={title} subheader={subheader} />
      {compact ? <Box sx={{ p: 3 }}>{content}</Box> : content}
    </Card>
  );
}
