import LoadingButton from '@mui/lab/LoadingButton';
import {
  Button,
  Dialog,
  Typography,
  DialogTitle,
  DialogContent,
  DialogActions,
} from '@mui/material';

import { Form } from 'src/components/hook-form';
import { Iconify } from 'src/components/iconify';
import { DialogCloseButton } from 'src/components/custom-dialog';

import { ignoreBackdropClose } from './ignore-backdrop-close';

// ----------------------------------------------------------------------
// The chrome shared by every VionHub form dialog: close button, title,
// content, Cancel + submit actions — extracted from the ~16 near-identical
// dialogs of the app (user-form, annual-budget-form, resource-form, ...).
//
// Two submit modes:
//   - RHF mode: pass `methods` (a useForm return). Children are wrapped in
//     the DS <Form>, the submit button is type="submit" bound to
//     handleSubmit(onSubmit), and its loading state derives from
//     formState.isSubmitting.
//   - Plain mode: omit `methods`. The submit button calls `onSubmit`
//     directly and the `loading` prop drives its spinner (covers non-RHF
//     pickers and confirm-style dialogs).
//
// Props:
//   - open, onClose
//   - title, subtitle?: header texts (subtitle renders as a caption line)
//   - maxWidth: MUI Dialog maxWidth (default 'sm')
//   - methods?: react-hook-form methods → enables RHF mode
//   - onSubmit: (values) in RHF mode, () in plain mode
//   - loading?: plain-mode submit spinner
//   - submitLabel / cancelLabel: button texts (default 'Enregistrer' / 'Annuler')
//   - submitColor?: submit button color (default 'primary')
//   - submitIcon?: Iconify icon name for the submit button's startIcon
//   - submitDisabled?: disables the submit button
//   - contextHeader?: ReactNode rendered between the title and the content
//     (info banners, entity summary, ...)
//   - actionsExtra?: ReactNode rendered between Cancel and the submit
//     button (secondary actions, e.g. "save as draft")
//   - disableBackdropClose: swallow backdrop clicks (default true;
//     Escape always closes)

/**
 * @template {import('react-hook-form').FieldValues} [TFieldValues=import('react-hook-form').FieldValues]
 * @typedef {object} FormDialogShellProps
 * @property {boolean} open
 * @property {() => void} onClose
 * @property {import('react').ReactNode} [title]
 * @property {import('react').ReactNode} [subtitle]
 * @property {import('@mui/material').DialogProps['maxWidth']} [maxWidth] Default `'sm'`.
 * @property {import('react-hook-form').UseFormReturn<TFieldValues>} [methods] Pass a `useForm()` return to enable RHF mode.
 * @property {(values: TFieldValues) => void | Promise<unknown>} [onSubmit] Receives the form values in RHF mode; called with no argument in plain mode.
 * @property {boolean} [loading] Plain-mode submit spinner (ignored in RHF mode).
 * @property {import('react').ReactNode} [submitLabel] Default `'Enregistrer'`.
 * @property {import('react').ReactNode} [cancelLabel] Default `'Annuler'`.
 * @property {import('@mui/material').ButtonProps['color']} [submitColor] Default `'primary'`.
 * @property {string} [submitIcon] Iconify icon name for the submit button.
 * @property {boolean} [submitDisabled]
 * @property {import('react').ReactNode} [contextHeader] Rendered between the title and the content.
 * @property {import('react').ReactNode} [actionsExtra] Rendered between Cancel and the submit button.
 * @property {boolean} [disableBackdropClose] Swallow backdrop clicks (default `true`).
 * @property {import('react').ReactNode} [children]
 */

/**
 * @template {import('react-hook-form').FieldValues} [TFieldValues=import('react-hook-form').FieldValues]
 * @param {FormDialogShellProps<TFieldValues>} props
 * @returns {import('react').JSX.Element}
 */
export function FormDialogShell({
  open,
  onClose,
  title,
  subtitle,
  maxWidth = 'sm',
  methods,
  onSubmit,
  loading = false,
  submitLabel = 'Enregistrer',
  cancelLabel = 'Annuler',
  submitColor = 'primary',
  submitIcon,
  submitDisabled = false,
  contextHeader,
  actionsExtra,
  disableBackdropClose = true,
  children,
}) {
  const submitting = methods ? methods.formState.isSubmitting : loading;

  const body = (
    <>
      <DialogTitle>
        {title}
        {subtitle && (
          <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 0.5 }}>
            {subtitle}
          </Typography>
        )}
      </DialogTitle>

      {contextHeader}

      <DialogContent>{children}</DialogContent>

      <DialogActions>
        <Button onClick={onClose} color="inherit" disabled={submitting}>
          {cancelLabel}
        </Button>
        {actionsExtra}
        <LoadingButton
          type={methods ? 'submit' : 'button'}
          variant="contained"
          color={submitColor}
          loading={submitting}
          disabled={submitDisabled}
          startIcon={submitIcon ? <Iconify icon={submitIcon} /> : undefined}
          onClick={methods ? undefined : onSubmit}
        >
          {submitLabel}
        </LoadingButton>
      </DialogActions>
    </>
  );

  return (
    <Dialog
      fullWidth
      maxWidth={maxWidth}
      open={open}
      onClose={disableBackdropClose ? ignoreBackdropClose(onClose) : onClose}
    >
      <DialogCloseButton onClick={onClose} />
      {methods ? (
        <Form methods={methods} onSubmit={methods.handleSubmit(onSubmit)}>
          {body}
        </Form>
      ) : (
        body
      )}
    </Dialog>
  );
}
