import dayjs from 'dayjs';
import { z as zod } from 'zod';
import { useForm } from 'react-hook-form';
import { useMemo, useEffect } from 'react';
import { zodResolver } from '@hookform/resolvers/zod';

import { Box, MenuItem } from '@mui/material';

import { Field } from 'src/components/hook-form';

import { FormDialogShell } from './form-dialog-shell';

// ----------------------------------------------------------------------
// Declarative create/edit dialog: describe the form as a `fields` array and
// get a validated, responsive two-column dialog form. Merges the app's two
// near-duplicate implementations (ResourceFormDialog + ResourceFormSimple)
// into their superset: emptyValues, disabledOnEdit, select/date field types.
//
// Props:
//   - open, onClose
//   - title: dialog title
//   - fields: [{ name, label, type?: 'text'|'number'|'textarea'|'select'|'date',
//       required?, gridSpan?: 1|2, disabledOnEdit?, options? }]
//       `options` (select only): [{ value, label }] or scalar array
//   - initial: record being edited, or null → create mode. Edit mode
//     switches the submit label and honors `disabledOnEdit`.
//   - emptyValues: default values for new records (merged under `initial`)
//   - onSubmit: async (values) — the dialog stays open; close/refresh is the
//     caller's job (matches the app's ResourcePage loop)
//   - schema?: zod schema overriding the generated one
//   - renderField?: (field, { isEdit, methods }) => ReactNode — per-field
//     rendering override; return null/undefined to keep the default
//   - maxWidth: Dialog maxWidth (default 'sm')
//   - labels: { cancel, save, saveEdit } button texts
//   - messages: { required: (label) => string, invalidNumber: (label) => string }
//     validation texts used by the generated schema

const DEFAULT_LABELS = {
  cancel: 'Annuler',
  save: 'Enregistrer',
  saveEdit: 'Modifier',
};

const DEFAULT_MESSAGES = {
  required: (label) => `${label} requis`,
  invalidNumber: (label) => `${label} doit être un nombre`,
};

// ----------------------------------------------------------------------

function buildSchema(fields, messages) {
  const shape = {};
  fields.forEach((f) => {
    let s;
    if (f.type === 'number') {
      // Empty ('' / null) must not coerce to 0 — treat it as missing so
      // `required` actually fires and optional numbers stay undefined.
      s = zod.preprocess(
        (v) => (v === '' || v == null ? undefined : v),
        // `message`, not `invalid_type_error`: zod 4 dropped `invalid_type_error`
        // (renamed to `error`) and IGNORES it silently, which would replace the
        // caller's message with zod's generic English one. `message` is honoured
        // by both zod 3 and zod 4.
        //
        // On zod 3, `message` is broader than `invalid_type_error` — it sets the
        // required-error message as well. That is not observable here, and was
        // checked by running both spellings through this exact schema on the
        // installed zod 3.25.76: `''`/`null`/`undefined` are mapped to
        // `undefined` by the preprocess and swallowed by `.optional()`, so the
        // required message always comes from the `.refine()` below, never from
        // the number schema; and a non-numeric string produces the same
        // `invalid_type` issue either way. Both spellings give byte-identical
        // messages for every input, required or not.
        zod.coerce.number({ message: messages.invalidNumber(f.label) }).optional()
      );
      s = f.required
        ? s.refine((v) => v !== undefined && !Number.isNaN(v), {
            message: messages.required(f.label),
          })
        : s;
    } else if (f.type === 'date') {
      s = f.required
        ? zod.any().refine((v) => !!v && dayjs(v).isValid(), { message: messages.required(f.label) })
        : zod.any().optional();
    } else if (f.type === 'select') {
      s = f.required
        ? zod.any().refine((v) => v !== null && v !== undefined && v !== '', {
            message: messages.required(f.label),
          })
        : zod.any().optional();
    } else {
      s = zod.string();
      s = f.required ? s.min(1, { message: messages.required(f.label) }) : s.optional();
    }
    shape[f.name] = s;
  });
  return zod.object(shape);
}

function buildDefaults(fields, initial, empty) {
  const out = { ...empty };
  fields.forEach((f) => {
    const fallback = f.type === 'date' ? null : '';
    out[f.name] = initial?.[f.name] ?? empty[f.name] ?? fallback;
  });
  return out;
}

const normalizeOption = (opt) =>
  opt !== null && typeof opt === 'object' ? opt : { value: opt, label: String(opt) };

// ----------------------------------------------------------------------

export function SchemaFormDialog({
  open,
  onClose,
  title,
  fields,
  initial = null,
  emptyValues = {},
  onSubmit,
  schema,
  renderField,
  maxWidth = 'sm',
  labels: labelsProp,
  messages: messagesProp,
}) {
  const isEdit = initial != null;
  const labels = { ...DEFAULT_LABELS, ...labelsProp };
  const messages = { ...DEFAULT_MESSAGES, ...messagesProp };

  const resolvedSchema = useMemo(
    () => schema ?? buildSchema(fields, messages),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [schema, fields]
  );

  const methods = useForm({
    resolver: zodResolver(resolvedSchema),
    defaultValues: buildDefaults(fields, initial, emptyValues),
  });

  useEffect(() => {
    methods.reset(buildDefaults(fields, initial, emptyValues));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [initial, open]);

  const renderDefault = (f) => {
    const disabled = isEdit && !!f.disabledOnEdit;
    if (f.type === 'textarea') {
      return <Field.Text name={f.name} label={f.label} multiline rows={3} disabled={disabled} />;
    }
    if (f.type === 'number') {
      return <Field.Number name={f.name} label={f.label} disabled={disabled} />;
    }
    if (f.type === 'select') {
      return (
        <Field.Select name={f.name} label={f.label} disabled={disabled}>
          {(f.options ?? []).map(normalizeOption).map((opt) => (
            <MenuItem key={opt.value} value={opt.value}>
              {opt.label}
            </MenuItem>
          ))}
        </Field.Select>
      );
    }
    if (f.type === 'date') {
      return <Field.DatePicker name={f.name} label={f.label} disabled={disabled} />;
    }
    return <Field.Text name={f.name} label={f.label} disabled={disabled} />;
  };

  return (
    <FormDialogShell
      open={open}
      onClose={onClose}
      title={title}
      maxWidth={maxWidth}
      methods={methods}
      onSubmit={onSubmit}
      cancelLabel={labels.cancel}
      submitLabel={isEdit ? labels.saveEdit : labels.save}
    >
      <Box
        sx={{
          display: 'grid',
          gridTemplateColumns: { xs: '1fr', sm: 'repeat(2, 1fr)' },
          gap: 2,
          py: 1,
        }}
      >
        {fields.map((f) => (
          <Box key={f.name} sx={{ gridColumn: { sm: f.gridSpan === 2 ? 'span 2' : 'span 1' } }}>
            {renderField?.(f, { isEdit, methods }) ?? renderDefault(f)}
          </Box>
        ))}
      </Box>
    </FormDialogShell>
  );
}
