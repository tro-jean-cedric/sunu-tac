import { useState } from 'react';

import LoadingButton from '@mui/lab/LoadingButton';
import { Box, Button, DialogActions } from '@mui/material';

import { Iconify } from 'src/components/iconify';
import { useOptionalConfirm } from 'src/components/confirm-provider';

// ----------------------------------------------------------------------
// The multi-action dialog footer of the app's request form: Cancel on the
// left, a spacer, then one LoadingButton per action ("save as draft",
// "save and forward", ...). Replaces the default DialogActions — render it
// as a direct child of a Dialog.
//
// Props:
//   - onCancel, cancelLabel (default 'Annuler')
//   - busy?: external submit flag — spins every action button and disables
//     Cancel (mirror of the app's shared `submitting` state)
//   - actions: [{
//       key,                 // unique id — tracks which action is running
//       label,
//       icon?,               // Iconify name → startIcon
//       variant?: 'outlined'|'contained' (default 'contained')
//       color?,
//       confirm?: { title, message, confirmText, color },  // gate through
//                            // the DS confirm-provider before onClick
//       onClick: async () => {},
//     }]
//
// While one action runs (its onClick promise is pending) its button spins
// and every sibling + Cancel is disabled. No toasts here — success/error
// feedback is the caller's job.
//
// `confirm` needs <ConfirmProvider> up the tree; without one the action
// runs unconfirmed (keeps the bar renderable under the bare ThemeProvider).

export function DialogActionBar({ onCancel, cancelLabel = 'Annuler', busy = false, actions = [], sx }) {
  const confirm = useOptionalConfirm();
  const [runningKey, setRunningKey] = useState(null);

  const run = async (action) => {
    if (action.confirm && confirm) {
      const ok = await confirm({
        title: action.confirm.title,
        message: action.confirm.message,
        confirmText: action.confirm.confirmText,
        color: action.confirm.color,
      });
      if (!ok) return;
    }
    setRunningKey(action.key);
    try {
      await action.onClick?.();
    } finally {
      setRunningKey(null);
    }
  };

  return (
    <DialogActions sx={{ px: 3, py: 2, gap: 1, ...sx }}>
      <Button onClick={onCancel} color="inherit" disabled={busy || runningKey != null}>
        {cancelLabel}
      </Button>
      <Box sx={{ flex: 1 }} />
      {actions.map((action) => (
        <LoadingButton
          key={action.key}
          type="button"
          variant={action.variant ?? 'contained'}
          color={action.color}
          loading={busy || runningKey === action.key}
          disabled={runningKey != null && runningKey !== action.key}
          startIcon={action.icon ? <Iconify icon={action.icon} /> : undefined}
          onClick={() => run(action)}
        >
          {action.label}
        </LoadingButton>
      ))}
    </DialogActions>
  );
}
