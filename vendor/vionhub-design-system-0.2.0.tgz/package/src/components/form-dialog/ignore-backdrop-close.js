/**
 * Wraps a Dialog `onClose` so that clicks on the backdrop are ignored while
 * Escape key presses still close the dialog. This is the VionHub app's standard
 * behavior for every form dialog (a stray click outside must not discard a
 * half-filled form).
 *
 * Use as `onClose={ignoreBackdropClose(handleClose)}`.
 */
export function ignoreBackdropClose(onClose) {
  return (event, reason) => {
    if (reason === 'backdropClick') return;
    onClose?.(event, reason);
  };
}
