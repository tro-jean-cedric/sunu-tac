import { useRef, useMemo, useState, useEffect } from 'react';

import { Card, Stack, TextField, InputAdornment, CircularProgress } from '@mui/material';
import { DataGrid, gridClasses, GRID_CHECKBOX_SELECTION_COL_DEF } from '@mui/x-data-grid';

import { Iconify } from 'src/components/iconify';
import { EmptyContent } from 'src/components/empty-content';
import { SEARCH_DEBOUNCE_MS, DATA_GRID_PAGE_SIZE_OPTIONS } from 'src/components/list-defaults';

// ----------------------------------------------------------------------

/**
 * Own props of {@link AsyncDataGrid} that are not simply forwarded to MUI's
 * `DataGrid`. Everything else (`checkboxSelection`, `onRowClick`, `slotProps`…)
 * is spread onto the grid.
 *
 * @typedef {object} AsyncDataGridOwnProps
 * @property {number} [searchDebounce] Milliseconds the search box waits after
 *   the last keystroke before calling `onSearchChange`. Defaults to `500` — the
 *   library-wide `SEARCH_DEBOUNCE_MS`, the same default `DebouncedSearchField`
 *   uses for its `delay`. Was a hard-coded, unoverridable 700 ms in v0.2.0;
 *   pass `searchDebounce={700}` to keep that timing.
 * @property {readonly number[]} [pageSizeOptions] Page sizes offered in the
 *   footer. Defaults to `[10, 25, 50, 100]` — unchanged from v0.2.0, where it
 *   was hard-coded. `TablePaginationCustom` deliberately offers a shorter list;
 *   see `src/components/list-defaults.js` for why they are not merged.
 */

export function AsyncDataGrid({
  columns,
  rows,
  total,
  page,
  pageSize,
  search,
  loading,
  onPageChange,
  onPageSizeChange,
  onSearchChange,
  searchDebounce = SEARCH_DEBOUNCE_MS,
  pageSizeOptions = DATA_GRID_PAGE_SIZE_OPTIONS,
  toolbar,
  toolbarLeft,
  topSlot,
  belowToolbar,
  getRowId,
  sx,
  ...other
}) {
  const paginationModel = useMemo(() => ({ page: page - 1, pageSize }), [page, pageSize]);

  // Give every column sensible defaults so the grid can self-size to content
  // (flex + minWidth) instead of relying on hard-coded widths. Per-column
  // values from the caller still win.
  const autoColumns = useMemo(() => {
    const mapped = columns.map((c) => ({
      flex: c.flex ?? (c.width ? undefined : 1),
      minWidth: c.minWidth ?? 120,
      ...c,
    }));
    // When checkbox selection is on, the checkbox column becomes the first
    // column and inherits the leading gutter (pl: 3) that the first data
    // column used to have. The default 50px width can't fit that padding +
    // the checkbox, so widen it to keep the body aligned with the rest of
    // the table without clipping the "select all" checkbox.
    if (other.checkboxSelection) {
      mapped.unshift({ ...GRID_CHECKBOX_SELECTION_COL_DEF, width: 72, minWidth: 72 });
    }
    return mapped;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [columns, other.checkboxSelection]);

  // Debounced search: keep a local input value that updates instantly so the
  // textbox feels responsive, but only forward to onSearchChange after the
  // user stops typing for `searchDebounce` ms.
  const [inputValue, setInputValue] = useState(search ?? '');
  const isTypingRef = useRef(false);
  // searchPending: true while a search debounce is in flight. We use this to
  // gate the spinner inside the search field so it doesn't echo the table's
  // own loading state on every refetch (BDC update, transfer, page change…).
  const [searchPending, setSearchPending] = useState(false);

  // Sync local input when the parent resets/changes search externally
  // (e.g. clearing the chip in FiltersResult). Don't clobber while typing.
  useEffect(() => {
    if (!isTypingRef.current) {
      setInputValue(search ?? '');
    }
  }, [search]);

  useEffect(() => {
    if (!isTypingRef.current) return undefined;
    setSearchPending(true);
    const t = setTimeout(() => {
      isTypingRef.current = false;
      if (inputValue !== (search ?? '')) {
        onSearchChange?.(inputValue);
      }
      setSearchPending(false);
    }, searchDebounce);
    return () => clearTimeout(t);
  }, [inputValue, search, onSearchChange, searchDebounce]);

  return (
    <Card>
      {topSlot}

      <Stack
        spacing={2}
        alignItems={{ xs: 'flex-end', md: 'center' }}
        direction={{ xs: 'column', md: 'row' }}
        sx={{ p: 2.5, pr: { xs: 2.5, md: 1 } }}
      >
        {toolbarLeft}
        <Stack direction="row" alignItems="center" spacing={2} flexGrow={1} sx={{ width: 1 }}>
          <TextField
            value={inputValue}
            onChange={(e) => {
              isTypingRef.current = true;
              setInputValue(e.target.value);
            }}
            placeholder="Rechercher..."
            sx={{ width: { xs: 1, sm: 260 } }}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <Iconify icon="eva:search-fill" sx={{ color: 'text.disabled' }} />
                </InputAdornment>
              ),
              endAdornment: searchPending ? (
                <InputAdornment position="end">
                  <CircularProgress size={16} />
                </InputAdornment>
              ) : null,
            }}
          />
          {toolbar && (
            <Stack
              direction="row"
              alignItems="center"
              spacing={1}
              sx={{
                ml: 'auto',
                '& .MuiButton-contained': {
                  bgcolor: 'primary.main',
                  color: '#ffffff',
                  boxShadow: 'none',
                  borderRadius: '20px',
                  padding: '12px 17px',
                  '&:hover': {
                    bgcolor: '#000000',
                    color: '#ffffff',
                    boxShadow: 'none',
                  },
                },
              }}
            >
              {toolbar}
            </Stack>
          )}
        </Stack>
      </Stack>

      {belowToolbar}

      <DataGrid
        autoHeight
        disableRowSelectionOnClick
        disableColumnMenu
        getRowId={getRowId ?? ((row) => row.id)}
        rows={rows}
        columns={autoColumns}
        loading={loading}
        rowCount={total}
        paginationMode="server"
        paginationModel={paginationModel}
        onPaginationModelChange={(m) => {
          if (m.pageSize !== pageSize) onPageSizeChange?.(m.pageSize);
          if (m.page + 1 !== page) onPageChange?.(m.page + 1);
        }}
        pageSizeOptions={pageSizeOptions}
        slots={{
          noRowsOverlay: () => <EmptyContent title="Aucune donnée" />,
          noResultsOverlay: () => <EmptyContent title="Aucun résultat" />,
        }}
        rowHeight={64}
        columnHeaderHeight={56}
        sx={[
          {
            border: 0,
            [`& .${gridClasses.cell}`]: {
              display: 'flex',
              alignItems: 'center',
              py: 1.5,
              px: 2,
              fontSize: '0.875rem',
              fontWeight: 400,
              color: '#888888',
            },
            [`& .${gridClasses.cell}:first-of-type, & .${gridClasses.columnHeader}:first-of-type`]: {
              pl: 3,
            },
            // Keep the leading gutter (pl: 3) on the checkbox column so the
            // checkbox lines up where the first data column used to start, but
            // drop the right padding so the generic cell padding doesn't
            // overflow the column and clip the "select all" checkbox.
            [`&& .${gridClasses.cellCheckbox}, && .${gridClasses.columnHeaderCheckbox}`]: {
              pl: 3,
              pr: 0,
              justifyContent: 'flex-start',
              '& .MuiCheckbox-root': { p: 0 },
            },
            [`& .${gridClasses.cell}:last-of-type, & .${gridClasses.columnHeader}:last-of-type`]: {
              pr: 3,
            },
            [`& .${gridClasses.columnHeaders}`]: {
              bgcolor: 'background.neutral',
            },
            [`& .${gridClasses.columnHeader}`]: {
              px: 2,
              fontSize: '0.8125rem',
              fontWeight: 700,
              color: '#000000',
            },
            [`& .${gridClasses.columnHeaderTitle}`]: {
              fontWeight: 700,
              color: '#000000',
            },
            [`& .${gridClasses.row}`]: {
              '&:hover': { bgcolor: 'action.hover' },
            },
            [`& .${gridClasses.footerContainer}`]: {
              px: 2,
              borderTop: (theme) => `1px dashed ${theme.palette.divider}`,
            },
            // Suppress the red focus outline that the global stylesheet applies
            // to focused cells / column headers — clicks shouldn't draw a border.
            [`& .${gridClasses.cell}:focus, & .${gridClasses.cell}:focus-within, & .${gridClasses.columnHeader}:focus, & .${gridClasses.columnHeader}:focus-within`]:
              { outline: 'none' },
          },
          ...(Array.isArray(sx) ? sx : [sx]),
        ]}
        {...other}
      />
    </Card>
  );
}
