import { Box } from '@mui/material';

// Wrapper for DataGrid renderCell content that contains interactive buttons.
// MUI DataGrid focuses the cell on `mousedown` (before `click` fires), which
// causes interactive children to require two clicks: first focuses the cell,
// second invokes the button. Stopping propagation at `mousedown` defuses the
// focus-stealing path so child onClick fires on the very first click.
//
// Use this anywhere a renderCell wraps IconButtons / Buttons / Menus.
export function ActionsCell({ children, sx, ...rest }) {
  const stop = (e) => e.stopPropagation();
  return (
    <Box
      onMouseDown={stop}
      onMouseUp={stop}
      onClick={stop}
      sx={{ display: 'flex', alignItems: 'center', gap: 0.5, width: '100%', ...sx }}
      {...rest}
    >
      {children}
    </Box>
  );
}
