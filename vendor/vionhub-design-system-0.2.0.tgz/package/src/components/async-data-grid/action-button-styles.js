// Shared sx presets for circular action buttons used inside ActionsCell.
// Three brand colors: black, warning (#f5c928), danger (#cb3b2a).
// Black hovers to primary; the colored ones hover to black.

const actionBtnSx = (bg, hoverBg, color) => ({
  bgcolor: bg,
  color: color ?? 'common.white',
  borderRadius: '50%',
  width: 36,
  height: 36,
  p: 0,
  boxShadow: '0 4px 10px rgba(0,0,0,0.18)',
  transition: 'background-color 0.2s ease, transform 0.15s ease',
  '&:hover': {
    bgcolor: hoverBg,
    color: 'common.white',
    transform: 'translateY(-1px)',
    boxShadow: '0 6px 14px rgba(0,0,0,0.22)',
  },
});

export const ACTION_BLACK = actionBtnSx('common.black', 'primary.main');
export const ACTION_PRIMARY = actionBtnSx('primary.main', 'common.black');
export const ACTION_WARNING = actionBtnSx('#f5c928', 'common.black', 'common.black');
export const ACTION_DANGER = actionBtnSx('#cb3b2a', 'common.black');
