import { useEffect, useState, useCallback } from 'react';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm, useWatch } from 'react-hook-form';

import LoadingButton from '@mui/lab/LoadingButton';
import {
  Box,
  Stack,
  alpha,
  Dialog,
  Button,
  Typography,
  DialogTitle,
  DialogContent,
  DialogActions,
} from '@mui/material';

import { Iconify } from 'src/components/iconify';
import { Form } from 'src/components/hook-form';
import { useOptionalConfirm } from 'src/components/confirm-provider';
import { DialogCloseButton } from 'src/components/custom-dialog';

import { FormItemAccordionList } from './form-item-accordion-list';

// ----------------------------------------------------------------------
// Create/edit 1..N sibling entities in one submit — the v2 "batch" form
// dialog design shared by demandes d'achat and bons de commande. Data-agnostic:
// the caller supplies the zod schema, the per-item fields, the summary line
// and the submit handler(s); option lists and uploads live in the caller's
// `renderItemFields` / `onSubmit`.
//
// Props:
//   open, onClose            dialog visibility. Backdrop clicks are ignored by
//                            default (`disableBackdropClose`); Escape still closes.
//   title, subtitle?         header texts; `icon?` is the Iconify name of the
//                            36px header badge (default 'solar:clipboard-list-bold').
//   schema                   zod schema with an `items` array (see `name`).
//   name                     field-array name (default 'items').
//   defaultItem              blank-item template (create mode + add button).
//   data?                    entity being edited; prefills item 0 through
//   buildItemFromData?       `(data) => itemValues` (falls back to defaultItem).
//                            `data` should be identity-stable or carry an `id` —
//                            the open-reset keys on `data?.id ?? data`, so a
//                            fresh object literal per render without an `id`
//                            would reset the form on every parent re-render.
//   editing                  edit mode: single item, no add button (default false).
//   renderItemFields         ({ index, editing }) => the expanded form body.
//   buildSummary             (itemValues, index) => collapsed header summary.
//   allowMultiple            false forces a single item (default true).
//   seedFromFirst?           (firstItemValues) => partial item merged over
//                            defaultItem when the add button appends a new item.
//   minItems                 remove blocked at/below this count (default 1).
//   onRemoveItem?            (index) => void — clean parallel state (e.g. files).
//   footerActions?           [{ key, label: string | (count) => string, icon?,
//                            variant?, color?, confirm?: {title, message, ...} |
//                            true, onClick?: async (values, key) => {} }] —
//                            one LoadingButton per action, mutually-exclusive
//                            loading; `confirm` gates through the DS
//                            confirm-provider. Omitted -> single submit button.
//   onSubmit                 async (values, actionKey) => {} — default handler
//                            for actions without their own onClick.
//   submitLabel, cancelLabel footer texts ('Enregistrer' / 'Annuler').
//   countLabel               (count) => text of the DialogTitle pill shown when
//                            more than one item (default `${count} éléments`).
//   addLabel, itemLabel, removeTooltip, headerColor
//                            forwarded to <FormItemAccordionList>.
//   maxWidth                 Dialog maxWidth (default 'md').
//
// Requires the DS <ConfirmProvider> only when an action declares `confirm`;
// renders fine without it otherwise (confirm gating is then skipped).

// Isolated item-count subscription. Watching the `items` array at the dialog
// level would re-render the whole dialog (title, footer, every item body) on
// each keystroke; rendered as a leaf, only the count pill / button label that
// actually shows the count re-renders.
function WatchItemCount({ control, name, children }) {
  const items = useWatch({ control, name });
  return children(Array.isArray(items) ? items.length : 0);
}

// ----------------------------------------------------------------------

export function MultiItemFormDialog({
  open,
  onClose,
  title,
  subtitle,
  icon = 'solar:clipboard-list-bold',
  schema,
  name = 'items',
  defaultItem,
  buildItemFromData,
  data = null,
  editing = false,
  renderItemFields,
  buildSummary,
  allowMultiple = true,
  seedFromFirst,
  minItems = 1,
  onRemoveItem,
  footerActions,
  onSubmit,
  submitLabel = 'Enregistrer',
  cancelLabel = 'Annuler',
  countLabel = (count) => `${count} éléments`,
  addLabel,
  itemLabel,
  removeTooltip,
  headerColor = 'primary',
  maxWidth = 'md',
  disableBackdropClose = true,
}) {
  const confirm = useOptionalConfirm();

  // Mutually-exclusive loading: key of the action in flight, or null.
  const [loadingKey, setLoadingKey] = useState(null);
  const submitting = loadingKey != null;

  const makeDefaultValues = useCallback(
    () => ({
      [name]: [data && buildItemFromData ? buildItemFromData(data) : { ...defaultItem }],
    }),
    [name, data, buildItemFromData, defaultItem]
  );

  const methods = useForm({
    resolver: zodResolver(schema),
    defaultValues: makeDefaultValues(),
  });

  // Reset whenever the dialog opens or targets another entity. Keyed on
  // `data?.id ?? data` (not the object identity) so a non-memoized `data`
  // doesn't wipe in-progress edits on every parent re-render.
  useEffect(() => {
    if (!open) return;
    methods.reset(makeDefaultValues());
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, data?.id ?? data]);

  // Footer: explicit actions, or the default single submit button.
  const actions = footerActions?.length
    ? footerActions
    : [{ key: 'submit', label: submitLabel, variant: 'contained' }];

  const runAction = (action, event) =>
    methods.handleSubmit(async (values) => {
      if (action.confirm && confirm) {
        const ok = await confirm(action.confirm === true ? {} : action.confirm);
        if (!ok) return;
      }
      const handler = action.onClick ?? onSubmit;
      if (!handler) return;
      setLoadingKey(action.key);
      try {
        await handler(values, action.key);
      } finally {
        setLoadingKey(null);
      }
    })(event);

  // Enter key submits the primary (last) action, like the source dialogs.
  const primaryAction = actions[actions.length - 1];

  const handleDialogClose = (event, reason) => {
    if (submitting) return;
    if (disableBackdropClose && reason === 'backdropClick') return;
    onClose?.(event, reason);
  };

  // Count-aware labels subscribe to the item count in a leaf renderer so
  // keystrokes elsewhere in the form never re-render the dialog chrome.
  const actionLabel = (action) =>
    typeof action.label === 'function' ? (
      <WatchItemCount control={methods.control} name={name}>
        {(count) => action.label(count)}
      </WatchItemCount>
    ) : (
      action.label
    );

  return (
    <Dialog
      fullWidth
      maxWidth={maxWidth}
      open={open}
      onClose={handleDialogClose}
      PaperProps={{ sx: { borderRadius: 2 } }}
    >
      <DialogCloseButton onClick={onClose} />
      <Form methods={methods} onSubmit={(event) => runAction(primaryAction, event)}>
        <DialogTitle sx={{ pb: 1 }}>
          <Stack direction="row" alignItems="center" spacing={1.5}>
            {icon && (
              <Box
                sx={{
                  width: 36,
                  height: 36,
                  borderRadius: 1.5,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  color: `${headerColor}.main`,
                  bgcolor: (theme) =>
                    alpha(theme.palette[headerColor]?.main ?? theme.palette.primary.main, 0.12),
                }}
              >
                <Iconify icon={icon} width={20} />
              </Box>
            )}
            <Box sx={{ flex: 1, minWidth: 0 }}>
              <Typography variant="h6" sx={{ lineHeight: 1.2 }}>
                {title}
              </Typography>
              {subtitle && (
                <Typography variant="caption" color="text.secondary">
                  {subtitle}
                </Typography>
              )}
            </Box>
            {!editing && (
              <WatchItemCount control={methods.control} name={name}>
                {(count) =>
                  count > 1 && (
                    <Box
                      sx={{
                        px: 1.25,
                        py: 0.5,
                        borderRadius: 999,
                        fontSize: 12,
                        fontWeight: 700,
                        color: `${headerColor}.main`,
                        bgcolor: (theme) =>
                          alpha(
                            theme.palette[headerColor]?.main ?? theme.palette.primary.main,
                            0.12
                          ),
                      }}
                    >
                      {countLabel(count)}
                    </Box>
                  )
                }
              </WatchItemCount>
            )}
          </Stack>
        </DialogTitle>

        <DialogContent
          dividers
          sx={{
            bgcolor: 'background.neutral',
            p: { xs: 2, md: 3 },
          }}
        >
          {/* The key forces a fresh useFieldArray per open/entity session —
              methods.reset() alone does not always sync useFieldArray's
              internal field list, so leftover items from a previous create
              session could otherwise reappear (same safeguard as the source's
              explicit replace(initialItems) call). */}
          <FormItemAccordionList
            key={`${open}-${data?.id ?? 'new'}`}
            name={name}
            editing={editing}
            renderItemFields={renderItemFields}
            buildSummary={buildSummary}
            defaultItem={defaultItem}
            seedFromFirst={seedFromFirst}
            allowMultiple={allowMultiple && !editing}
            addLabel={addLabel}
            minItems={minItems}
            onRemoveItem={onRemoveItem}
            itemLabel={itemLabel}
            removeTooltip={removeTooltip}
            headerColor={headerColor}
          />
        </DialogContent>

        <DialogActions sx={{ px: 3, py: 2, gap: 1 }}>
          <Button onClick={onClose} color="inherit" disabled={submitting}>
            {cancelLabel}
          </Button>
          <Box sx={{ flex: 1 }} />
          {actions.map((action) => (
            <LoadingButton
              key={action.key}
              type="button"
              variant={action.variant ?? 'contained'}
              color={action.color ?? 'primary'}
              loading={loadingKey === action.key}
              disabled={submitting && loadingKey !== action.key}
              onClick={(event) => runAction(action, event)}
              startIcon={action.icon ? <Iconify icon={action.icon} /> : null}
            >
              {actionLabel(action)}
            </LoadingButton>
          ))}
        </DialogActions>
      </Form>
    </Dialog>
  );
}
