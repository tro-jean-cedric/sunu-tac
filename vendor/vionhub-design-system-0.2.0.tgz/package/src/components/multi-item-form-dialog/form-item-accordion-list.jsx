import { useState, useEffect } from 'react';
import { useWatch, useFieldArray, useFormContext } from 'react-hook-form';

import { Stack, alpha, Button } from '@mui/material';

import { Iconify } from 'src/components/iconify';

import { FormItemAccordion } from './form-item-accordion';

// ----------------------------------------------------------------------
// The 1..N item list of a multi-item form. Owns the `useFieldArray` for
// `name`, the single-expanded accordion state, add/remove, and the
// error-driven auto-expansion (on a failed submit, the first item in error
// is expanded so the user sees the messages). Must be rendered inside a
// react-hook-form context (<Form methods={methods}>).
//
//   <FormItemAccordionList
//     name="items"                             // field-array name (default 'items')
//     editing={false}                          // forwarded to renderItemFields
//     renderItemFields={({ index, editing }) => <ItemFields index={index} />}
//     buildSummary={(item, index) => `${item.object} · qté ${item.quantity}`}
//     defaultItem={emptyItem}                  // template appended by the add button
//     seedFromFirst={(first) => ({ department: first?.department ?? null })}
//     allowMultiple                            // false hides the add button
//     addLabel="Ajouter une demande"
//     minItems={1}                             // remove blocked at/below this count
//     onRemoveItem={(index) => ...}            // clean up parallel state (files, ...)
//     itemLabel={(index) => `Demande ${index + 1}`}
//     removeTooltip="Supprimer cette demande"
//     headerColor="primary"
//   />

// Per-item wrapper so each card watches only its own values — the collapsed
// summary stays live without re-rendering the siblings.
function FieldArrayItem({
  name,
  index,
  buildSummary,
  itemLabel,
  ...accordionProps
}) {
  const watched = useWatch({ name: `${name}.${index}` });
  const summary = buildSummary ? buildSummary(watched, index) : null;

  return (
    <FormItemAccordion
      index={index}
      summary={summary}
      label={itemLabel ? itemLabel(index) : undefined}
      {...accordionProps}
    />
  );
}

// ----------------------------------------------------------------------

export function FormItemAccordionList({
  name = 'items',
  renderItemFields,
  buildSummary,
  defaultItem,
  seedFromFirst,
  allowMultiple = true,
  addLabel = 'Ajouter un élément',
  minItems = 1,
  editing = false,
  onRemoveItem,
  itemLabel,
  removeTooltip,
  headerColor = 'primary',
  sx,
}) {
  const { control, getValues, formState } = useFormContext();
  const { fields, append, remove } = useFieldArray({ control, name });

  const [expandedIdx, setExpandedIdx] = useState(0);

  // Read both during render so RHF's formState proxy subscribes to them.
  const { errors, submitCount } = formState;

  // Error-driven auto-expansion: after a failed submit, open the first item
  // carrying an error so the user can see the messages.
  useEffect(() => {
    if (!submitCount) return;
    const itemErrors = errors?.[name];
    if (Array.isArray(itemErrors)) {
      const firstErrIdx = itemErrors.findIndex(Boolean);
      if (firstErrIdx >= 0) setExpandedIdx(firstErrIdx);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [submitCount]);

  // ---- item add/remove ----
  const handleAddItem = () => {
    const first = getValues(`${name}.0`);
    append({
      ...defaultItem,
      ...(seedFromFirst ? seedFromFirst(first) : {}),
    });
    // Open the new item, collapse all others. The new item's index is
    // fields.length because append hasn't applied yet for state but will
    // after this render.
    setExpandedIdx(fields.length);
  };

  const handleRemoveItem = (idx) => {
    if (fields.length <= minItems) return;
    remove(idx);
    onRemoveItem?.(idx);
    setExpandedIdx((prev) => {
      if (prev === idx) return Math.max(0, idx - 1);
      if (prev > idx) return prev - 1;
      return prev;
    });
  };

  return (
    <Stack spacing={1.5} sx={sx}>
      {fields.map((field, idx) => (
        <FieldArrayItem
          key={field.id}
          name={name}
          index={idx}
          expanded={expandedIdx === idx}
          onToggle={() => setExpandedIdx(expandedIdx === idx ? -1 : idx)}
          onRemove={fields.length > minItems ? () => handleRemoveItem(idx) : null}
          removable={fields.length > minItems}
          buildSummary={buildSummary}
          itemLabel={itemLabel}
          removeTooltip={removeTooltip}
          headerColor={headerColor}
        >
          {renderItemFields({ index: idx, editing })}
        </FieldArrayItem>
      ))}

      {allowMultiple && (
        <Button
          variant="outlined"
          fullWidth
          onClick={handleAddItem}
          startIcon={<Iconify icon="mingcute:add-line" />}
          sx={{
            py: 1.5,
            borderStyle: 'dashed',
            borderWidth: 1.5,
            fontWeight: 700,
            color: `${headerColor}.main`,
            borderColor: `${headerColor}.main`,
            '&:hover': {
              borderStyle: 'dashed',
              bgcolor: (theme) =>
                alpha(theme.palette[headerColor]?.main ?? theme.palette.primary.main, 0.06),
            },
          }}
        >
          {addLabel}
        </Button>
      )}
    </Stack>
  );
}
