import {
  Box,
  Stack,
  Paper,
  alpha,
  Tooltip,
  Collapse,
  Typography,
  IconButton,
} from '@mui/material';

import { Iconify } from 'src/components/iconify';

// ----------------------------------------------------------------------
// The numbered accordion card of a multi-item form: index badge, title,
// live summary when collapsed, optional remove button, and the form body
// as `children`. Purely presentational — expansion state and removal are
// owned by the parent (usually <FormItemAccordionList>).
//
//   <FormItemAccordion
//     index={0}                      // zero-based position (badge shows index + 1)
//     expanded={expandedIdx === 0}
//     onToggle={() => ...}
//     onRemove={() => ...}           // omit/null to hide the remove button
//     removable                      // false hides the remove button even with onRemove
//     summary="Organisationnelle · DSI · qté 2"   // collapsed subtitle (string|node)
//     label="Demande 1"              // header title; default `Élément ${index + 1}`
//     headerColor="primary"          // palette key driving the header accent
//     removeTooltip="Supprimer cette demande"
//   >
//     ...fields...
//   </FormItemAccordion>

const paletteMain = (theme, key) => theme.palette[key]?.main ?? theme.palette.primary.main;

export function FormItemAccordion({
  index,
  expanded,
  onToggle,
  onRemove,
  removable = true,
  summary,
  label,
  headerColor = 'primary',
  removeTooltip = 'Supprimer cet élément',
  children,
}) {
  const showRemove = removable && !!onRemove;

  return (
    <Paper
      variant="outlined"
      sx={{
        borderRadius: 2,
        borderColor: expanded ? 'transparent' : 'divider',
        bgcolor: expanded ? 'grey.200' : 'background.paper',
        overflow: 'hidden',
        transition: 'border-color 150ms ease, box-shadow 150ms ease',
        boxShadow: expanded
          ? (theme) => `0 1px 0 ${alpha(paletteMain(theme, headerColor), 0.9)}`
          : 'none',
      }}
    >
      {/* Header (toggle row) */}
      <Stack
        direction="row"
        alignItems="center"
        spacing={1.5}
        sx={{
          px: 2,
          py: 1.5,
          cursor: 'pointer',
          bgcolor: expanded
            ? (theme) => alpha(paletteMain(theme, headerColor), 0.8)
            : 'transparent',
        }}
        onClick={onToggle}
      >
        <Box
          sx={{
            width: 28,
            height: 28,
            borderRadius: 1,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: expanded ? `${headerColor}.main` : 'text.secondary',
            bgcolor: 'background.paper',
            fontWeight: 700,
            fontSize: 13,
          }}
        >
          {index + 1}
        </Box>
        <Box sx={{ flex: 1, minWidth: 0 }}>
          <Typography
            variant="subtitle2"
            sx={{ fontWeight: 700, color: expanded ? 'common.white' : `${headerColor}.main` }}
          >
            {label ?? `Élément ${index + 1}`}
          </Typography>
          {!expanded && summary && (
            <Typography variant="caption" color="text.secondary" noWrap component="div">
              {summary}
            </Typography>
          )}
        </Box>
        {showRemove && (
          <Tooltip title={removeTooltip} arrow>
            <IconButton
              size="small"
              color="error"
              onClick={(e) => {
                e.stopPropagation();
                onRemove();
              }}
              sx={{
                color: expanded ? 'common.white' : `${headerColor}.main`,
              }}
            >
              <Iconify icon="solar:trash-bin-trash-bold" width={18} />
            </IconButton>
          </Tooltip>
        )}
        <Iconify
          icon={expanded ? 'eva:arrow-ios-upward-fill' : 'eva:arrow-ios-downward-fill'}
          width={20}
          sx={{ color: expanded ? 'common.white' : 'text.secondary' }}
        />
      </Stack>

      {/* Body */}
      <Collapse in={expanded} unmountOnExit={false}>
        <Box
          sx={{ p: { xs: 2, md: 2.5 }, pt: 0, display: 'flex', flexDirection: 'column', gap: 2 }}
        >
          {children}
        </Box>
      </Collapse>
    </Paper>
  );
}
