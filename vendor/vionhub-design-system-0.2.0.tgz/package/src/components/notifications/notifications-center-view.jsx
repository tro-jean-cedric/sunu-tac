import { useRef, useMemo, useState, useEffect, useCallback } from 'react';

import Box from '@mui/material/Box';
import Tab from '@mui/material/Tab';
import Card from '@mui/material/Card';
import Stack from '@mui/material/Stack';
import Button from '@mui/material/Button';
import { alpha } from '@mui/material/styles';
import Container from '@mui/material/Container';
import Typography from '@mui/material/Typography';
import Pagination from '@mui/material/Pagination';
import CircularProgress from '@mui/material/CircularProgress';

import { Label } from 'src/components/label';
import { Iconify } from 'src/components/iconify';
import { CustomTabs } from 'src/components/custom-tabs';
import { CustomBreadcrumbs } from 'src/components/custom-breadcrumbs';

import { isNotificationRead } from './notifications-provider';
import { NotificationListItem } from './notification-list-item';
import { DEFAULT_NOTIFICATION_LABELS } from './notifications-drawer';

// ----------------------------------------------------------------------
// The v2 notifications-center page — the page-scale sibling of the drawer:
// CustomBreadcrumbs header with a conditional mark-all action, a Card with
// the unread/all tab bar, loading spinner, empty state, flat dashed-divider
// NotificationListItem rows (variant 'row') and a centered Pagination bound
// to server pages.
//
// The page owns its pagination state and fetches through `onFetchPage`; row
// interactions are optimistically reflected locally (mark-read tint, remove)
// exactly like the source app, while the authoritative counters live in the
// provider and flow back through `unreadCount`.

// ----------------------------------------------------------------------

const markRead = (notification) => ({ ...notification, read: true, isRead: true });

/**
 * NotificationsCenterView
 *
 * @param {object}   props
 * @param {string}   [props.heading='Notifications']  Page heading.
 * @param {Array}    [props.breadcrumbs=[]]           CustomBreadcrumbs links.
 * @param {number}   [props.unreadCount=0]            Count shown on the "Non lues" tab and gating the mark-all action.
 * @param {*}        [props.refreshToken]             Change this value to refetch the current page (e.g. after drawer-side mutations on the same store).
 * @param {number}   [props.pageSize=20]              Server page size.
 * @param {Function} props.onFetchPage                async ({ page, size, filter: 'unread'|'all' }) => ({ items, totalPages, totalElements }). Read through a latest-value ref, so inline literals are safe.
 * @param {Function} [props.onItemClick]              (notification) => void|Promise — mark-as-read / navigation is the caller's job; the clicked row is untinted locally.
 * @param {Function} [props.onItemRemove]             (notification) => void|Promise; omit to hide the delete buttons.
 * @param {Function} [props.onMarkAllRead]            () => void|Promise; omit to hide the header action.
 * @param {object}   [props.entityTypeLabels]         Forwarded to NotificationListItem.
 * @param {Function} [props.formatTime]               Forwarded to NotificationListItem.
 * @param {object}   [props.labels]                   Overrides merged over DEFAULT_NOTIFICATION_LABELS.
 * @param {object}   [props.sx]                       Container sx override.
 */
export function NotificationsCenterView({
  heading = 'Notifications',
  breadcrumbs = [],
  unreadCount = 0,
  refreshToken,
  pageSize = 20,
  onFetchPage,
  onItemClick,
  onItemRemove,
  onMarkAllRead,
  entityTypeLabels,
  formatTime,
  labels: labelsProp,
  sx,
}) {
  const labels = { ...DEFAULT_NOTIFICATION_LABELS, ...labelsProp };

  const [filter, setFilter] = useState('unread');
  const [page, setPage] = useState(0);
  const [items, setItems] = useState([]);
  const [totalPages, setTotalPages] = useState(1);
  const [totalElements, setTotalElements] = useState(0);
  const [loading, setLoading] = useState(false);

  // Latest-value ref so an inline `onFetchPage` prop doesn't re-fire the fetch
  // effect on every render (same pattern as NotificationsProvider's `api`).
  const onFetchPageRef = useRef(onFetchPage);
  onFetchPageRef.current = onFetchPage;
  const hasFetchPage = Boolean(onFetchPage);

  const fetchPage = useCallback(
    async (currentPage, currentFilter) => {
      if (!onFetchPageRef.current) return;
      setLoading(true);
      try {
        const data =
          (await onFetchPageRef.current({
            page: currentPage,
            size: pageSize,
            filter: currentFilter,
          })) ?? {};
        setItems(data.items ?? []);
        setTotalPages(data.totalPages ?? 1);
        setTotalElements(data.totalElements ?? 0);
      } catch {
        /* keep previous page on failure */
      } finally {
        setLoading(false);
      }
    },
    [hasFetchPage, pageSize]
  );

  useEffect(() => {
    fetchPage(page, filter);
  }, [page, filter, fetchPage, refreshToken]);

  const TABS = useMemo(
    () => [
      { value: 'unread', label: labels.unread, count: unreadCount },
      { value: 'all', label: labels.all, count: totalElements },
    ],
    [totalElements, unreadCount, labels.unread, labels.all]
  );

  const handleClick = async (notification) => {
    await onItemClick?.(notification);
    if (!isNotificationRead(notification)) {
      setItems((prev) => prev.map((n) => (n.id === notification.id ? markRead(n) : n)));
    }
  };

  const handleRemove = async (notification) => {
    await onItemRemove?.(notification);
    setItems((prev) => prev.filter((n) => n.id !== notification.id));
    setTotalElements((c) => Math.max(0, c - 1));
  };

  const handleMarkAll = async () => {
    await onMarkAllRead?.();
    setItems((prev) => prev.map(markRead));
  };

  return (
    <Container maxWidth="lg" sx={sx}>
      <CustomBreadcrumbs
        heading={heading}
        links={breadcrumbs}
        action={
          unreadCount > 0 &&
          onMarkAllRead && (
            <Button
              variant="contained"
              startIcon={<Iconify icon="eva:done-all-fill" />}
              onClick={handleMarkAll}
            >
              {labels.markAll}
            </Button>
          )
        }
        sx={{ mb: { xs: 3, md: 5 } }}
      />

      <Card>
        <CustomTabs
          value={filter}
          onChange={(_, v) => {
            setFilter(v);
            setPage(0);
          }}
          sx={{ px: 2.5, boxShadow: (t) => `inset 0 -2px 0 0 ${alpha(t.palette.grey[500], 0.08)}` }}
        >
          {TABS.map((tab) => (
            <Tab
              key={tab.value}
              iconPosition="end"
              value={tab.value}
              label={tab.label}
              icon={
                <Label
                  variant={tab.value === filter ? 'filled' : 'soft'}
                  color={(tab.value === 'unread' && 'info') || 'default'}
                >
                  {tab.count}
                </Label>
              }
            />
          ))}
        </CustomTabs>

        {loading && (
          <Box sx={{ p: 4, textAlign: 'center' }}>
            <CircularProgress size={28} />
          </Box>
        )}

        {!loading && items.length === 0 && (
          <Box sx={{ p: 8, textAlign: 'center', color: 'text.disabled' }}>
            <Iconify icon="solar:bell-off-bold-duotone" width={56} sx={{ mb: 1 }} />
            <Typography variant="body2">
              {filter === 'unread' ? labels.emptyUnread : labels.emptyAll}
            </Typography>
          </Box>
        )}

        {!loading && items.length > 0 && (
          <Stack divider={<Box sx={{ borderTop: '1px dashed', borderColor: 'divider' }} />}>
            {items.map((notification) => (
              <NotificationListItem
                key={notification.id}
                variant="row"
                notification={notification}
                entityTypeLabels={entityTypeLabels}
                formatTime={formatTime}
                onClick={() => handleClick(notification)}
                onRemove={onItemRemove ? () => handleRemove(notification) : undefined}
              />
            ))}
          </Stack>
        )}

        {totalPages > 1 && (
          <Box sx={{ p: 2, display: 'flex', justifyContent: 'center' }}>
            <Pagination
              count={totalPages}
              page={page + 1}
              onChange={(_, value) => setPage(value - 1)}
              color="primary"
            />
          </Box>
        )}
      </Card>
    </Container>
  );
}
