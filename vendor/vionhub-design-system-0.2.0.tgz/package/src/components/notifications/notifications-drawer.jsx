import { m } from 'framer-motion';
import { useMemo, useState, useCallback } from 'react';

import Tab from '@mui/material/Tab';
import Box from '@mui/material/Box';
import Stack from '@mui/material/Stack';
import Badge from '@mui/material/Badge';
import Drawer from '@mui/material/Drawer';
import Button from '@mui/material/Button';
import Tooltip from '@mui/material/Tooltip';
import Typography from '@mui/material/Typography';
import IconButton from '@mui/material/IconButton';

import { useBoolean } from 'src/hooks/use-boolean';

import { Label } from 'src/components/label';
import { Iconify } from 'src/components/iconify';
import { varHover } from 'src/components/animate';
import { Scrollbar } from 'src/components/scrollbar';
import { CustomTabs } from 'src/components/custom-tabs';

import { isNotificationRead } from './notifications-provider';
import { NotificationListItem } from './notification-list-item';

// ----------------------------------------------------------------------
// The v2 notifications bell + right drawer, fully controlled: the bell
// IconButton (Badge = unreadCount) opens a Drawer with a title row
// (mark-all icon, mobile close), an unread/all tab bar with count Labels, a
// Scrollbar list of NotificationListItems (per-tab empty state, unread-first
// sort on "all") and an optional full-width "view all" footer.
//
// Typically fed straight from useNotifications() by the host app:
//   const { notifications, unreadCount, markAsRead, markAllAsRead, remove } = useNotifications();
//   <NotificationsDrawer
//     notifications={notifications}
//     unreadCount={unreadCount}
//     onMarkAllRead={markAllAsRead}
//     onItemClick={(n) => { if (!n.read) markAsRead(n.id); if (n.link) router.push(n.link); }}
//     onItemRemove={(n) => remove(n.id)}
//     onViewAll={() => router.push('/dashboard/notifications')}
//   />

// ----------------------------------------------------------------------

export const DEFAULT_NOTIFICATION_LABELS = {
  title: 'Notifications',
  unread: 'Non lues',
  all: 'Toutes',
  markAll: 'Tout marquer comme lu',
  viewAll: 'Voir toutes les notifications',
  emptyUnread: 'Aucune notification non lue',
  emptyAll: 'Aucune notification',
};

// ----------------------------------------------------------------------

/**
 * NotificationsDrawer
 *
 * @param {object}   props
 * @param {Array}    [props.notifications=[]]   Notification objects (see NotificationListItem for the shape).
 * @param {number}   [props.unreadCount=0]      Badge / tab count.
 * @param {Function} [props.onMarkAllRead]      Mark-all handler (header icon, shown while unreadCount > 0).
 * @param {Function} [props.onItemClick]        (notification) => void — mark-as-read / navigation is the caller's job. The drawer closes itself when the notification has a `link`.
 * @param {Function} [props.onItemRemove]       (notification) => void; omit to hide the per-item delete button.
 * @param {Function} [props.onViewAll]          Footer "view all" handler; omit to hide the footer. The drawer closes itself first.
 * @param {object}   [props.entityTypeLabels]   Forwarded to NotificationListItem.
 * @param {Function} [props.formatTime]         Forwarded to NotificationListItem.
 * @param {object}   [props.labels]             Overrides merged over DEFAULT_NOTIFICATION_LABELS ({ title, unread, all, markAll, viewAll, emptyUnread, emptyAll }).
 * @param {object}   [props.slotProps]          { drawer, button } — extra props for the Drawer and the bell IconButton.
 * @param {object}   [props.sx]                 sx of the bell IconButton (rest props are spread on it too).
 */
export function NotificationsDrawer({
  notifications = [],
  unreadCount = 0,
  onMarkAllRead,
  onItemClick,
  onItemRemove,
  onViewAll,
  entityTypeLabels,
  formatTime,
  labels: labelsProp,
  slotProps,
  sx,
  ...other
}) {
  const drawer = useBoolean();

  const labels = { ...DEFAULT_NOTIFICATION_LABELS, ...labelsProp };

  const [currentTab, setCurrentTab] = useState('unread');

  const handleChangeTab = useCallback((event, newValue) => {
    setCurrentTab(newValue);
  }, []);

  const filtered = useMemo(() => {
    if (currentTab === 'unread') return notifications.filter((n) => !isNotificationRead(n));
    // "Toutes" tab: show unread notifications first, keeping original order within each group
    return [...notifications].sort(
      (a, b) => Number(isNotificationRead(a)) - Number(isNotificationRead(b))
    );
  }, [notifications, currentTab]);

  const TABS = useMemo(
    () => [
      { value: 'unread', label: labels.unread, count: unreadCount },
      { value: 'all', label: labels.all, count: notifications.length },
    ],
    [notifications.length, unreadCount, labels.unread, labels.all]
  );

  const handleViewAll = () => {
    drawer.onFalse();
    onViewAll?.();
  };

  const handleItemClick = (notification) => {
    onItemClick?.(notification);
    // Mirror the app: a notification carrying a link navigates away, so the
    // drawer closes itself.
    if (notification.link) drawer.onFalse();
  };

  const renderHead = (
    <Stack direction="row" alignItems="center" sx={{ py: 2, pl: 2.5, pr: 1, minHeight: 68 }}>
      <Typography variant="h6" sx={{ flexGrow: 1 }}>
        {labels.title}
      </Typography>

      {!!unreadCount && onMarkAllRead && (
        <Tooltip title={labels.markAll}>
          <IconButton color="primary" onClick={onMarkAllRead}>
            <Iconify icon="eva:done-all-fill" />
          </IconButton>
        </Tooltip>
      )}

      <IconButton onClick={drawer.onFalse} sx={{ display: { xs: 'inline-flex', sm: 'none' } }}>
        <Iconify icon="mingcute:close-line" />
      </IconButton>
    </Stack>
  );

  const renderTabs = (
    <CustomTabs variant="fullWidth" value={currentTab} onChange={handleChangeTab}>
      {TABS.map((tab) => (
        <Tab
          key={tab.value}
          iconPosition="end"
          value={tab.value}
          label={tab.label}
          icon={
            <Label
              variant={(tab.value === currentTab && 'filled') || 'soft'}
              color={(tab.value === 'unread' && 'info') || 'default'}
            >
              {tab.count}
            </Label>
          }
        />
      ))}
    </CustomTabs>
  );

  const renderEmpty = (
    <Box sx={{ p: 4, textAlign: 'center', color: 'text.disabled' }}>
      <Iconify icon="solar:bell-off-bold-duotone" width={40} sx={{ mb: 1 }} />
      <Typography variant="body2">
        {currentTab === 'unread' ? labels.emptyUnread : labels.emptyAll}
      </Typography>
    </Box>
  );

  const renderList = (
    <Scrollbar>
      <Box component="ul">
        {filtered.length === 0 && renderEmpty}
        {filtered.map((notification) => (
          <Box component="li" key={notification.id} sx={{ display: 'flex' }}>
            <NotificationListItem
              notification={notification}
              entityTypeLabels={entityTypeLabels}
              formatTime={formatTime}
              onClick={() => handleItemClick(notification)}
              onRemove={onItemRemove ? () => onItemRemove(notification) : undefined}
            />
          </Box>
        ))}
      </Box>
    </Scrollbar>
  );

  return (
    <>
      <IconButton
        component={m.button}
        whileTap="tap"
        whileHover="hover"
        variants={varHover(1.05)}
        onClick={drawer.onTrue}
        sx={{ color: 'primary.main', ...sx }}
        {...slotProps?.button}
        {...other}
      >
        <Badge badgeContent={unreadCount} color="error">
          <Iconify icon="solar:bell-outline" width={24} />
        </Badge>
      </IconButton>

      <Drawer
        open={drawer.value}
        onClose={drawer.onFalse}
        anchor="right"
        slotProps={{ backdrop: { invisible: true } }}
        PaperProps={{ sx: { width: 1, maxWidth: 420 } }}
        {...slotProps?.drawer}
      >
        {renderHead}

        {renderTabs}

        {renderList}

        {onViewAll && (
          <Box sx={{ p: 1 }}>
            <Button fullWidth size="large" onClick={handleViewAll}>
              {labels.viewAll}
            </Button>
          </Box>
        )}
      </Drawer>
    </>
  );
}
