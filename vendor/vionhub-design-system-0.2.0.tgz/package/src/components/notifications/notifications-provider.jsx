import { useRef, useMemo, useState, useEffect, useContext, useCallback, createContext } from 'react';

// ----------------------------------------------------------------------
// Headless notifications state — the v2 notifications context, decoupled from
// any HTTP client / auth / SSE endpoint. The consumer supplies an `api`
// adapter (promise-based, resolves data or throws) and an optional
// `subscribe` function that wires a live push channel (SSE, WebSocket, ...).
//
// Expected notification shape (extra fields pass through untouched):
//   { id, type: 'INFO'|'SUCCESS'|'WARNING'|'ERROR', title, body, link,
//     read (or isRead), createdAt, entityType (or sourceEntityType) }
//
// Behavior (kept intact from the source app):
// - initial list + unread-count fetch when `enabled` turns true;
// - `subscribe` hook-up with de-dupe by id (reconnects may replay events),
//   prepend-newest, unread bump and an autoplay-safe Audio chime (only when
//   `soundUrl` is set — the play() rejection before the first user
//   interaction is silently swallowed);
// - polling fallback on the unread count so stale state (suspended tab,
//   network blip) self-heals even while the push channel is open;
// - optimistic markAsRead / markAllAsRead / remove with rollback-by-refresh
//   when the API call throws.
//
// `api`, `subscribe` and `soundUrl` are read through refs, so inline
// object/function literals are safe (they will not retrigger the bootstrap
// effect). The subscription is (re)established when `enabled` flips.

// ----------------------------------------------------------------------

/** Tolerant read of the "read" flag (`read` in the DS shape, `isRead` in the app payloads). */
export function isNotificationRead(notification) {
  return Boolean(notification?.read ?? notification?.isRead);
}

const markRead = (notification) => ({ ...notification, read: true, isRead: true });

// `list()` may resolve a raw array or a Spring-style page ({ content: [...] }).
const normalizeList = (data) => {
  const content = data?.content ?? data ?? [];
  return Array.isArray(content) ? content : [];
};

// `unreadCount()` may resolve a number or an object ({ unreadCount: n }).
const normalizeCount = (data) => {
  if (typeof data === 'number') return data;
  return data?.unreadCount ?? 0;
};

// ----------------------------------------------------------------------

const NotificationsContext = createContext({
  notifications: [],
  unreadCount: 0,
  loading: false,
  refresh: () => {},
  markAsRead: () => {},
  markAllAsRead: () => {},
  remove: () => {},
});

export function useNotifications() {
  return useContext(NotificationsContext);
}

// ----------------------------------------------------------------------

/**
 * NotificationsProvider — headless provider for the notifications stack.
 *
 * @param {object}   props
 * @param {boolean}  [props.enabled=true]        Gate for the whole machinery (typically "authenticated"). While false nothing is fetched and the state stays empty.
 * @param {object}   props.api                   Adapter object; each method resolves data or throws:
 *                                               - list({ page, size }) → array or { content: [...] }
 *                                               - unreadCount() → number or { unreadCount }
 *                                               - markRead(id), markAllRead(), remove(id)
 * @param {Function} [props.subscribe]           (onNotification) => unsubscribe. Wire your push channel here (the app builds its own EventSource inside) and invoke `onNotification(dto)` per incoming notification.
 * @param {string}   [props.soundUrl]            URL of a short chime played when a new unread notification arrives. Omit for silence.
 * @param {number}   [props.pollIntervalMs=60000] Unread-count polling fallback. 0 disables polling.
 * @param {number}   [props.pageSize=30]          Page size of the initial / refreshed list fetch.
 * @param {*}        props.children
 */
export function NotificationsProvider({
  enabled = true,
  api,
  subscribe,
  soundUrl,
  pollIntervalMs = 60_000,
  pageSize = 30,
  children,
}) {
  const [notifications, setNotifications] = useState([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [loading, setLoading] = useState(false);

  const audioRef = useRef(null);

  // Latest-value refs so inline `api` / `subscribe` props (and a changing
  // `soundUrl`) don't retrigger the bootstrap effect on every render.
  const apiRef = useRef(api);
  apiRef.current = api;
  const subscribeRef = useRef(subscribe);
  subscribeRef.current = subscribe;
  const soundUrlRef = useRef(soundUrl);
  soundUrlRef.current = soundUrl;

  // Rebuild the Audio element when `soundUrl` changes so the new chime is
  // actually picked up on the next play.
  useEffect(() => {
    audioRef.current = null;
  }, [soundUrl]);

  // Lazily build the Audio element on first need so SSR / non-browser
  // environments don't blow up. The element is reused across plays. Dep-free
  // (reads `soundUrl` through a ref) so sound configuration cannot disturb
  // the subscription/fetch lifecycle in the bootstrap effect.
  const playNotificationSound = useCallback(() => {
    if (typeof window === 'undefined' || !soundUrlRef.current) return;
    if (!audioRef.current) {
      audioRef.current = new Audio(soundUrlRef.current);
      audioRef.current.preload = 'auto';
      audioRef.current.volume = 0.6;
    }
    try {
      audioRef.current.currentTime = 0;
      const playPromise = audioRef.current.play();
      if (playPromise && typeof playPromise.catch === 'function') {
        playPromise.catch(() => {
          /* autoplay blocked before first user interaction — ignore */
        });
      }
    } catch {
      /* ignore */
    }
  }, []);

  const refresh = useCallback(async () => {
    if (!enabled) return;
    setLoading(true);
    try {
      const [listData, countData] = await Promise.all([
        apiRef.current.list({ page: 0, size: pageSize }),
        apiRef.current.unreadCount(),
      ]);
      setNotifications(normalizeList(listData));
      setUnreadCount(normalizeCount(countData));
    } catch {
      /* keep previous state on failure */
    } finally {
      setLoading(false);
    }
  }, [enabled, pageSize]);

  const markAsRead = useCallback(
    async (id) => {
      // Optimistic update so the drawer feels instant.
      setNotifications((prev) =>
        prev.map((n) => (n.id === id && !isNotificationRead(n) ? markRead(n) : n))
      );
      setUnreadCount((c) => Math.max(0, c - 1));
      try {
        await apiRef.current.markRead(id);
      } catch {
        // Roll back on failure.
        refresh();
      }
    },
    [refresh]
  );

  const markAllAsRead = useCallback(async () => {
    setNotifications((prev) => prev.map(markRead));
    setUnreadCount(0);
    try {
      await apiRef.current.markAllRead();
    } catch {
      refresh();
    }
  }, [refresh]);

  const remove = useCallback(
    async (id) => {
      let wasUnread = false;
      setNotifications((prev) => {
        const target = prev.find((n) => n.id === id);
        wasUnread = Boolean(target) && !isNotificationRead(target);
        return prev.filter((n) => n.id !== id);
      });
      setUnreadCount((c) => (wasUnread ? Math.max(0, c - 1) : c));
      try {
        await apiRef.current.remove(id);
      } catch {
        refresh();
      }
    },
    [refresh]
  );

  // Bootstrap: initial fetch, push-channel subscription and the polling
  // fallback — all gated on `enabled` and torn down together.
  useEffect(() => {
    if (!enabled) return undefined;

    refresh();

    let unsubscribe;
    if (subscribeRef.current) {
      unsubscribe = subscribeRef.current((dto) => {
        if (!dto || dto.id == null) return;
        let isNew = false;
        // Prepend so newest is on top; de-dupe in case the same notification
        // arrives twice during a reconnect.
        setNotifications((prev) => {
          if (prev.some((n) => n.id === dto.id)) return prev;
          isNew = true;
          return [dto, ...prev];
        });
        if (isNew && !isNotificationRead(dto)) {
          setUnreadCount((c) => c + 1);
          playNotificationSound();
        }
      });
    }

    // Polling fallback for the unread count.
    let interval = null;
    if (pollIntervalMs > 0) {
      interval = setInterval(() => {
        Promise.resolve(apiRef.current.unreadCount())
          .then((data) => setUnreadCount(normalizeCount(data)))
          .catch(() => {
            /* transient failure — next tick retries */
          });
      }, pollIntervalMs);
    }

    return () => {
      if (typeof unsubscribe === 'function') unsubscribe();
      if (interval) clearInterval(interval);
    };
  }, [enabled, pollIntervalMs, refresh]);

  const value = useMemo(
    () => ({ notifications, unreadCount, loading, refresh, markAsRead, markAllAsRead, remove }),
    [notifications, unreadCount, loading, refresh, markAsRead, markAllAsRead, remove]
  );

  return <NotificationsContext.Provider value={value}>{children}</NotificationsContext.Provider>;
}
