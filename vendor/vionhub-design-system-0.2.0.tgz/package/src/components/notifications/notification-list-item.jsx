import Box from '@mui/material/Box';
import Stack from '@mui/material/Stack';
import Tooltip from '@mui/material/Tooltip';
import Typography from '@mui/material/Typography';
import IconButton from '@mui/material/IconButton';
import ListItemText from '@mui/material/ListItemText';
import { alpha, useTheme } from '@mui/material/styles';
import ListItemAvatar from '@mui/material/ListItemAvatar';
import ListItemButton from '@mui/material/ListItemButton';

import { fToNow } from 'src/utils/format-time';

import { Iconify } from 'src/components/iconify';

import { isNotificationRead } from './notifications-provider';

// ----------------------------------------------------------------------
// A single notification row — the v2 design: type icon bubble, unread dot +
// tinted background when unread, body, time-ago + entity-type caption and a
// delete button. Two variants:
// - 'drawer' (default): the drawer list item — dashed bottom border, absolute
//   unread dot, hover-revealed close button;
// - 'row': the flat notifications-center page style — inline unread dot next
//   to the title, always-visible trash button; the parent supplies the dashed
//   dividers between rows.

// ----------------------------------------------------------------------

const TYPE_VISUAL = {
  INFO: { icon: 'solar:info-circle-bold', color: 'info' },
  SUCCESS: { icon: 'solar:check-circle-bold', color: 'success' },
  WARNING: { icon: 'solar:bell-bing-bold', color: 'warning' },
  ERROR: { icon: 'solar:close-circle-bold', color: 'error' },
};

const typeVisual = (type) => TYPE_VISUAL[type] ?? TYPE_VISUAL.INFO;

// Sensible French defaults for the VionHub procurement domain — override /
// extend via the `entityTypeLabels` prop. Unknown types fall back to the raw
// value.
export const DEFAULT_ENTITY_TYPE_LABELS = {
  REQUEST: 'Demande',
  PURCHASE_ORDER: 'Bon de commande',
};

// ----------------------------------------------------------------------

/**
 * NotificationListItem
 *
 * @param {object}   props
 * @param {object}   props.notification            { id, type?, title?, body?, createdAt, read (or isRead), entityType (or sourceEntityType), link? }
 * @param {Function} [props.onClick]               Row click handler (mark-as-read / navigation is the caller's job).
 * @param {Function} [props.onRemove]              Delete handler; omit to hide the delete button.
 * @param {object}   [props.entityTypeLabels]      Map entityType → caption label. Defaults to the VionHub map (REQUEST / PURCHASE_ORDER).
 * @param {Function} [props.formatTime=fToNow]     (createdAt) => string shown in the caption (defaults to the DS time-ago formatter).
 * @param {'drawer'|'row'} [props.variant='drawer'] Visual variant (see above).
 * @param {string}   [props.deleteLabel='Supprimer'] Tooltip of the delete button.
 * @param {object}   [props.sx]                    Root sx override.
 */
export function NotificationListItem({
  notification,
  onClick,
  onRemove,
  entityTypeLabels = DEFAULT_ENTITY_TYPE_LABELS,
  formatTime = fToNow,
  variant = 'drawer',
  deleteLabel = 'Supprimer',
  sx,
}) {
  const theme = useTheme();

  const read = isNotificationRead(notification);
  const entityType = notification.entityType ?? notification.sourceEntityType;

  const visual = typeVisual(notification.type);
  const paletteColor = theme.palette[visual.color]?.main ?? theme.palette.info.main;

  const captionDivider = (
    <Box sx={{ width: 2, height: 2, bgcolor: 'currentColor', mx: 0.5, borderRadius: '50%' }} />
  );

  const iconBubble = (
    <Stack
      alignItems="center"
      justifyContent="center"
      sx={{
        width: 40,
        height: 40,
        borderRadius: '50%',
        color: paletteColor,
        bgcolor: alpha(paletteColor, 0.12),
        flexShrink: 0,
      }}
    >
      <Iconify icon={visual.icon} width={22} />
    </Stack>
  );

  // --------------------------------------------------------------------
  // 'row' variant — flat page style.

  if (variant === 'row') {
    return (
      <Stack
        direction="row"
        spacing={2}
        alignItems="flex-start"
        sx={{
          p: 2.5,
          cursor: onClick ? 'pointer' : 'default',
          bgcolor: !read ? alpha(theme.palette.info.main, 0.04) : 'transparent',
          '&:hover': { bgcolor: alpha(theme.palette.action.hover, 0.5) },
          ...sx,
        }}
        onClick={onClick}
      >
        {iconBubble}

        <Box sx={{ flex: 1, minWidth: 0 }}>
          <Stack direction="row" alignItems="center" spacing={1}>
            <Typography variant="subtitle2" sx={{ fontWeight: !read ? 700 : 500 }}>
              {notification.title}
            </Typography>
            {!read && (
              <Box sx={{ width: 8, height: 8, borderRadius: '50%', bgcolor: 'info.main' }} />
            )}
          </Stack>

          {notification.body && (
            <Typography variant="body2" sx={{ color: 'text.secondary', mt: 0.5 }}>
              {notification.body}
            </Typography>
          )}

          <Stack
            direction="row"
            alignItems="center"
            sx={{ mt: 0.75, typography: 'caption', color: 'text.disabled' }}
            divider={captionDivider}
          >
            <span>{formatTime(notification.createdAt)}</span>
            {entityType && <span>{entityTypeLabels[entityType] ?? entityType}</span>}
          </Stack>
        </Box>

        {onRemove && (
          <Tooltip title={deleteLabel}>
            <IconButton
              size="small"
              onClick={(e) => {
                e.stopPropagation();
                onRemove();
              }}
            >
              <Iconify icon="solar:trash-bin-trash-bold" width={18} />
            </IconButton>
          </Tooltip>
        )}
      </Stack>
    );
  }

  // --------------------------------------------------------------------
  // 'drawer' variant (default).

  return (
    <ListItemButton
      disableRipple
      onClick={onClick}
      sx={{
        p: 2.5,
        alignItems: 'flex-start',
        borderBottom: (t) => `dashed 1px ${t.vars.palette.divider}`,
        bgcolor: !read ? (t) => alpha(t.palette.info.main, 0.04) : 'transparent',
        ...sx,
      }}
    >
      {!read && (
        <Box
          sx={{
            top: 26,
            width: 8,
            height: 8,
            right: 20,
            borderRadius: '50%',
            bgcolor: 'info.main',
            position: 'absolute',
          }}
        />
      )}

      {onRemove && (
        <Tooltip title={deleteLabel}>
          <IconButton
            size="small"
            onClick={(e) => {
              e.stopPropagation();
              onRemove();
            }}
            sx={{
              position: 'absolute',
              top: 8,
              right: 8,
              opacity: 0,
              transition: 'opacity 150ms ease',
              '.MuiListItemButton-root:hover &': { opacity: 1 },
            }}
          >
            <Iconify icon="mingcute:close-line" width={16} />
          </IconButton>
        </Tooltip>
      )}

      <ListItemAvatar>{iconBubble}</ListItemAvatar>

      <Stack sx={{ flexGrow: 1 }}>
        <ListItemText
          disableTypography
          primary={
            <Typography variant="subtitle2" sx={{ mb: 0.25 }}>
              {notification.title}
            </Typography>
          }
          secondary={
            <>
              {notification.body && (
                <Typography variant="body2" sx={{ color: 'text.secondary', mb: 0.5 }}>
                  {notification.body}
                </Typography>
              )}
              <Stack
                direction="row"
                alignItems="center"
                sx={{ typography: 'caption', color: 'text.disabled' }}
                divider={captionDivider}
              >
                <span>{formatTime(notification.createdAt)}</span>
                {entityType && <span>{entityTypeLabels[entityType] ?? entityType}</span>}
              </Stack>
            </>
          }
        />
      </Stack>
    </ListItemButton>
  );
}
