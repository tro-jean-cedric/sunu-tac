import { useRef, useState, useContext, useCallback, createContext } from 'react';

import {
  Box,
  Stack,
  alpha,
  Dialog,
  Button,
  DialogTitle,
  DialogContent,
  DialogActions,
  DialogContentText,
} from '@mui/material';

import { Iconify } from 'src/components/iconify';

// ----------------------------------------------------------------------
// Programmatic confirm — v2 equivalent of v1's AlertUtils.sweetConfirm.
//
//   const confirm = useConfirm();
//   const ok = await confirm({
//     title: 'Attention',
//     message: 'Voulez-vous transférer cette demande ?',
//     confirmText: 'Oui', cancelText: 'Non',
//     color: 'primary' | 'error' | 'warning' | 'success' | 'info',
//   });
//   if (!ok) return;

/**
 * Options accepted by the programmatic confirm function.
 * @typedef {object} ConfirmOptions
 * @property {import('react').ReactNode} [title] Defaults to the provider's
 *   `defaultTexts.title`, then to `'Confirmation'`.
 * @property {import('react').ReactNode} [message] Defaults to the provider's
 *   `defaultTexts.message`, then to `'Êtes-vous sûr ?'`.
 * @property {import('react').ReactNode} [confirmText] Defaults to `'Oui'`.
 * @property {import('react').ReactNode} [cancelText] Defaults to `'Non'`.
 * @property {ConfirmColor} [color] Icon and confirm-button color. Default `'primary'`.
 */

/**
 * Colors the confirm dialog knows how to render (each maps to an icon).
 * @typedef {'primary' | 'info' | 'warning' | 'error' | 'success'} ConfirmColor
 */

/**
 * Opens the confirm dialog and resolves with the user's answer.
 * @typedef {(options?: ConfirmOptions) => Promise<boolean>} ConfirmFn
 */

/** @type {import('react').Context<ConfirmFn | null>} */
const ConfirmContext = createContext(null);

/**
 * Returns the programmatic confirm function.
 * @returns {ConfirmFn}
 * @throws {Error} When used outside a `<ConfirmProvider>`.
 */
export function useConfirm() {
  const ctx = useContext(ConfirmContext);
  if (!ctx) throw new Error('useConfirm must be used inside <ConfirmProvider>');
  return ctx;
}

// Optional variant: returns null instead of throwing when no <ConfirmProvider>
// is mounted, for components that only need confirm gating when it's available.
/**
 * Same as {@link useConfirm} but returns `null` instead of throwing when no
 * `<ConfirmProvider>` is mounted.
 * @returns {ConfirmFn | null}
 */
export function useOptionalConfirm() {
  try {
    // useConfirm only throws on the missing-context check; the underlying
    // useContext call is unconditional, so hook order stays stable.
    return useConfirm();
  } catch {
    return null;
  }
}

const ICONS = {
  primary: 'solar:question-circle-bold',
  info: 'solar:info-circle-bold',
  warning: 'solar:danger-circle-bold',
  error: 'solar:trash-bin-trash-bold',
  success: 'solar:check-circle-bold',
};

const DEFAULT_TEXTS = {
  title: 'Confirmation',
  message: 'Êtes-vous sûr ?',
  confirmText: 'Oui',
  cancelText: 'Non',
};

/**
 * @typedef {object} ConfirmProviderProps
 * @property {import('react').ReactNode} [children]
 * @property {{
 *   title?: import('react').ReactNode;
 *   message?: import('react').ReactNode;
 *   confirmText?: import('react').ReactNode;
 *   cancelText?: import('react').ReactNode;
 * }} [defaultTexts] Overrides the built-in French default labels.
 */

/**
 * Provides the programmatic confirm dialog (`useConfirm`) to the tree and
 * renders the single shared dialog.
 * @param {ConfirmProviderProps} props
 * @returns {import('react').JSX.Element}
 */
export function ConfirmProvider({ children, defaultTexts }) {
  const textsRef = useRef({ ...DEFAULT_TEXTS, ...defaultTexts });
  textsRef.current = { ...DEFAULT_TEXTS, ...defaultTexts };

  const [state, setState] = useState({
    open: false,
    title: '',
    message: '',
    confirmText: textsRef.current.confirmText,
    cancelText: textsRef.current.cancelText,
    color: 'primary',
  });
  const resolverRef = useRef(null);

  const close = useCallback((value) => {
    setState((s) => ({ ...s, open: false }));
    resolverRef.current?.(value);
    resolverRef.current = null;
  }, []);

  const confirm = useCallback((opts = {}) => {
    setState({
      open: true,
      title: opts.title ?? textsRef.current.title,
      message: opts.message ?? textsRef.current.message,
      confirmText: opts.confirmText ?? textsRef.current.confirmText,
      cancelText: opts.cancelText ?? textsRef.current.cancelText,
      color: opts.color ?? 'primary',
    });
    return new Promise((resolve) => {
      resolverRef.current = resolve;
    });
  }, []);

  const icon = ICONS[state.color] ?? ICONS.primary;

  return (
    <ConfirmContext.Provider value={confirm}>
      {children}
      <Dialog
        open={state.open}
        onClose={() => close(false)}
        maxWidth="xs"
        fullWidth
        PaperProps={{ sx: { borderRadius: 2 } }}
      >
        <DialogTitle sx={{ pb: 1 }}>
          <Stack direction="row" alignItems="center" spacing={1.5}>
            <Box
              sx={{
                width: 40,
                height: 40,
                borderRadius: '50%',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: `${state.color}.main`,
                bgcolor: (t) => alpha(t.palette[state.color].main, 0.12),
              }}
            >
              <Iconify icon={icon} width={22} />
            </Box>
            <Box>{state.title}</Box>
          </Stack>
        </DialogTitle>
        <DialogContent>
          <DialogContentText sx={{ color: 'text.secondary' , padding:'0px', display:'flex', alignItems:'center', justifyContent:'center', minHeight:'5em' }}>{state.message}</DialogContentText>
        </DialogContent>
        <DialogActions sx={{ px: 3, py: 2, borderTop: (t) => `1px solid ${t.palette.divider}` }}>
          <Button onClick={() => close(false)} color="inherit">
            {state.cancelText}
          </Button>
          <Button
            onClick={() => close(true)}
            variant="contained"
            color={state.color}
            autoFocus
          >
            {state.confirmText}
          </Button>
        </DialogActions>
      </Dialog>
    </ConfirmContext.Provider>
  );
}
