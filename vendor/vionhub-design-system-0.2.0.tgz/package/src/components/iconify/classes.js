/**
 * CSS class names applied by `<Iconify />`.
 *
 * @type {{ root: string }}
 */
export const iconifyClasses = {
  root: 'mnl__icon__root',
};
