import { forwardRef } from 'react';
import { Icon, disableCache } from '@iconify/react';

import Box from '@mui/material/Box';
import NoSsr from '@mui/material/NoSsr';

import { iconifyClasses } from './classes';

// ----------------------------------------------------------------------

/**
 * Own props of `<Iconify />`.
 *
 * @typedef {object} IconifyOwnProps
 * @property {import('@iconify/react').IconifyIcon | string} icon Iconify icon name (e.g. `solar:home-bold`) or an inline icon object.
 * @property {number | string} [width] Square size in px; also used as the height. Defaults to `20`.
 * @property {number | string} [height] Explicit height, when it must differ from `width`.
 * @property {string} [className] Appended after the `iconifyClasses.root` class.
 * @property {import('@mui/material').SxProps<import('@mui/material').Theme>} [sx]
 */

/**
 * Props of `<Iconify />`: own props plus the remaining `@iconify/react` `<Icon />`
 * props, which are spread onto the underlying element.
 *
 * @typedef {IconifyOwnProps & Omit<import('@iconify/react').IconProps, 'icon' | 'width' | 'height' | 'className' | 'ref' | 'style'>} IconifyProps
 */

/**
 * Icon renderer backed by `@iconify/react`, sized and styled through the MUI system.
 *
 * @type {import('react').ForwardRefExoticComponent<IconifyProps & import('react').RefAttributes<SVGSVGElement>>}
 */
export const Iconify = forwardRef(({ className, width = 20, sx, ...other }, ref) => {
  const baseStyles = {
    width,
    height: width,
    flexShrink: 0,
    display: 'inline-flex',
  };

  const renderFallback = (
    <Box
      component="span"
      className={iconifyClasses.root.concat(className ? ` ${className}` : '')}
      sx={{ ...baseStyles, ...sx }}
    />
  );

  return (
    <NoSsr fallback={renderFallback}>
      <Box
        ref={ref}
        component={Icon}
        className={iconifyClasses.root.concat(className ? ` ${className}` : '')}
        sx={{ ...baseStyles, ...sx }}
        {...other}
      />
    </NoSsr>
  );
});

// https://iconify.design/docs/iconify-icon/disable-cache.html
disableCache('local');
