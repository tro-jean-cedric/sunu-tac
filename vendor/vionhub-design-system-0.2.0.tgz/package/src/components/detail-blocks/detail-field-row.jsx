import { Box, Stack, Typography } from '@mui/material';

// ----------------------------------------------------------------------
// DetailFieldRow — one "label: value" row of a detail sheet. Fixed-width
// secondary-colour label column that stacks above the value on xs; the value
// renders at fontWeight 500 and falls back to a muted em-dash when empty.
// Extracted from the Field helper of request-detail-drawer.
//
// Props:
// - label            — left column text.
// - labelWidth       — label column width in px (default 160).
// - emptyPlaceholder — node shown when children is null/undefined/'' (default '—').
// - sx               — merged into the root Stack.
// - children         — the value (string or any node).

export function DetailFieldRow({ label, labelWidth = 160, emptyPlaceholder = '—', sx, children }) {
  const isEmpty = children == null || children === '';

  return (
    <Stack
      direction={{ xs: 'column', sm: 'row' }}
      spacing={{ xs: 0.25, sm: 1.5 }}
      sx={{ py: 0.75, ...sx }}
    >
      <Typography variant="body2" sx={{ width: labelWidth, color: 'text.secondary', flexShrink: 0 }}>
        {label}
      </Typography>
      <Typography variant="body2" component="div" sx={{ flex: 1, fontWeight: 500 }}>
        {isEmpty ? (
          <Box component="span" sx={{ color: 'text.disabled' }}>
            {emptyPlaceholder}
          </Box>
        ) : (
          children
        )}
      </Typography>
    </Stack>
  );
}
