import { Card, Stack, CardHeader, Typography } from '@mui/material';

import { Iconify } from 'src/components/iconify';

// ----------------------------------------------------------------------
// InfoRow — one icon + caption-label + value line of an "about" panel.
// Extracted from profile-about.
//
// Props:
// - icon          — Iconify name, rendered muted (text.disabled).
// - label         — caption above the value.
// - value         — the value (string or any node).
// - emptyFallback — shown when value is null/undefined/'' (default '—').

export function InfoRow({ icon, label, value, emptyFallback = '—' }) {
  const isEmpty = value == null || value === '';

  return (
    <Stack direction="row" spacing={2} alignItems="flex-start">
      {icon && <Iconify icon={icon} width={20} sx={{ color: 'text.disabled', mt: 0.25 }} />}
      <Stack spacing={0.25} sx={{ flexGrow: 1 }}>
        <Typography variant="caption" color="text.secondary">
          {label}
        </Typography>
        <Typography variant="body2" component="div" sx={{ fontWeight: 500, wordBreak: 'break-word' }}>
          {isEmpty ? emptyFallback : value}
        </Typography>
      </Stack>
    </Stack>
  );
}

// ----------------------------------------------------------------------
// InfoCard — a Card of stacked InfoRows (the "Informations" panel of the
// profile page). Fully declarative: the caller passes the rows as data.
//
// Props:
// - title         — CardHeader title.
// - subheader     — optional CardHeader subheader.
// - items         — [{ icon, label, value, render? }]. When `render` is
//                   provided it is called with the item and its result is
//                   used as the value node (e.g. to render a Chip).
// - emptyFallback — forwarded to each InfoRow (default '—').
// - sx            — merged into the root Card.

export function InfoCard({ title, subheader, items = [], emptyFallback = '—', sx }) {
  return (
    <Card sx={sx}>
      <CardHeader title={title} subheader={subheader} />

      <Stack spacing={2.5} sx={{ p: 3 }}>
        {items.map((item, index) => (
          <InfoRow
            key={item.label ?? index}
            icon={item.icon}
            label={item.label}
            value={item.render ? item.render(item) : item.value}
            emptyFallback={emptyFallback}
          />
        ))}
      </Stack>
    </Card>
  );
}
