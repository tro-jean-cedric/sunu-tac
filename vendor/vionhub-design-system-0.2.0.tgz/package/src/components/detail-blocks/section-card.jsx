import {
  Box,
  Card,
  Paper,
  Stack,
  alpha,
  Divider,
  CardHeader,
  Typography,
  CardContent,
} from '@mui/material';

import { Iconify } from 'src/components/iconify';

// ----------------------------------------------------------------------
// SectionCard — the app's "section" presentation primitive, in two flavours.
// Consolidates the near-identical Section helpers of request-form-dialog,
// product-form and purchase-order-form-dialog ('form' variant) and the
// Section helper of request-detail-drawer ('detail' variant).
//
// Props:
// - icon        — optional Iconify name. 'form' renders it in a 32px
//                 alpha-tinted primary square; 'detail' as the CardHeader
//                 avatar in primary.main.
// - title       — section title (bold subtitle1 in both variants).
// - subtitle    — optional caption under the title.
// - action      — optional ReactNode aligned to the right of the header
//                 (e.g. a small "Modifier" button).
// - variant     — 'form' (default): outlined Paper, header row + children,
//                 used inside sectioned form dialogs.
//                 'detail': outlined Card with CardHeader + Divider +
//                 CardContent, used in detail drawers / read-only sheets.
// - sx          — merged into the root Paper/Card.
// - children    — section body.

/**
 * @typedef {object} SectionCardProps
 * @property {string} [icon] Iconify icon name (e.g. `'solar:calendar-bold-duotone'`).
 * @property {import('react').ReactNode} [title]
 * @property {import('react').ReactNode} [subtitle]
 * @property {import('react').ReactNode} [action]
 * @property {'form' | 'detail'} [variant] `'form'` (default) = outlined Paper; `'detail'` = Card + CardHeader.
 * @property {import('@mui/material').SxProps<import('@mui/material').Theme>} [sx]
 * @property {import('react').ReactNode} [children]
 */

/**
 * @param {SectionCardProps} props
 * @returns {import('react').JSX.Element}
 */
export function SectionCard({ icon, title, subtitle, action, variant = 'form', sx, children }) {
  if (variant === 'detail') {
    return (
      <Card variant="outlined" sx={{ borderRadius: 2, ...sx }}>
        <CardHeader
          avatar={icon ? <Iconify icon={icon} width={20} sx={{ color: 'primary.main' }} /> : null}
          title={title}
          titleTypographyProps={{ variant: 'subtitle1', fontWeight: 700 }}
          subheader={subtitle}
          subheaderTypographyProps={{ variant: 'caption', color: 'text.secondary' }}
          action={action}
          sx={{ pb: 1 }}
        />
        <Divider />
        <CardContent sx={{ pt: 2 }}>{children}</CardContent>
      </Card>
    );
  }

  return (
    <Paper
      variant="outlined"
      sx={{ p: { xs: 2, md: 2.5 }, borderRadius: 2, borderColor: 'divider', ...sx }}
    >
      <Stack direction="row" spacing={1.25} alignItems="center" sx={{ mb: subtitle ? 0.5 : 2 }}>
        {icon && (
          <Box
            sx={{
              width: 32,
              height: 32,
              borderRadius: 1.5,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              flexShrink: 0,
              color: 'primary.main',
              bgcolor: (theme) => alpha(theme.palette.primary.main, 0.12),
            }}
          >
            <Iconify icon={icon} width={18} />
          </Box>
        )}
        <Typography variant="subtitle1" sx={{ fontWeight: 700, flex: 1, minWidth: 0 }}>
          {title}
        </Typography>
        {action}
      </Stack>
      {subtitle && (
        <Typography
          variant="caption"
          color="text.secondary"
          sx={{ display: 'block', ml: icon ? 5.25 : 0, mb: 2 }}
        >
          {subtitle}
        </Typography>
      )}
      {children}
    </Paper>
  );
}

// ----------------------------------------------------------------------
// DialogHeader — the matching DialogTitle content block for sectioned form
// dialogs: 36px alpha-tinted icon square + title + caption, plus an optional
// right-aligned node (e.g. an items-count pill). Render it inside a MUI
// <DialogTitle>.
//
// Props:
// - icon      — Iconify name for the tinted square.
// - title     — dialog title (h6).
// - subtitle  — optional caption under the title.
// - action    — optional ReactNode aligned right.
// - sx        — merged into the root Stack.

/**
 * @typedef {object} DialogHeaderProps
 * @property {string} [icon] Iconify icon name rendered in the tinted square.
 * @property {import('react').ReactNode} [title]
 * @property {import('react').ReactNode} [subtitle]
 * @property {import('react').ReactNode} [action]
 * @property {import('@mui/material').SxProps<import('@mui/material').Theme>} [sx]
 */

/**
 * @param {DialogHeaderProps} props
 * @returns {import('react').JSX.Element}
 */
export function DialogHeader({ icon, title, subtitle, action, sx }) {
  return (
    <Stack direction="row" alignItems="center" spacing={1.5} sx={sx}>
      {icon && (
        <Box
          sx={{
            width: 36,
            height: 36,
            borderRadius: 1.5,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            flexShrink: 0,
            color: 'primary.main',
            bgcolor: (theme) => alpha(theme.palette.primary.main, 0.12),
          }}
        >
          <Iconify icon={icon} width={20} />
        </Box>
      )}
      <Box sx={{ flex: 1, minWidth: 0 }}>
        <Typography variant="h6" sx={{ lineHeight: 1.2 }}>
          {title}
        </Typography>
        {subtitle && (
          <Typography variant="caption" color="text.secondary">
            {subtitle}
          </Typography>
        )}
      </Box>
      {action}
    </Stack>
  );
}
