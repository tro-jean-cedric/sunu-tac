import { forwardRef } from 'react';

import Box from '@mui/material/Box';
import { useTheme } from '@mui/material/styles';

import { StyledLabel } from './styles';
import { labelClasses } from './classes';

// ----------------------------------------------------------------------

/**
 * Complete set of label colors. `default` uses the neutral/grey ramp; every other
 * member maps to a theme palette entry (`theme.palette[color]`). Consumers index
 * lookup maps with this union, so it must stay exhaustive.
 *
 * @typedef {'default' | 'primary' | 'secondary' | 'info' | 'success' | 'warning' | 'error'} LabelColor
 */

/** @typedef {'filled' | 'outlined' | 'soft' | 'inverted'} LabelVariant */

/**
 * Own props of `<Label />`.
 *
 * @typedef {object} LabelOwnProps
 * @property {import('react').ReactNode} [children] A plain string child is rendered sentence-cased.
 * @property {LabelColor} [color] Defaults to `'default'`.
 * @property {LabelVariant} [variant] Defaults to `'soft'`.
 * @property {import('react').ReactNode} [startIcon]
 * @property {import('react').ReactNode} [endIcon]
 * @property {import('@mui/material').SxProps<import('@mui/material').Theme>} [sx]
 */

/** @typedef {LabelOwnProps & Omit<import('@mui/material').BoxProps, 'color' | 'variant' | 'children' | 'ref'>} LabelProps */

/**
 * Small status pill.
 *
 * @type {import('react').ForwardRefExoticComponent<LabelProps & import('react').RefAttributes<HTMLSpanElement>>}
 */
export const Label = forwardRef(
  ({ children, color = 'default', variant = 'soft', startIcon, endIcon, sx, ...other }, ref) => {
    const theme = useTheme();

    const iconStyles = {
      width: 16,
      height: 16,
      '& svg, img': {
        width: 1,
        height: 1,
        objectFit: 'cover',
      },
    };

    return (
      <StyledLabel
        ref={ref}
        component="span"
        className={labelClasses.root}
        ownerState={{ color, variant }}
        sx={{ ...(startIcon && { pl: 0.75 }), ...(endIcon && { pr: 0.75 }), ...sx }}
        theme={theme}
        {...other}
      >
        {startIcon && (
          <Box component="span" className={labelClasses.icon} sx={{ mr: 0.75, ...iconStyles }}>
            {startIcon}
          </Box>
        )}

        {typeof children === 'string' ? sentenceCase(children) : children}

        {endIcon && (
          <Box component="span" className={labelClasses.icon} sx={{ ml: 0.75, ...iconStyles }}>
            {endIcon}
          </Box>
        )}
      </StyledLabel>
    );
  }
);

// ----------------------------------------------------------------------

function sentenceCase(string) {
  return string.charAt(0).toUpperCase() + string.slice(1);
}
