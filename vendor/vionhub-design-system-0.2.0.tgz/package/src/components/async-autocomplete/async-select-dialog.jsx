import { useState, useEffect } from 'react';

import LoadingButton from '@mui/lab/LoadingButton';
import { Stack, Dialog, Button, DialogTitle, DialogContent, DialogActions } from '@mui/material';

import { staticDialog } from 'src/utils/dialog';

import { DialogCloseButton } from 'src/components/custom-dialog';

import { AsyncSearchAutocomplete } from './async-search-autocomplete';

// ----------------------------------------------------------------------
// Small "link entity B to entity A" dialog (set supervisor, activate user…):
// one server-search Autocomplete, Cancel / Confirm actions. Data-agnostic —
// the consumer provides `fetchOptions(query) => Promise<array>` and an async
// `onConfirm(option)`: resolving closes the dialog, throwing keeps it open
// (surface the failure via toast on the caller side). The confirm button is
// disabled until a selection exists and drives its own submitting state.
//
// `initialSelection` pre-fills the picker when editing an existing link
// (e.g. the current supervisor). `extraFields` renders extra inputs below
// the autocomplete (e.g. a roles multi-select). Backdrop clicks don't close
// the dialog — only the close button / Cancel do.

export function AsyncSelectDialog({
  open,
  onClose,
  title,
  label,
  placeholder,
  fetchOptions,
  getOptionLabel,
  isOptionEqualToValue,
  renderOption,
  initialSelection = null,
  onConfirm,
  confirmLabel = 'Confirmer',
  cancelLabel = 'Annuler',
  loadingText,
  noOptionsText,
  extraFields = null,
}) {
  const [selected, setSelected] = useState(initialSelection);
  const [submitting, setSubmitting] = useState(false);
  const [openCount, setOpenCount] = useState(0);

  // Re-seed the selection every time the dialog opens. Bumping `openCount`
  // remounts the inner autocomplete (via `key`) so its `initialOptions` are
  // re-read and the previous open's fetched options are discarded.
  useEffect(() => {
    if (open) {
      setSelected(initialSelection ?? null);
      setSubmitting(false);
      setOpenCount((c) => c + 1);
    }
  }, [open, initialSelection]);

  const handleSubmit = async () => {
    if (!selected) return;
    setSubmitting(true);
    try {
      await onConfirm?.(selected);
      onClose?.();
    } catch {
      // Keep the dialog open — the caller reports the failure.
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Dialog fullWidth maxWidth="sm" open={open} onClose={staticDialog(onClose)}>
      <DialogCloseButton onClick={onClose} />
      <DialogTitle>{title}</DialogTitle>
      <DialogContent>
        <Stack spacing={3} sx={{ mt: 1 }}>
          <AsyncSearchAutocomplete
            key={openCount}
            size="medium"
            label={label}
            placeholder={placeholder}
            fetchOptions={fetchOptions}
            value={selected}
            onChange={setSelected}
            getOptionLabel={getOptionLabel}
            isOptionEqualToValue={isOptionEqualToValue}
            renderOption={renderOption}
            initialOptions={initialSelection ? [initialSelection] : []}
            loadingText={loadingText}
            noOptionsText={noOptionsText}
          />
          {extraFields}
        </Stack>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose} color="inherit">
          {cancelLabel}
        </Button>
        <LoadingButton variant="contained" loading={submitting} disabled={!selected} onClick={handleSubmit}>
          {confirmLabel}
        </LoadingButton>
      </DialogActions>
    </Dialog>
  );
}
