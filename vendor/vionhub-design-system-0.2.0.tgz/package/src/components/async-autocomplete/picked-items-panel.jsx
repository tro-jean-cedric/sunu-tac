import { Box, Chip, Stack, Paper, Avatar, Typography, IconButton } from '@mui/material';

import { Label } from 'src/components/label';
import { Iconify } from 'src/components/iconify';

import { AsyncSearchAutocomplete } from './async-search-autocomplete';

// ----------------------------------------------------------------------
// Search-and-pick side panel (the "Demandes liées" panel of the purchase
// order form): an outlined Paper with an icon + title header, a caption
// hint, a tag-less multiple server-search Autocomplete on top, then one
// card per selected item — Avatar, primary text, soft Label badge,
// secondary caption, trailing node (e.g. an amount Chip) and a remove
// button. Data-agnostic: the consumer owns `items` and mutates through
// `onAdd(picked)` / `onRemove(item)`.
//
// Per-item getters shape the card:
//   getPrimary(item)   -> main line (bold, defaults to getOptionLabel)
//   getBadge(item)     -> soft info Label content (e.g. the request code)
//   getSecondary(item) -> caption next to the badge (e.g. product name)
//   getTrailing(item)  -> right-side node; strings become an outlined Chip
//   getAvatar(item)    -> avatar image URL or node; falls back to the
//                         first letter of getPrimary(item)
// or take over entirely with `renderItem(item, { onRemove })`.

export function PickedItemsPanel({
  title,
  icon = 'solar:clipboard-list-bold',
  hint,
  items = [],
  onAdd,
  onRemove,
  fetchOptions,
  getOptionLabel = (option) => option?.label ?? '',
  isOptionEqualToValue = (option, val) => option?.id === val?.id,
  getAvatar,
  getPrimary,
  getBadge,
  getSecondary,
  getTrailing,
  renderItem,
  emptyMessage = 'Aucun élément sélectionné.',
  searchPlaceholder = 'Rechercher…',
  renderOption,
  debounceMs,
  minChars,
  disabled,
  sx,
}) {
  const primaryOf = (item) => (getPrimary ? getPrimary(item) : getOptionLabel(item));

  const keyOf = (item, index) => item?.id ?? item?.code ?? `${primaryOf(item)}-${index}`;

  // The multiple Autocomplete reports the whole new array — diff it against
  // `items` and surface additions/removals as unit events.
  const handleChange = (newValue) => {
    const next = Array.isArray(newValue) ? newValue : [];
    next
      .filter((option) => !items.some((item) => isOptionEqualToValue(item, option)))
      .forEach((added) => onAdd?.(added));
    items
      .filter((item) => !next.some((option) => isOptionEqualToValue(item, option)))
      .forEach((removed) => onRemove?.(removed));
  };

  const renderAvatar = (item) => {
    const avatar = getAvatar?.(item);
    if (avatar != null && typeof avatar !== 'string') {
      return avatar;
    }
    return (
      <Avatar src={typeof avatar === 'string' ? avatar : undefined} sx={{ width: 32, height: 32, fontSize: 14 }}>
        {String(primaryOf(item) ?? '')[0]?.toUpperCase() ?? '?'}
      </Avatar>
    );
  };

  const renderTrailing = (item) => {
    const trailing = getTrailing?.(item);
    if (trailing == null) return null;
    if (typeof trailing === 'string' || typeof trailing === 'number') {
      return <Chip size="small" variant="outlined" label={trailing} />;
    }
    return trailing;
  };

  return (
    <Paper variant="outlined" sx={{ p: 2.5, borderRadius: 2, alignSelf: 'start', ...sx }}>
      <Stack direction="row" spacing={1.25} alignItems="center" sx={{ mb: 0.5 }}>
        {icon && <Iconify icon={icon} width={18} />}
        <Typography variant="subtitle2" sx={{ fontWeight: 700 }}>
          {title}
        </Typography>
      </Stack>
      {hint && (
        <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 2 }}>
          {hint}
        </Typography>
      )}

      <AsyncSearchAutocomplete
        multiple
        hideTags
        size="small"
        disabled={disabled}
        placeholder={searchPlaceholder}
        fetchOptions={fetchOptions}
        value={items}
        onChange={handleChange}
        getOptionLabel={getOptionLabel}
        isOptionEqualToValue={isOptionEqualToValue}
        renderOption={renderOption}
        debounceMs={debounceMs}
        minChars={minChars}
        sx={{ mb: 2, ...(hint ? {} : { mt: 1.5 }) }}
      />

      <Stack spacing={1}>
        {items.length === 0 && (
          <Typography
            variant="caption"
            color="text.secondary"
            sx={{ fontStyle: 'italic', textAlign: 'center', py: 2 }}
          >
            {emptyMessage}
          </Typography>
        )}
        {items.map((item, index) => {
          if (renderItem) {
            return <Box key={keyOf(item, index)}>{renderItem(item, { onRemove })}</Box>;
          }
          const badge = getBadge?.(item);
          const secondary = getSecondary?.(item);
          return (
            <Stack
              key={keyOf(item, index)}
              direction="row"
              alignItems="center"
              spacing={1.5}
              sx={{
                px: 1.5,
                py: 1,
                borderRadius: 1.5,
                border: 1,
                borderColor: 'divider',
                bgcolor: 'background.neutral',
              }}
            >
              {renderAvatar(item)}
              <Box sx={{ flex: 1, minWidth: 0 }}>
                <Typography variant="body2" sx={{ fontWeight: 600 }} noWrap>
                  {primaryOf(item) || '—'}
                </Typography>
                {(badge || secondary) && (
                  <Stack direction="row" spacing={0.75} alignItems="center">
                    {badge && (
                      <Label variant="soft" color="info" sx={{ textTransform: 'none' }}>
                        {badge}
                      </Label>
                    )}
                    {secondary && (
                      <Typography variant="caption" color="text.secondary" noWrap>
                        {secondary}
                      </Typography>
                    )}
                  </Stack>
                )}
              </Box>
              {renderTrailing(item)}
              <IconButton size="small" color="error" onClick={() => onRemove?.(item)}>
                <Iconify icon="solar:trash-bin-trash-bold" width={18} />
              </IconButton>
            </Stack>
          );
        })}
      </Stack>
    </Paper>
  );
}
