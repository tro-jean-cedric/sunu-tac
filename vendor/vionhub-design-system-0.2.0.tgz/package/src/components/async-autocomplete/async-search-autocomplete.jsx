import { useRef, useState, useEffect } from 'react';

import { TextField, Autocomplete, CircularProgress } from '@mui/material';

import { useDebounce } from 'src/hooks/use-debounce';

// ----------------------------------------------------------------------
// Debounced server-search Autocomplete, data-agnostic. The consumer provides
// `fetchOptions(query) => Promise<array>` — a plain array of options, any
// response unwrapping (envelopes, pagination) happens on the caller side,
// typically in a closure that also carries the caller's filters:
//
//   <AsyncSearchAutocomplete
//     label="Rechercher un utilisateur"
//     fetchOptions={(q) => searchUsers({ name: q, companyId })}
//     value={selected}
//     onChange={setSelected}
//   />
//
// Behavior: the raw input goes through `useDebounce(debounceMs)`; each fetch
// carries an incrementing request id so stale resolutions are ignored (no
// flicker when a slow response lands after a fast one). While a fetch is in
// flight a CircularProgress shows in the end adornment. Opening the dropdown
// triggers an initial fetch when `minChars === 0` (browse-then-type UX).
//
// `error` / `helperText` pass straight to the TextField so the component
// drops into an RHF <Controller> or standalone form untouched. `hideTags`
// renders no chips for `multiple` selections — the picker-panel pattern where
// selected items are displayed elsewhere (see <PickedItemsPanel />).

export function AsyncSearchAutocomplete({
  fetchOptions,
  value,
  onChange,
  getOptionLabel = (option) => option?.label ?? '',
  isOptionEqualToValue = (option, val) => option?.id === val?.id,
  multiple = false,
  debounceMs = 300,
  minChars = 0,
  initialOptions = [],
  label,
  placeholder,
  hideTags = false,
  loadingText = 'Recherche en cours…',
  noOptionsText = 'Aucun résultat',
  error,
  helperText,
  disabled,
  size = 'small',
  renderOption,
  ...autocompleteProps
}) {
  const [open, setOpen] = useState(false);
  const [inputValue, setInputValue] = useState('');
  const [options, setOptions] = useState(initialOptions);
  const [loading, setLoading] = useState(false);

  const query = useDebounce(inputValue, debounceMs);

  // Keep the latest fetcher without retriggering the effect when the caller
  // passes an inline closure (new identity every render).
  const fetchRef = useRef(fetchOptions);
  fetchRef.current = fetchOptions;

  // Incrementing request id — only the latest request may commit its result.
  const requestIdRef = useRef(0);

  useEffect(() => {
    if (!open) return;

    if ((query ?? '').length < minChars) {
      setLoading(false);
      return;
    }

    const requestId = requestIdRef.current + 1;
    requestIdRef.current = requestId;
    setLoading(true);

    Promise.resolve(fetchRef.current(query))
      .then((list) => {
        if (requestId !== requestIdRef.current) return;
        setOptions(Array.isArray(list) ? list : []);
        setLoading(false);
      })
      .catch(() => {
        if (requestId !== requestIdRef.current) return;
        setOptions([]);
        setLoading(false);
      });
  }, [open, query, minChars]);

  return (
    <Autocomplete
      size={size}
      multiple={multiple}
      disabled={disabled}
      open={open}
      onOpen={() => setOpen(true)}
      onClose={() => setOpen(false)}
      options={options}
      value={value}
      onChange={(_, newValue) => onChange?.(newValue)}
      inputValue={inputValue}
      onInputChange={(_, newInput) => setInputValue(newInput)}
      getOptionLabel={getOptionLabel}
      isOptionEqualToValue={isOptionEqualToValue}
      loading={loading}
      loadingText={loadingText}
      noOptionsText={noOptionsText}
      renderOption={renderOption}
      {...(hideTags ? { renderTags: () => null, filterSelectedOptions: true } : {})}
      renderInput={(params) => (
        <TextField
          {...params}
          label={label}
          placeholder={placeholder}
          error={!!error}
          helperText={helperText}
          InputProps={{
            ...params.InputProps,
            endAdornment: (
              <>
                {loading ? <CircularProgress size={16} /> : null}
                {params.InputProps.endAdornment}
              </>
            ),
          }}
        />
      )}
      {...autocompleteProps}
    />
  );
}
