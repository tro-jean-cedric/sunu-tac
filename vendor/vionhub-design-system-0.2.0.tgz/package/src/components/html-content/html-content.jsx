import { forwardRef } from 'react';

import { Box, Typography } from '@mui/material';

// ----------------------------------------------------------------------
// HtmlContent — display layer for editor-authored rich HTML (descriptions,
// motifs, observations…). Wraps dangerouslySetInnerHTML in the shared
// typographic block the app repeats around every rich-text render: paragraph
// margins, list padding, primary-colored links, rounded max-width images,
// secondary text color and a 1.7 line-height. Complements the DS Markdown
// component for the raw-HTML cases (editor output, API-provided HTML).
//
// SECURITY — the component does NOT bundle a sanitizer. By default the HTML
// is rendered as-is and a one-time dev warning asks you to inject one via the
// `sanitize` prop (e.g. DOMPurify). Never feed it untrusted HTML without one.
//
// Props:
// - html      — the raw HTML string to render. When empty / whitespace-only,
//               `emptyText` is rendered instead (disabled color).
// - sanitize  — (html) => safeHtml. Injected by the app, e.g.
//               (h) => DOMPurify.sanitize(h). Defaults to a passthrough that
//               dev-warns once.
// - emptyText — fallback text when there is nothing to show. Default '—'.
// - sx        — merged over the base typographic styles.
//
// Also exports `htmlContentRichSx`, the table/img-capable style block used by
// CollapsibleHtmlContent's dialog — reuse it anywhere full-width rich HTML is hosted.

// Base typographic block shared by every rich-HTML render in the app.
export const htmlContentBaseSx = {
  color: 'text.secondary',
  lineHeight: 1.7,
  wordBreak: 'break-word',
  '& p': { my: 1 },
  '& ul, & ol': { pl: 3, my: 1 },
  '& a': { color: 'primary.main' },
  '& img': { maxWidth: '100%', borderRadius: 1 },
};

// Full-content variant (dialogs, printable views): primary text color plus
// Excel/Sheets-paste-friendly table styles.
export const htmlContentRichSx = {
  ...htmlContentBaseSx,
  color: 'text.primary',
  '& table': {
    borderCollapse: 'collapse',
    width: '100%',
    my: 1.5,
    '& th, & td': { border: '1px solid', borderColor: 'divider', p: 0.75 },
    '& th': { bgcolor: 'action.hover', fontWeight: 600, textAlign: 'left' },
  },
};

// Passthrough sanitizer — warns once (dev only) so integrators remember to
// plug a real one in. Kept module-level so the warning fires a single time
// per app session, not per render.
let warnedMissingSanitizer = false;

const defaultSanitize = (html) => {
  if (!warnedMissingSanitizer && !import.meta.env?.PROD) {
    warnedMissingSanitizer = true;
    // eslint-disable-next-line no-console
    console.warn(
      '[HtmlContent] no `sanitize` prop provided — HTML is rendered as-is. ' +
        'Provide a sanitizer, e.g. DOMPurify: <HtmlContent sanitize={(h) => DOMPurify.sanitize(h)} />'
    );
  }
  return html;
};

export const HtmlContent = forwardRef(
  ({ html, sanitize = defaultSanitize, emptyText = '—', sx, ...other }, ref) => {
    const isEmpty = html == null || !String(html).trim();

    if (isEmpty) {
      return (
        <Typography ref={ref} variant="body2" color="text.disabled" sx={sx} {...other}>
          {emptyText}
        </Typography>
      );
    }

    return (
      <Box
        ref={ref}
        sx={{ ...htmlContentBaseSx, ...sx }}
        dangerouslySetInnerHTML={{ __html: sanitize(String(html)) }}
        {...other}
      />
    );
  }
);
