import { useRef, useState, useCallback, useLayoutEffect } from 'react';

import {
  Box,
  Stack,
  Button,
  Dialog,
  Typography,
  DialogTitle,
  DialogContent,
  DialogActions,
} from '@mui/material';

import { Iconify } from 'src/components/iconify';
import { DialogCloseButton } from 'src/components/custom-dialog';

import { HtmlContent, htmlContentRichSx } from './html-content';

// ----------------------------------------------------------------------
// CollapsibleHtmlContent — HtmlContent capped at `collapsedHeight` with a fade-out
// gradient overlay. The "Voir plus" toggle only appears when the rendered
// content actually overflows the cap (scrollHeight probe in useLayoutEffect,
// re-checked by a ResizeObserver — images/fonts loading late change the
// height). Consolidates the app's request-drawer description block and the
// timeline's ReasonBox into one component.
//
// Props:
// - html            — raw HTML. Renders nothing when empty / whitespace-only.
// - label           — optional caption above the block (e.g. 'Description').
// - collapsedHeight — cap in px before the fade + toggle kick in. Default 140.
// - expandMode      — 'inline' expands in place (default) | 'dialog' opens a
//                     Dialog hosting the full HTML with table/img-capable
//                     styles (the timeline "reason" pattern).
// - dialogTitle     — Dialog title ('dialog' mode). Default 'Détail'. In the
//                     app this was RequestStatusTranslation[action].
// - tone            — 'default' | 'error' | 'info'. Non-default tones reproduce
//                     the timeline ReasonBox look: a tinted, compact box
//                     (fontSize 13, lineHeight 1.4, tight paragraph/list
//                     margins, 32px fade). 'error' is the dark rejection box
//                     (error.dark bg, grey.50 text — note the app's original
//                     fade ended on error.lighter over that dark bg, a visible
//                     band; here it correctly ends on error.dark). 'info' is
//                     the light note box (info.lighter / info.darker).
// - sanitize        — (html) => safeHtml, forwarded to HtmlContent. Inject
//                     your app sanitizer (e.g. DOMPurify).
// - moreLabel       — toggle text when collapsed. Default 'Voir plus'.
// - lessLabel       — toggle text when expanded ('inline'). Default 'Voir moins'.
// - sx              — merged over the collapsed HtmlContent styles.

// Compact typography shared by tone boxes — mirrors the ReasonBox block
// (fontSize 13, lineHeight 1.4, tight margins). Deliberately overrides
// htmlContentBaseSx's roomier lineHeight 1.7 / my: 1 paragraphs so tone boxes
// render at the app's height, not the description block's.
const TONE_COMPACT_SX = {
  px: 1.25,
  py: 0.75,
  borderRadius: 1,
  fontSize: 13,
  lineHeight: 1.4,
  '& p': { my: 0.5 },
  '& p:first-of-type': { mt: 0 },
  '& p:last-of-type': { mb: 0 },
  '& ul, & ol': { pl: 2.5, my: 0.5 },
};

// Container palette per tone — borderless like the source ReasonBox. 'error'
// keeps the app's dark rejection box; 'info' its light note box.
const TONE_STYLES = {
  error: {
    ...TONE_COMPACT_SX,
    bgcolor: 'error.dark',
    color: 'grey.50',
  },
  info: {
    ...TONE_COMPACT_SX,
    bgcolor: 'info.lighter',
    color: 'info.darker',
  },
};

// Dialog title icon per tone — mirrors the timeline's rejection vs note look.
const TONE_DIALOG_ICONS = {
  default: { icon: 'solar:document-text-bold', color: 'primary.main' },
  error: { icon: 'solar:dislike-bold', color: 'error.main' },
  info: { icon: 'solar:document-text-bold', color: 'info.main' },
};

// The fade gradient must end on the container's own background so the cut
// looks like paper, not a hard band. Note: the app's original ReasonBox faded
// to error.lighter over its error.dark background — fixed here to error.dark.
const TONE_FADE_KEYS = { error: 'dark', info: 'lighter' };

const toneFadeColor = (theme, tone) =>
  tone === 'default'
    ? theme.palette.background.paper
    : theme.palette[tone][TONE_FADE_KEYS[tone]];

export function CollapsibleHtmlContent({
  html,
  label,
  collapsedHeight = 140,
  expandMode = 'inline',
  dialogTitle = 'Détail',
  tone = 'default',
  sanitize,
  moreLabel = 'Voir plus',
  lessLabel = 'Voir moins',
  sx,
}) {
  const ref = useRef(null);
  const [expanded, setExpanded] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [overflows, setOverflows] = useState(false);

  const probe = useCallback(() => {
    const el = ref.current;
    if (!el) return;
    setOverflows(el.scrollHeight > collapsedHeight + 4);
  }, [collapsedHeight]);

  useLayoutEffect(() => {
    probe();
    const el = ref.current;
    if (!el || typeof ResizeObserver === 'undefined') return undefined;
    // Re-check when the rendered content changes size (late images, fonts,
    // container resizes) — scrollHeight isn't reactive by itself.
    const observer = new ResizeObserver(probe);
    observer.observe(el);
    return () => observer.disconnect();
  }, [html, probe]);

  if (html == null || !String(html).trim()) return null;

  const collapsed = !expanded;
  const toneSx = TONE_STYLES[tone] ?? null;
  const dialogIcon = TONE_DIALOG_ICONS[tone] ?? TONE_DIALOG_ICONS.default;

  const handleToggle = (event) => {
    // The block often lives inside drawers/timeline rows with their own click
    // handlers — don't let the toggle bubble into them.
    event.stopPropagation();
    if (expandMode === 'dialog') setDialogOpen(true);
    else setExpanded((v) => !v);
  };

  return (
    <Box>
      {label && (
        <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 0.5 }}>
          {label}
        </Typography>
      )}

      <Box sx={{ position: 'relative' }}>
        <HtmlContent
          ref={ref}
          html={html}
          sanitize={sanitize}
          sx={{
            ...toneSx,
            maxHeight: collapsed ? collapsedHeight : 'none',
            overflow: 'hidden',
            transition: 'max-height 0.2s ease',
            ...sx,
          }}
        />
        {collapsed && overflows && (
          <Box
            sx={{
              position: 'absolute',
              left: 0,
              right: 0,
              bottom: 0,
              // Tone boxes use the source ReasonBox's shorter 32px fade; the
              // default (description) block keeps the taller 48px one.
              height: tone === 'default' ? 48 : 32,
              pointerEvents: 'none',
              borderRadius: 1,
              background: (theme) =>
                `linear-gradient(180deg, transparent 0%, ${toneFadeColor(theme, tone)} 100%)`,
            }}
          />
        )}
      </Box>

      {overflows && (
        <Button
          size="small"
          onClick={handleToggle}
          endIcon={
            <Iconify
              icon={expanded && expandMode === 'inline' ? 'eva:chevron-up-fill' : 'eva:chevron-down-fill'}
              width={16}
            />
          }
          sx={{ mt: 0.5, alignSelf: 'flex-start', textTransform: 'none' }}
        >
          {expanded && expandMode === 'inline' ? lessLabel : moreLabel}
        </Button>
      )}

      {expandMode === 'dialog' && (
        <Dialog
          open={dialogOpen}
          onClose={() => setDialogOpen(false)}
          maxWidth="sm"
          fullWidth
          PaperProps={{ sx: { borderRadius: 2 } }}
        >
          <DialogCloseButton onClick={() => setDialogOpen(false)} />
          <DialogTitle>
            <Stack direction="row" alignItems="center" spacing={1.5}>
              <Iconify icon={dialogIcon.icon} width={22} sx={{ color: dialogIcon.color }} />
              <Typography variant="h6" sx={{ lineHeight: 1.2 }}>
                {dialogTitle}
              </Typography>
            </Stack>
          </DialogTitle>
          <DialogContent dividers>
            <HtmlContent html={html} sanitize={sanitize} sx={htmlContentRichSx} />
          </DialogContent>
          <DialogActions sx={{ px: 3, py: 2 }}>
            <Button onClick={() => setDialogOpen(false)} variant="contained">
              Fermer
            </Button>
          </DialogActions>
        </Dialog>
      )}
    </Box>
  );
}
