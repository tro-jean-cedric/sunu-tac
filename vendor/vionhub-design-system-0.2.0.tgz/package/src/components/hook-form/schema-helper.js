import dayjs from 'dayjs';
import { z as zod } from 'zod';

// ----------------------------------------------------------------------

/**
 * Issue code emitted for an unparseable date by `schemaHelper.date`.
 *
 * The package supports `zod@^3.23 || ^4`, and the two majors do not offer the
 * same set of issue codes:
 *
 *   - On zod 3 (verified against the installed 3.25.76) `invalid_date` is a
 *     real code: `zod.ZodIssueCode.invalid_date === 'invalid_date'`, `addIssue`
 *     emits it, and the custom `message` is preserved. This is what the library
 *     has always emitted, so consumers branching on
 *     `issue.code === 'invalid_date'` are relying on it.
 *   - zod 4 removed the code (and `ZodIssueCode` itself may be absent), so the
 *     same expression yields `undefined` — an issue with no usable code.
 *
 * Resolving it once, at module load, gives zod-3 hosts exactly the behaviour
 * they already depend on and zod-4 hosts a code that actually exists. Picking
 * one literal for both majors would have meant breaking one of them for the
 * sake of uniformity the host cannot observe anyway (a host only ever has one
 * zod installed).
 *
 * @type {'invalid_date' | 'custom'}
 */
const INVALID_DATE_ISSUE_CODE = zod.ZodIssueCode?.invalid_date ?? 'custom';

export const schemaHelper = {
  /**
   * Phone number
   * defaultValue === null
   */
  phoneNumber: (props) =>
    zod
      .string()
      .min(1, {
        message: props?.message?.required_error ?? 'Phone number is required!',
      })
      .refine((data) => props?.isValidPhoneNumber?.(data), {
        message: props?.message?.invalid_type_error ?? 'Invalid phone number!',
      }),
  /**
   * date
   * defaultValue === null
   */
  date: (props) =>
    zod.coerce
      .date()
      .nullable()
      .transform((dateString, ctx) => {
        const date = dayjs(dateString).format();

        const stringToDate = zod.string().pipe(zod.coerce.date());

        if (!dateString) {
          ctx.addIssue({
            code: zod.ZodIssueCode.custom,
            message: props?.message?.required_error ?? 'Date is required!',
          });
          return null;
        }

        if (!stringToDate.safeParse(date).success) {
          ctx.addIssue({
            code: INVALID_DATE_ISSUE_CODE,
            message: props?.message?.invalid_type_error ?? 'Invalid Date!!',
          });
        }

        return date;
      })
      .pipe(zod.union([zod.number(), zod.string(), zod.date(), zod.null()])),
  /**
   * editor
   * defaultValue === '' | <p></p>
   */
  editor: (props) =>
    zod.string().min(8, {
      message: props?.message?.required_error ?? 'Editor is required!',
    }),
  /**
   * object
   * defaultValue === null
   */
  objectOrNull: (props) =>
    zod
      .custom()
      .refine((data) => data !== null, {
        message: props?.message?.required_error ?? 'Field is required!',
      })
      .refine((data) => data !== '', {
        message: props?.message?.required_error ?? 'Field is required!',
      }),
  /**
   * boolean
   * defaultValue === false
   */
  boolean: (props) =>
    zod.coerce.boolean().refine((bool) => bool === true, {
      message: props?.message?.required_error ?? 'Switch is required!',
    }),
  /**
   * file
   * defaultValue === '' || null
   */
  file: (props) =>
    zod.custom().transform((data, ctx) => {
      const hasFile = data instanceof File || (typeof data === 'string' && !!data.length);

      if (!hasFile) {
        ctx.addIssue({
          code: zod.ZodIssueCode.custom,
          message: props?.message?.required_error ?? 'File is required!',
        });
        return null;
      }

      return data;
    }),
  /**
   * files
   * defaultValue === []
   */
  files: (props) =>
    zod.array(zod.custom()).transform((data, ctx) => {
      const minFiles = props?.minFiles ?? 2;

      if (!data.length) {
        ctx.addIssue({
          code: zod.ZodIssueCode.custom,
          message: props?.message?.required_error ?? 'Files is required!',
        });
      } else if (data.length < minFiles) {
        ctx.addIssue({
          code: zod.ZodIssueCode.custom,
          message: `Must have at least ${minFiles} items!`,
        });
      }

      return data;
    }),
};
