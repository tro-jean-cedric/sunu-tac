import { Controller, useFormContext } from 'react-hook-form';

import { NumberFormatInput } from 'src/components/number-format-input';

// ----------------------------------------------------------------------
// RHF number field: shows the value with a space thousand separator while it is
// typed (10000 -> "10 000"), but stores a plain number in form state so the
// submitted payload contains digits only. Empty stays '' so zod.coerce.number
// / required rules behave as before.
// ----------------------------------------------------------------------

export function RHFNumberField({ name, helperText, inputProps, ...other }) {
  const { control } = useFormContext();

  return (
    <Controller
      name={name}
      control={control}
      render={({ field, fieldState: { error } }) => (
        <NumberFormatInput
          {...other}
          name={field.name}
          value={field.value ?? ''}
          onChange={(raw) => {
            // Store a real number once the value parses; keep partial input
            // (a lone '.', '-', '10.') as-is so it isn't turned into NaN and
            // wiped mid-typing. zod.coerce.number() still yields digits on submit.
            if (raw === '') {
              field.onChange('');
              return;
            }
            const n = Number(raw);
            field.onChange(Number.isNaN(n) ? raw : n);
          }}
          onBlur={field.onBlur}
          inputRef={field.ref}
          fullWidth
          error={!!error}
          helperText={error?.message ?? helperText}
          inputProps={{ autoComplete: 'off', ...inputProps }}
        />
      )}
    />
  );
}
