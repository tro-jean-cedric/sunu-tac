// Default values for the library's list surfaces, named in one place.
// =============================================================================
//
// WHY THIS FILE EXISTS
// --------------------
// Three components answer the same two questions — "how long do we wait before
// firing a search?" and "which page sizes do we offer?" — and used to answer
// them with hard-coded literals scattered across three files:
//
//   * AsyncDataGrid          debounce 700 ms, page sizes [10, 25, 50, 100]
//   * DebouncedSearchField   debounce 500 ms
//   * TablePaginationCustom  page sizes [5, 10, 25]
//
// Two problems were tangled together there, and only one of them is worth
// paying a behaviour change to fix:
//
//   1. AsyncDataGrid's two values were UNOVERRIDABLE. A consumer who wanted a
//      different debounce or different page sizes had no prop to pass and had
//      to fork the component. That is a real API defect, and it is fixed by
//      turning the literals into props — a purely additive change that cannot
//      break anyone.
//
//   2. The values themselves DISAGREE across components. That is a wart, but
//      "fixing" it by moving a default breaks every consumer relying on the old
//      one. The two cases are not symmetric:
//
//      * The DEBOUNCE divergence is safe to converge. The only observable
//        effect is how long the UI waits before emitting a search; no value is
//        ever rejected, nothing goes out of range, and any consumer who cares
//        can now pass the prop. So both search surfaces share
//        SEARCH_DEBOUNCE_MS below, and AsyncDataGrid moves 700 -> 500 ms.
//
//      * The PAGE-SIZE divergence is NOT safe to converge, in either
//        direction, because the page-size list is validated against the
//        current page size. Move TablePaginationCustom to [10, 25, 50, 100]
//        and a consumer rendering `rowsPerPage={5}` hands MUI's
//        TablePagination a Select value that is not among its options — MUI
//        reports an out-of-range value and the control renders blank. Move
//        AsyncDataGrid to [5, 10, 25] and the mirror-image break hits every
//        consumer holding `pageSize={50}` (MUI X warns that `pageSize` is not
//        present in `pageSizeOptions`). Server-paginated grids routinely carry
//        that page size in URL state, so this is not hypothetical.
//
//        The two components therefore keep the defaults they shipped with,
//        named separately below. Converging them is a deliberate breaking
//        change that has to be proposed and migrated on its own, not smuggled
//        in as a tidy-up.
//
// The rule this file encodes: every one of these numbers is a DEFAULT for an
// overridable prop, never a hard-coded constant. A consumer who disagrees with
// any of them passes the prop.
//
// These constants are intentionally NOT exported from any public barrel: they
// are the library's internal single source of truth, not API. Their VALUES are
// part of the contract (each is documented on the prop it defaults) — their
// identity as importable symbols is not.
// =============================================================================

/**
 * Debounce, in milliseconds, between the last keystroke in a search box and the
 * search actually being emitted to the parent (and therefore, usually, to the
 * server).
 *
 * 500 ms is `DebouncedSearchField`'s long-standing default and is now also what
 * `AsyncDataGrid` uses, so the two search surfaces feel the same. It is a
 * compromise: long enough that a normal typing burst (~150-200 ms between
 * keystrokes for a touch typist) collapses into one request, short enough that
 * the pause at the end of a word does not read as dead time. Apps hitting a
 * fast endpoint usually want less — pass `delay` / `searchDebounce`.
 *
 * @type {number}
 */
export const SEARCH_DEBOUNCE_MS = 500;

/**
 * Page-size choices offered by `TablePaginationCustom`, the client-paginated
 * `<Table>` surface. Small by design: these tables render every row of the page
 * into the DOM, and the pages they sit on (detail-page sub-tables, pickers) are
 * usually short.
 *
 * Deliberately NOT the same list as {@link DATA_GRID_PAGE_SIZE_OPTIONS} — see
 * the header of this file for why the two are not merged.
 *
 * @type {readonly number[]}
 */
export const TABLE_PAGE_SIZE_OPTIONS = [5, 10, 25];

/**
 * Page-size choices offered by `AsyncDataGrid`, the server-paginated list
 * surface. This is MUI's own DataGrid default and what `AsyncDataGrid` has
 * always shipped: server-backed lists are long, a page costs one request either
 * way, and 5 rows per page is below the point where paging is worth the round
 * trip.
 *
 * @type {readonly number[]}
 */
export const DATA_GRID_PAGE_SIZE_OPTIONS = [10, 25, 50, 100];
