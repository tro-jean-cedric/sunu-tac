import { Box, Stack, Button, Typography, CircularProgress } from '@mui/material';

import { Iconify } from 'src/components/iconify';

import { AttachmentListItem } from './attachment-list-item';

// ----------------------------------------------------------------------
// The attachment block shared by the request dialogs (create/edit form and
// "Charger les devis / pro-forma"), data-agnostic. Dashed full-width upload
// label-button with a hidden multi-file input and a spinner row while `busy`;
// then the already-stored attachments (`existing`) and the freshly picked
// ones (`pending`, from usePendingFiles) rendered with AttachmentListItem.
// Pending rows are renameable & removable; existing rows link to their url
// and are deletable per-item. No upload/delete service and no URL resolution
// here — the caller uploads getFiles() at submit time, deletes through
// `onDeleteExisting` and passes urls already resolved.
//
// The "recommended quote" radio spans BOTH lists through composite keys
// 'existing:<i>' / 'new:<i>': pass `selectable`, the current `selectedKey`
// and receive picks via `onSelectRecommended(key)`. When an entry is removed
// the caller owns clearing/shifting its selection.
//
// Props:
//   existing            [{ id, name, hint?, url?, meta?, deletable?, recommended? }]
//                       — hint is a node (date, uploader…); `recommended`
//                       drives the highlight when not `selectable`; `meta` is
//                       an opaque passthrough for a custom `slots.item`
//   pending             [{ file: File, name }] — usePendingFiles().files
//   onAddFiles          (fileList) => void — usePendingFiles().add
//   onRemovePending     (index) => void
//   onRenamePending     (index, name) => void
//   onDeleteExisting    async (item) => void — called with the existing entry
//   selectable          bool (false) — enable the recommended radio
//   selectedKey         'existing:<i>' | 'new:<i>' | null
//   onSelectRecommended (key) => void
//   uploadLabel         string ('Glisser-déposer ou cliquez pour ajouter des fichiers')
//   busyLabel           string ('Traitement des fichiers…')
//   accept              string ('*') — file input accept attribute
//   multiple            bool (true)
//   busy                bool (false) — disables the button, shows the spinner row
//   readOnly            bool (false) — hides upload, rename and delete affordances
//   slots               { item } — component replacing AttachmentListItem;
//                       receives the same props plus `itemKey` and `meta`
//   sx                  root sx override

export function AttachmentManager({
  existing = [],
  pending = [],
  onAddFiles,
  onRemovePending,
  onRenamePending,
  onDeleteExisting,
  selectable = false,
  selectedKey = null,
  onSelectRecommended,
  uploadLabel = 'Glisser-déposer ou cliquez pour ajouter des fichiers',
  busyLabel = 'Traitement des fichiers…',
  accept = '*',
  multiple = true,
  busy = false,
  readOnly = false,
  slots,
  sx,
}) {
  const ItemSlot = slots?.item ?? AttachmentListItem;

  const canSelect = selectable && !!onSelectRecommended;

  const handleFilesPicked = (event) => {
    const list = event.target.files;
    if (list?.length) onAddFiles?.(list);
    // Allow re-picking the same file right away.
    event.target.value = '';
  };

  const hasRows = existing.length + pending.length > 0;

  return (
    <Box sx={sx}>
      {!readOnly && (
        <Button
          component="label"
          variant="outlined"
          fullWidth
          startIcon={<Iconify icon="solar:upload-bold" />}
          disabled={busy}
          sx={{
            py: 2,
            borderStyle: 'dashed',
            borderWidth: 1.5,
            fontWeight: 600,
            '&:hover': { borderStyle: 'dashed' },
          }}
        >
          {uploadLabel}
          <input type="file" hidden accept={accept} multiple={multiple} onChange={handleFilesPicked} />
        </Button>
      )}

      {!readOnly && busy && (
        <Stack direction="row" alignItems="center" spacing={1} sx={{ mt: 1 }}>
          <CircularProgress size={16} />
          <Typography variant="caption">{busyLabel}</Typography>
        </Stack>
      )}

      {hasRows && (
        <Stack spacing={1} sx={{ mt: readOnly ? 0 : 1.5 }}>
          {existing.map((att, idx) => {
            const key = `existing:${idx}`;
            return (
              <ItemSlot
                key={att.id ?? `ex-${att.name ?? idx}`}
                itemKey={key}
                meta={att.meta}
                name={att.name}
                hint={att.hint}
                url={att.url}
                recommended={canSelect ? selectedKey === key : !!att.recommended}
                selectable={canSelect}
                onPickRecommended={canSelect ? () => onSelectRecommended(key) : undefined}
                deletable={!readOnly && !!att.deletable && !!onDeleteExisting}
                onRemove={() => onDeleteExisting?.(att)}
              />
            );
          })}

          {pending.map((item, idx) => {
            const key = `new:${idx}`;
            return (
              <ItemSlot
                key={key}
                itemKey={key}
                meta={item.meta}
                name={item.name ?? item.file?.name}
                hint={fmtBytes(item.file?.size)}
                editable={!readOnly}
                onRename={(value) => onRenamePending?.(idx, value)}
                recommended={canSelect && selectedKey === key}
                selectable={canSelect}
                onPickRecommended={canSelect ? () => onSelectRecommended(key) : undefined}
                deletable={!readOnly}
                onRemove={() => onRemovePending?.(idx)}
              />
            );
          })}
        </Stack>
      )}
    </Box>
  );
}

// ----------------------------------------------------------------------

// Human file size — same output as the source app's fmtBytes.
function fmtBytes(n) {
  if (n == null) return '';
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / 1024 / 1024).toFixed(2)} MB`;
}
