import { useRef, useMemo, useState, useCallback } from 'react';

// ----------------------------------------------------------------------
// Local state for freshly picked File objects, kept OUTSIDE any form state
// (raw File instances don't survive react-hook-form serialization cleanly).
// Mirrors the pendingFiles/pendingNames parallel arrays used by the source
// app's request dialogs, merged into a single [{ file, name }] list.
//
// Returns:
//   files            [{ file: File, name: string }] — name is the editable
//                    display name, initialised from file.name
//   add(fileList)    append a FileList / File[] (e.g. e.target.files)
//   remove(index)    drop one entry
//   rename(index, name)  change an entry's display name
//   clear()          reset to empty (e.g. when a dialog re-opens)
//   getFiles()       raw File[] snapshot for upload at submit time

export function usePendingFiles() {
  const [files, setFiles] = useState([]);

  // Ref mirror so getFiles() is stable yet never stale.
  const filesRef = useRef(files);
  filesRef.current = files;

  const add = useCallback((fileList) => {
    const list = Array.from(fileList ?? []);
    if (!list.length) return;
    setFiles((prev) => [...prev, ...list.map((file) => ({ file, name: file.name }))]);
  }, []);

  const remove = useCallback((index) => {
    setFiles((prev) => prev.filter((_, i) => i !== index));
  }, []);

  const rename = useCallback((index, name) => {
    setFiles((prev) => prev.map((item, i) => (i === index ? { ...item, name } : item)));
  }, []);

  const clear = useCallback(() => setFiles([]), []);

  const getFiles = useCallback(() => filesRef.current.map((item) => item.file), []);

  return useMemo(
    () => ({ files, add, remove, rename, clear, getFiles }),
    [files, add, remove, rename, clear, getFiles]
  );
}
