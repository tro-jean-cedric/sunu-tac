import { Card, Stack, Button, Divider, Typography, CardHeader, CardContent } from '@mui/material';

import { Iconify } from 'src/components/iconify';

import { AttachmentListItem } from './attachment-list-item';

// ----------------------------------------------------------------------
// Read-only attachment card — the detail-drawer "Devis / Pro-forma" variant.
// Outlined card with a paperclip header, one AttachmentListItem per file
// (name links to `url`, trailing download icon, success highlight + check
// glyph on the recommended one) and an empty state with a CTA button when
// the viewer can manage the files.
//
// Props:
//   attachments      [{ id, name, hint?, url?, recommended? }] — hint is a
//                    node (uploader chip, date…); urls arrive resolved
//   canManage        bool (false) — show the "Modifier" header action and
//                    the empty-state CTA
//   onManage         () => void — open the managing dialog
//   title            string ('Devis / Pro-forma')
//   emptyText        string ('Aucun devis / pro-forma chargé pour cette demande.')
//   manageLabel      string ('Modifier') — header action label
//   emptyActionLabel string ('Charger des devis') — empty-state CTA label
//   sx               root sx override

export function AttachmentListCard({
  attachments = [],
  canManage = false,
  onManage,
  title = 'Devis / Pro-forma',
  emptyText = 'Aucun devis / pro-forma chargé pour cette demande.',
  manageLabel = 'Modifier',
  emptyActionLabel = 'Charger des devis',
  sx,
}) {
  if (!attachments.length) {
    return (
      <Card variant="outlined" sx={{ borderRadius: 2, p: 4, textAlign: 'center', ...sx }}>
        <Iconify icon="solar:file-bold" width={42} sx={{ color: 'text.disabled', mb: 1 }} />
        <Typography variant="body2" color="text.secondary">
          {emptyText}
        </Typography>
        {canManage && (
          <Button
            variant="contained"
            startIcon={<Iconify icon="solar:upload-bold" />}
            onClick={onManage}
            sx={{ mt: 2 }}
          >
            {emptyActionLabel}
          </Button>
        )}
      </Card>
    );
  }

  return (
    <Card variant="outlined" sx={{ borderRadius: 2, ...sx }}>
      <CardHeader
        avatar={<Iconify icon="solar:paperclip-bold" width={20} sx={{ color: 'primary.main' }} />}
        title={title}
        titleTypographyProps={{ variant: 'subtitle1', fontWeight: 700 }}
        action={
          canManage ? (
            <Button
              size="small"
              variant="outlined"
              startIcon={<Iconify icon="material-symbols:edit-outline-rounded" />}
              onClick={onManage}
            >
              {manageLabel}
            </Button>
          ) : null
        }
        sx={{ pb: 1 }}
      />
      <Divider />
      <CardContent>
        <Stack spacing={1.25}>
          {attachments.map((att, idx) => (
            <AttachmentListItem
              key={att.id ?? att.name ?? idx}
              name={att.name}
              hint={att.hint}
              url={att.url}
              recommended={!!att.recommended}
              recommendedColor="success"
              showDownload
              sx={{ py: 1.25 }}
              slotProps={{
                name: { fontWeight: 600 },
                icon: { width: 32, height: 32 },
              }}
            />
          ))}
        </Stack>
      </CardContent>
    </Card>
  );
}
