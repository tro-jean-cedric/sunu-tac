import { Box, Radio, Stack, Tooltip, TextField, Typography, IconButton } from '@mui/material';

import { Iconify } from 'src/components/iconify';
import { FileThumbnail } from 'src/components/file-thumbnail';

// ----------------------------------------------------------------------
// One attachment row — the file idiom shared by the request dialogs and the
// detail drawer. Ext-based thumbnail (FileThumbnail replaces the app's three
// duplicated `fileExtIcon` copies), display name (inline-rename TextField when
// `editable`, preview/download link when `url`), hint caption (size / date /
// uploader), optional radio for "recommended quote" selection, optional
// trailing download & delete buttons. A recommended row gets a coloured
// border + tinted background, plus a check glyph when not selectable.
//
// Props:
//   name               string — display name (drives the ext thumbnail)
//   hint               node — caption under the name (size, date, uploader…)
//   url                string — preview/download href; name becomes a link
//   icon               node — custom leading icon, replaces FileThumbnail
//   editable           bool (false) — inline rename TextField
//   onRename           (value) => void
//   recommended        bool (false) — highlighted state
//   recommendedColor   'primary' | 'success' | … ('primary') — highlight tint
//   selectable         bool (false) — show the recommended Radio
//   onPickRecommended  () => void — radio change handler
//   deletable          bool (false) — show the delete IconButton
//   onRemove           () => void
//   showDownload       bool (false) — trailing download IconButton (needs url)
//   pickTooltip / recommendedTooltip / deleteTooltip / downloadTooltip
//                      strings — French defaults, overridable
//   slotProps          { name, hint, icon } — sx overrides per slot
//   sx                 root sx override

export function AttachmentListItem({
  name,
  hint,
  url,
  icon,
  editable = false,
  onRename,
  recommended = false,
  recommendedColor = 'primary',
  selectable = false,
  onPickRecommended,
  deletable = false,
  onRemove,
  showDownload = false,
  pickTooltip = 'Marquer comme devis recommandé',
  recommendedTooltip = 'Devis recommandé',
  deleteTooltip = 'Supprimer',
  downloadTooltip = 'Ouvrir / Télécharger',
  slotProps,
  sx,
}) {
  const renderName = () => {
    if (editable) {
      return (
        <TextField
          size="small"
          variant="standard"
          value={name ?? ''}
          onChange={(event) => onRename?.(event.target.value)}
          fullWidth
        />
      );
    }
    if (url) {
      return (
        <Typography
          variant="body2"
          component="a"
          href={url}
          target="_blank"
          rel="noreferrer"
          sx={{
            fontWeight: 500,
            color: 'text.primary',
            textDecoration: 'none',
            '&:hover': { color: 'primary.main' },
            overflow: 'hidden',
            textOverflow: 'ellipsis',
            whiteSpace: 'nowrap',
            ...slotProps?.name,
          }}
        >
          {name}
        </Typography>
      );
    }
    return (
      <Typography variant="body2" noWrap sx={{ fontWeight: 500, ...slotProps?.name }}>
        {name}
      </Typography>
    );
  };

  return (
    <Stack
      direction="row"
      alignItems="center"
      spacing={1.5}
      sx={{
        px: 1.5,
        py: 1,
        borderRadius: 1.5,
        border: 1,
        borderColor: recommended ? `${recommendedColor}.main` : 'divider',
        bgcolor: recommended ? `${recommendedColor}.lighter` : 'background.neutral',
        ...sx,
      }}
    >
      {selectable && (
        <Tooltip title={pickTooltip}>
          <Radio size="small" checked={!!recommended} onChange={() => onPickRecommended?.()} />
        </Tooltip>
      )}

      {icon ?? (
        <FileThumbnail
          file={name || url || ''}
          sx={{ width: 28, height: 28, ...slotProps?.icon }}
        />
      )}

      <Box sx={{ flex: 1, minWidth: 0 }}>
        <Stack direction="row" alignItems="center" spacing={1}>
          {renderName()}
          {recommended && !selectable && (
            <Tooltip title={recommendedTooltip}>
              <Iconify
                icon="solar:check-circle-bold"
                width={18}
                sx={{ flexShrink: 0, color: `${recommendedColor}.main` }}
              />
            </Tooltip>
          )}
        </Stack>
        {hint && (
          <Typography
            variant="caption"
            color="text.secondary"
            component="div"
            sx={slotProps?.hint}
          >
            {hint}
          </Typography>
        )}
      </Box>

      {showDownload && url && (
        <Tooltip title={downloadTooltip}>
          <IconButton
            size="small"
            component="a"
            href={url}
            target="_blank"
            rel="noreferrer"
            download
            sx={{ color: 'black' }}
          >
            <Iconify icon="solar:download-bold" width={18} />
          </IconButton>
        </Tooltip>
      )}

      {deletable && (
        <Tooltip title={deleteTooltip}>
          <IconButton size="small" color="error" onClick={onRemove}>
            <Iconify icon="tabler:trash" width={18} />
          </IconButton>
        </Tooltip>
      )}
    </Stack>
  );
}
