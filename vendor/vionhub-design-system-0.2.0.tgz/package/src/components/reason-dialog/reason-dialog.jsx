import { useState, useEffect } from 'react';

import LoadingButton from '@mui/lab/LoadingButton';
import {
  Stack,
  Dialog,
  Button,
  MenuItem,
  TextField,
  Typography,
  DialogTitle,
  DialogContent,
  DialogActions,
} from '@mui/material';

import { Iconify } from 'src/components/iconify';
import { DialogCloseButton } from 'src/components/custom-dialog';

// ----------------------------------------------------------------------
// Generic "reason" confirmation dialog for workflow actions (approve /
// reject / send-back...). Consolidates the app's ApprovalDialog and
// PurchaseOrderRejectDialog into one declarative component: the caller
// describes the action with plain props, owns the async side effect in
// `onSubmit`, and toasts on failure.
//
// Props:
// - open, onClose            — controlled visibility. All fields reset every
//                              time `open` flips true.
// - title                    — dialog title (e.g. "Rejeter la demande").
// - subtitle                 — optional caption under the title (entity code).
// - color                    — MUI palette of the submit button ('primary' |
//                              'error' | 'warning' | ...). Default 'primary'.
// - icon                     — optional Iconify name for the submit button
//                              start icon (e.g. 'solar:dislike-bold').
// - requireReason            — when true the reason field is required and
//                              validated inline (helperText, no toast).
// - reasonLabel / reasonPlaceholder / minRows — reason TextField config.
// - targetOptions            — optional [{ label, value }]; when provided a
//                              Select is rendered to pick the send-back
//                              target (anterior actor in the workflow).
// - targetLabel / targetHelperText / targetRequired / targetRequiredMessage
//                            — target Select config + its own validation.
// - submitLabel / cancelLabel — footer button texts.
// - requiredMessage          — inline error when the reason is missing.
// - onSubmit                 — async ({ reason, target }) => {}. The dialog
//                              owns the submitting state: resolve closes and
//                              resets, throw keeps it open (caller toasts).
// - disableBackdropClose     — guard backdrop clicks (default true); the
//                              close button / Cancel always work when idle.

export function ReasonDialog({
  open,
  onClose,
  title,
  subtitle,
  color = 'primary',
  icon,
  requireReason = false,
  reasonLabel = 'Motif',
  reasonPlaceholder,
  minRows = 4,
  targetOptions,
  targetLabel = 'Renvoyer vers',
  targetHelperText,
  targetRequired = false,
  targetRequiredMessage = 'Veuillez choisir un destinataire.',
  submitLabel = 'Confirmer',
  cancelLabel = 'Annuler',
  requiredMessage = 'Motif obligatoire.',
  onSubmit,
  disableBackdropClose = true,
}) {
  const [reason, setReason] = useState('');
  // Selected target as an index into targetOptions (not the value itself) —
  // the Select is keyed by index so labels stay stable even if two options
  // ever resolve to the same value.
  const [targetIdx, setTargetIdx] = useState('');
  const [reasonError, setReasonError] = useState('');
  const [targetError, setTargetError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const hasTarget = Array.isArray(targetOptions) && targetOptions.length > 0;

  // Reset everything whenever the dialog reopens so we never carry a stale
  // reason / selection / error across uses.
  useEffect(() => {
    if (open) {
      setReason('');
      setTargetIdx('');
      setReasonError('');
      setTargetError('');
    }
  }, [open]);

  const handleClose = () => {
    if (submitting) return;
    onClose?.();
  };

  // Backdrop-close guard — replaces the app's staticDialog util.
  const handleDialogClose = (event, closeReason) => {
    if (disableBackdropClose && closeReason === 'backdropClick') return;
    handleClose();
  };

  const handleSubmit = async () => {
    let invalid = false;
    if (requireReason && !reason.trim()) {
      setReasonError(requiredMessage);
      invalid = true;
    }
    if (hasTarget && targetRequired && targetIdx === '') {
      setTargetError(targetRequiredMessage);
      invalid = true;
    }
    if (invalid) return;

    setSubmitting(true);
    try {
      await onSubmit?.({
        reason,
        target: hasTarget && targetIdx !== '' ? targetOptions[targetIdx]?.value : undefined,
      });
      setReason('');
      setTargetIdx('');
      onClose?.();
    } catch {
      // Failure: keep the dialog open with its content intact — the caller's
      // onSubmit is responsible for surfacing the error (toast).
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Dialog
      fullWidth
      maxWidth="sm"
      open={open}
      onClose={handleDialogClose}
      PaperProps={{ sx: { borderRadius: 2 } }}
    >
      <DialogCloseButton onClick={handleClose} />
      <DialogTitle>
        <Stack spacing={0.25}>
          <Typography variant="h6">{title}</Typography>
          {subtitle && (
            <Typography variant="caption" color="text.secondary">
              {subtitle}
            </Typography>
          )}
        </Stack>
      </DialogTitle>
      <DialogContent dividers>
        <Stack spacing={2} sx={{ pt: 1 }}>
          <TextField
            autoFocus
            fullWidth
            multiline
            minRows={minRows}
            label={reasonLabel}
            placeholder={reasonPlaceholder}
            value={reason}
            onChange={(e) => {
              setReason(e.target.value);
              if (reasonError) setReasonError('');
            }}
            required={requireReason}
            error={!!reasonError}
            helperText={reasonError || undefined}
          />
          {hasTarget && (
            <TextField
              select
              fullWidth
              label={targetLabel}
              value={targetIdx}
              onChange={(e) => {
                setTargetIdx(e.target.value);
                if (targetError) setTargetError('');
              }}
              required={targetRequired}
              error={!!targetError}
              helperText={targetError || targetHelperText}
            >
              {targetOptions.map((opt, i) => (
                <MenuItem key={`${opt.value}-${i}`} value={i}>
                  {opt.label}
                </MenuItem>
              ))}
            </TextField>
          )}
        </Stack>
      </DialogContent>
      <DialogActions sx={{ px: 3, py: 2 }}>
        <Button onClick={handleClose} color="inherit" disabled={submitting}>
          {cancelLabel}
        </Button>
        <LoadingButton
          variant="contained"
          color={color}
          loading={submitting}
          startIcon={icon ? <Iconify icon={icon} width={18} /> : undefined}
          onClick={handleSubmit}
        >
          {submitLabel}
        </LoadingButton>
      </DialogActions>
    </Dialog>
  );
}
