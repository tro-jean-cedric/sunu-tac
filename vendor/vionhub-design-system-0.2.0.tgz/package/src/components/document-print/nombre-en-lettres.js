// ----------------------------------------------------------------------
// French amount-in-words. Handles 0 to 999 999 999 — enough for FCFA
// amounts ("arrêté le présent ordre à la somme de …"). Pure function, no
// dependencies: also import-worthy from app-side utils if you need it
// outside the document-print components. Mirrors the app's
// StringUtils.nombreEnLettres output where it matters; rare edge cases
// produce a best-effort string.

const UNITS = ['zéro', 'un', 'deux', 'trois', 'quatre', 'cinq', 'six', 'sept', 'huit', 'neuf', 'dix',
  'onze', 'douze', 'treize', 'quatorze', 'quinze', 'seize', 'dix-sept', 'dix-huit', 'dix-neuf'];
const TENS = ['', '', 'vingt', 'trente', 'quarante', 'cinquante', 'soixante', 'soixante', 'quatre-vingt', 'quatre-vingt'];

function below100(n) {
  if (n < 20) return UNITS[n];
  const t = Math.floor(n / 10);
  const u = n % 10;
  if (t === 7 || t === 9) {
    const base = TENS[t];
    return `${base}-${UNITS[10 + u]}`;
  }
  if (t === 8 && u === 0) return 'quatre-vingts';
  let s = TENS[t];
  if (u === 1 && t !== 8) s += ' et un';
  else if (u !== 0) s += `-${UNITS[u]}`;
  return s;
}

function below1000(n) {
  if (n < 100) return below100(n);
  const c = Math.floor(n / 100);
  const r = n % 100;
  let s;
  if (c === 1) s = 'cent';
  else s = `${UNITS[c]} cents`;
  if (r) s = `${c === 1 ? 'cent' : `${UNITS[c]} cent`} ${below100(r)}`;
  return s;
}

export function nombreEnLettres(n) {
  if (n == null) return '';
  const num = Math.abs(Math.floor(Number(n)));
  if (Number.isNaN(num)) return '';
  if (num === 0) return 'zéro';

  const millions = Math.floor(num / 1_000_000);
  const thousands = Math.floor((num % 1_000_000) / 1000);
  const rest = num % 1000;
  const parts = [];
  if (millions) parts.push(millions === 1 ? 'un million' : `${below1000(millions)} millions`);
  // "cent" and "vingt" lose their plural 's' when they multiply "mille":
  // 500 000 → "cinq cent mille" (not "cinq cents mille"),
  // 80 000 → "quatre-vingt mille" (not "quatre-vingts mille").
  if (thousands)
    parts.push(
      thousands === 1 ? 'mille' : `${below1000(thousands).replace(/(cent|vingt)s$/, '$1')} mille`
    );
  if (rest) parts.push(below1000(rest));
  return parts.join(' ');
}
