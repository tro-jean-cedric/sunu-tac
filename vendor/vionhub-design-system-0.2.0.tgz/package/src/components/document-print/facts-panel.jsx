import { Paper, Stack, Typography } from '@mui/material';

// ----------------------------------------------------------------------
// Outlined facts panel — the "CONDITIONS" / "FOURNISSEUR" blocks of the
// purchase-order preview: centered bold heading over caption rows of
// "Label : value".
//
// Props:
// - title        — panel heading (rendered as-is; the app uses uppercase).
// - facts        — [{ label, value }] rows; `value` can be any node and
//                  falls back to '—' when nullish.
// - emptyMessage — caption shown when `facts` is empty (e.g. "Aucun
//                  fournisseur renseigné."). Default 'Aucune information.'.
// - sx           — extra styles on the Paper.

export function FactsPanel({ title, facts = [], emptyMessage = 'Aucune information.', sx }) {
  return (
    <Paper variant="outlined" sx={{ p: 2, borderRadius: 1.5, ...sx }}>
      <Typography variant="subtitle2" align="center" sx={{ fontWeight: 700, mb: 1 }}>
        {title}
      </Typography>
      {facts.length ? (
        <Stack spacing={0.75}>
          {facts.map((fact, index) => (
            // eslint-disable-next-line react/no-array-index-key
            <Typography key={index} variant="caption">
              {fact.label} : <b>{fact.value ?? '—'}</b>
            </Typography>
          ))}
        </Stack>
      ) : (
        <Typography variant="caption" color="text.secondary">
          {emptyMessage}
        </Typography>
      )}
    </Paper>
  );
}
