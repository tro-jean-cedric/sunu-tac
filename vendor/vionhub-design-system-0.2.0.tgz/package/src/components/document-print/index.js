// Printable Document kit — paper-document rendering extracted from the
// app's print dialogs (fiche de demande, ordre de règlement) and the
// purchase-order preview card.
//
// Print half: PrintDialog + PrintSheet (+ PRINTABLE_CSS) and the sheet
// primitives PrintSectionBanner / DottedField / PrintCheckBox, plus the
// nombreEnLettres amount-in-words util.
// Preview half: DocumentPreviewCard composed from FactsPanel,
// LineItemsSummaryTable and TotalBar.

export * from './total-bar';
export * from './facts-panel';
export * from './print-sheet';
export * from './print-dialog';
export * from './nombre-en-lettres';
export * from './document-preview-card';
export * from './line-items-summary-table';
