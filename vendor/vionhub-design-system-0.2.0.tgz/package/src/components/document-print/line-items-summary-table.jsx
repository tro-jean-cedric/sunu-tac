import {
  Table,
  Paper,
  TableRow,
  TableBody,
  TableCell,
  TableHead,
  TableContainer,
} from '@mui/material';

// ----------------------------------------------------------------------
// Compact read-only line-items table — the articles table of the
// purchase-order preview. Read-only sibling of the editable-items-table
// family: same outlined container / small density / bold header cells,
// but purely declarative.
//
// Props:
// - columns      — [{ key, label, align?, render?, sx? }]. `render(row,
//                  index)` overrides the default `row[key]` cell content;
//                  `sx` is applied to the body cells (e.g. maxWidth +
//                  wordBreak on a description column).
// - rows         — data array. Row key: row.id when present, else index.
// - emptyMessage — centered italic row when `rows` is empty.
//                  Default 'Aucun article.'.
// - sx           — extra styles on the TableContainer.

export function LineItemsSummaryTable({ columns = [], rows = [], emptyMessage = 'Aucun article.', sx }) {
  return (
    <TableContainer component={Paper} variant="outlined" sx={{ borderRadius: 1.5, ...sx }}>
      <Table size="small">
        <TableHead>
          <TableRow>
            {columns.map((column) => (
              <TableCell key={column.key} align={column.align} sx={{ fontWeight: 700 }}>
                {column.label}
              </TableCell>
            ))}
          </TableRow>
        </TableHead>
        <TableBody>
          {rows.length === 0 && (
            <TableRow>
              <TableCell
                colSpan={columns.length}
                align="center"
                sx={{ py: 3, color: 'text.secondary', fontStyle: 'italic' }}
              >
                {emptyMessage}
              </TableCell>
            </TableRow>
          )}
          {rows.map((row, index) => (
            <TableRow key={row.id ?? index} hover>
              {columns.map((column) => (
                <TableCell key={column.key} align={column.align} sx={column.sx}>
                  {column.render ? column.render(row, index) : row[column.key]}
                </TableCell>
              ))}
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
}
