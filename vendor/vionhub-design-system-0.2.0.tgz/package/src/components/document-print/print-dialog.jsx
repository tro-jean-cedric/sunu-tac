import {
  Box,
  Stack,
  Dialog,
  Button,
  Typography,
  DialogTitle,
  DialogContent,
  DialogActions,
} from '@mui/material';

import { staticDialog } from 'src/utils/dialog';

import { Iconify } from 'src/components/iconify';
import { DialogCloseButton } from 'src/components/custom-dialog';

// ----------------------------------------------------------------------
// Shell dialog for printable documents — the frame shared by the app's
// "Fiche de demande d'achat" and "Ordre de règlement" dialogs. Icon title,
// neutral-background content hosting a PrintSheet (children), footer with
// Close on the left and a contained Print button on the right.
//
// Props:
// - open / onClose  — controlled visibility. Backdrop clicks are guarded
//                     (staticDialog); the close button and Close always work.
// - title           — dialog title text (e.g. "Fiche de demande d'achat").
// - icon            — optional Iconify name rendered before the title in
//                     primary colour (e.g. 'solar:document-text-bold').
// - maxWidth        — MUI Dialog maxWidth. Default 'md' (A4-ish).
// - printLabel      — print button text. Default 'Imprimer'.
// - closeLabel      — close button text. Default 'Fermer'.
// - onPrint         — optional override of the print action; defaults to
//                     window.print() (PRINTABLE_CSS's @media print rules
//                     make only the sheet visible on paper).
// - children        — dialog body, typically a <PrintSheet> with the
//                     document layout (layouts themselves stay app-side).

export function PrintDialog({
  open,
  onClose,
  title,
  icon,
  maxWidth = 'md',
  printLabel = 'Imprimer',
  closeLabel = 'Fermer',
  onPrint,
  children,
}) {
  const handlePrint = () => {
    if (onPrint) onPrint();
    else window.print();
  };

  return (
    <Dialog
      fullWidth
      maxWidth={maxWidth}
      open={open}
      onClose={staticDialog(onClose)}
      PaperProps={{ sx: { borderRadius: 2 } }}
    >
      <DialogCloseButton onClick={onClose} />
      <DialogTitle>
        <Stack direction="row" alignItems="center" spacing={1.5}>
          {icon && <Iconify icon={icon} width={22} sx={{ color: 'primary.main' }} />}
          <Typography variant="h6" sx={{ lineHeight: 1.2 }}>
            {title}
          </Typography>
        </Stack>
      </DialogTitle>
      <DialogContent dividers sx={{ bgcolor: 'background.neutral', p: 3 }}>
        {children}
      </DialogContent>
      <DialogActions sx={{ px: 3, py: 2 }}>
        <Button onClick={onClose} color="inherit">
          {closeLabel}
        </Button>
        <Box sx={{ flex: 1 }} />
        <Button
          variant="contained"
          startIcon={<Iconify icon="solar:printer-bold" />}
          onClick={handlePrint}
        >
          {printLabel}
        </Button>
      </DialogActions>
    </Dialog>
  );
}
