import { useEffect } from 'react';

import { Box } from '@mui/material';

// ----------------------------------------------------------------------
// Paper-document primitives — the A4-style printable sheet used by the
// app's "Fiche de demande d'achat" and "Ordre de règlement" dialogs.
//
// The visual language is intentionally old-school paperwork: dotted
// underlines on fields, a small grey section banner, square check-box
// glyphs. `PRINTABLE_CSS` keeps that styling scoped under `.print-sheet`
// and adds the @media print rules that hide everything but the sheet so
// window.print() outputs the document full-page.
//
// - PrintSheet({ className = 'print-sheet', sx, children }) — white
//   A4-style surface; injects PRINTABLE_CSS once into <head>. Keep the
//   'print-sheet' class if you override `className`, otherwise the scoped
//   styles (and the print rules) no longer apply.
// - PrintSectionBanner({ children, sx }) — grey uppercase band.
// - DottedField({ label, value, flex }) — "Label :" + value over a dotted
//   underline that fills the remaining width.
// - PrintCheckBox({ checked, label }) — bordered check-box glyph, optional
//   leading label.

export const PRINTABLE_CSS = `
.print-sheet .dotted-line {
  display: inline-block;
  width: 100%;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  position: relative;
}
.print-sheet .dotted-line::before {
  content: "";
  position: absolute;
  right: 0;
  top: 9px;
  bottom: 0;
  background: radial-gradient(circle closest-side, black 109%, transparent 4%) repeat-x;
  background-size: 6.2px 1.3px;
  width: 100%;
  z-index: 0;
}
.print-sheet .dotted-line-content {
  position: relative;
  background-color: white;
  display: inline-block;
  padding-right: 10px;
}
.print-sheet .dotted-line-content,
.print-sheet .dotted-line-content *,
.print-sheet .dotted-line *,
.print-sheet .small-text,
.print-sheet .small-text * {
  font-size: x-small !important;
}
.print-sheet .bg-main-grey {
  background-color: #4f4f4f47;
  color: black;
  padding: 2px 4px;
}
.print-sheet .check-box {
  display: inline-block;
  border: 1px solid #555;
  padding: 0 6px;
  min-width: 24px;
  text-align: center;
}
@media print {
  body * { visibility: hidden; }
  .print-sheet, .print-sheet * { visibility: visible; }
  .print-sheet { position: absolute; inset: 0; padding: 16mm; background: white; }
}
`;

// Injects PRINTABLE_CSS into <head> while at least one PrintSheet is
// mounted — every PrintSheet calls this, a module-level reference count
// keeps a single <style> tag no matter how many sheets mount, and the tag
// is removed when the last sheet unmounts. Removal matters: the @media
// print rules hide the whole body and only reveal `.print-sheet`, so
// leaving the tag behind after the last sheet is gone would make any
// subsequent browser print of the host page come out blank.
const STYLE_ID = 'vionhub-print-sheet-css';

let printableCssRefCount = 0;

function usePrintableCss() {
  useEffect(() => {
    if (typeof document === 'undefined') return undefined;
    printableCssRefCount += 1;
    if (!document.getElementById(STYLE_ID)) {
      const style = document.createElement('style');
      style.id = STYLE_ID;
      style.textContent = PRINTABLE_CSS;
      document.head.appendChild(style);
    }
    return () => {
      printableCssRefCount -= 1;
      if (printableCssRefCount <= 0) {
        printableCssRefCount = 0;
        document.getElementById(STYLE_ID)?.remove();
      }
    };
  }, []);
}

// ----------------------------------------------------------------------

export function PrintSheet({ className = 'print-sheet', sx, children }) {
  usePrintableCss();

  return (
    <Box
      className={className}
      sx={{
        bgcolor: 'common.white',
        color: 'common.black',
        p: 3,
        borderRadius: 1,
        boxShadow: 1,
        ...sx,
      }}
    >
      {children}
    </Box>
  );
}

// ----------------------------------------------------------------------

export function PrintSectionBanner({ children, sx }) {
  return (
    <Box
      className="bg-main-grey"
      sx={{ textAlign: 'center', fontWeight: 700, textTransform: 'uppercase', mt: 2, mb: 1, ...sx }}
    >
      {children}
    </Box>
  );
}

// ----------------------------------------------------------------------

export function DottedField({ label, value, flex, sx }) {
  return (
    <Box className="dotted-line" sx={{ mb: 0.5, ...(flex != null && { flex }), ...sx }}>
      <Box className="dotted-line-content">
        <b>{label} :</b> <span style={{ marginLeft: 4 }}>{value ?? ''}</span>
      </Box>
    </Box>
  );
}

// ----------------------------------------------------------------------

export function PrintCheckBox({ checked, label }) {
  return (
    <span>
      {label != null && <>{label} </>}
      <span className="check-box">{checked ? '✓' : ' '}</span>
    </span>
  );
}
