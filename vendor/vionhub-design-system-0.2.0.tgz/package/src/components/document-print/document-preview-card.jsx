import { Box, Card, Paper, Stack, Typography, CardContent } from '@mui/material';

import { TotalBar } from './total-bar';
import { FactsPanel } from './facts-panel';
import { LineItemsSummaryTable } from './line-items-summary-table';

// ----------------------------------------------------------------------
// On-screen document preview card — the printable purchase-order block of
// the app's fullscreen PO details dialog. Composes the preview primitives
// into one paper-like document: centered uppercase title + date line, a
// responsive grid of FactsPanels, the line-items summary table, the
// highlighted total bar and an optional comment panel.
//
// Data arrives fully resolved (no services, no asset-URL helpers): the
// caller fetches the document and maps it to plain props.
//
// Props:
// - title        — document heading, rendered centered in h5/700 (e.g.
//                  "BON DE COMMANDE N° BC-2026-0087").
// - subtitle     — optional node under the title (e.g. <>Abidjan, le
//                  <b>12 mars 2026</b></>).
// - panels       — [{ title, facts, emptyMessage? }] rendered as
//                  FactsPanels in a responsive 1–2 column grid.
// - columns      — LineItemsSummaryTable columns ([{ key, label, align?,
//                  render?, sx? }]).
// - items        — LineItemsSummaryTable rows.
// - emptyMessage — empty-table message (default 'Aucun article.').
// - totalLabel   — TotalBar caption (e.g. 'MONTANT TOTAL (FCFA TTC)').
// - totalValue   — TotalBar amount.
// - formatValue  — TotalBar formatter override (default fCurrency; the
//                  app passes fNumber).
// - comment      — optional comment text, shown pre-wrapped in an
//                  outlined panel under `commentLabel` ('Commentaire').
// - children     — extra nodes appended inside the card (signature rows,
//                  action history… fetched and rendered by the caller).
// - sx           — extra styles on the Card.

export function DocumentPreviewCard({
  title,
  subtitle,
  panels = [],
  columns = [],
  items = [],
  emptyMessage,
  totalLabel,
  totalValue,
  formatValue,
  comment,
  commentLabel = 'Commentaire',
  children,
  sx,
}) {
  return (
    <Card variant="outlined" sx={{ borderRadius: 2, ...sx }}>
      <CardContent sx={{ p: { xs: 2, md: 3 } }}>
        <Stack spacing={3}>
          <Box sx={{ textAlign: 'center' }}>
            <Typography variant="h5" sx={{ fontWeight: 700, letterSpacing: 0.5, mt: 1 }}>
              {title}
            </Typography>
            {subtitle && (
              <Typography variant="body2" color="text.secondary" sx={{ mt: 0.5 }}>
                {subtitle}
              </Typography>
            )}
          </Box>

          {panels.length > 0 && (
            <Box
              sx={{
                display: 'grid',
                gap: 2,
                gridTemplateColumns: {
                  xs: '1fr',
                  md: `repeat(${Math.min(panels.length, 2)}, 1fr)`,
                },
              }}
            >
              {panels.map((panel, index) => (
                <FactsPanel
                  // eslint-disable-next-line react/no-array-index-key
                  key={index}
                  title={panel.title}
                  facts={panel.facts}
                  emptyMessage={panel.emptyMessage}
                />
              ))}
            </Box>
          )}

          <LineItemsSummaryTable columns={columns} rows={items} emptyMessage={emptyMessage} />

          {totalLabel != null && (
            <TotalBar label={totalLabel} value={totalValue} formatter={formatValue} />
          )}

          {comment && (
            <Paper variant="outlined" sx={{ p: 2, borderRadius: 1.5 }}>
              <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 0.5 }}>
                {commentLabel}
              </Typography>
              <Typography variant="body2" sx={{ whiteSpace: 'pre-wrap' }}>
                {comment}
              </Typography>
            </Paper>
          )}

          {children}
        </Stack>
      </CardContent>
    </Card>
  );
}
