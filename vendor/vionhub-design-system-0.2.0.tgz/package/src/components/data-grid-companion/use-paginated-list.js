import { useRef, useState, useEffect, useCallback } from 'react';

// ----------------------------------------------------------------------
// usePaginatedList — drives a server-paginated list (the data-side companion
// to AsyncDataGrid; its return value plugs straight into the grid's
// rows/total/page/pageSize/search/loading/onPageChange/... props).
//
// Props (options object):
// - fetcher       (required) `fetcher({ page, size, [searchParam]: search, ...extraParams })`
//                 must return a promise resolving to the server response.
//                 IMPORTANT: `page` is 1-based — adapt in your fetcher if the
//                 backend expects 0-based page numbers. May be an inline arrow
//                 function — it is read through a ref, so an unstable
//                 reference does NOT cause a refetch loop.
// - defaultSize   initial page size (default 10).
// - extraParams   extra query params merged into every fetch. May be an
//                 inline object literal — changes are detected by value
//                 (JSON.stringify compared inside a ref), so an unstable
//                 reference does NOT cause a refetch loop.
// - cacheKey      opt-in SWR-lite cache scope (default null = no cache).
//                 When set, revisits (tab toggles, back-navigations) paint
//                 cached rows instantly — loading stays false — while a
//                 fresh fetch silently revalidates. In-flight requests for
//                 the same key are deduped, which also absorbs React 18
//                 StrictMode's dev double-mount. Bake your server-side
//                 filters into the key (e.g. `requests:${scope}:${status}`);
//                 the hook adds page/size/search itself.
// - select        `select(res) => ({ rows, total })` adapts the server
//                 response. Default probes, in order:
//                 res.data.content/res.data.totalElements (Spring envelope),
//                 res.content/res.totalElements, res.rows/res.total.
// - searchParam   name of the query param carrying the search text
//                 (default 'name').
// - errorMessage  fallback error text when the caught error has no message
//                 (default 'Erreur de chargement').
//
// Returns { rows, total, page, pageSize, search, loading, error,
//           setPage, setPageSize, setSearch, refresh }.
// - loading is true only on cold loads (no cached slot) — SWR semantics.
// - setSearch resets page to 1.
// - refresh() invalidates the current cache slot then refetches, so the
//   user gets the usual spinner + fresh data (post-mutation), not a flash
//   of stale rows.
// ----------------------------------------------------------------------

// Module-scope cache: fullKey -> { rows, total, ts }. Keyed by the caller's
// `cacheKey` plus the current page/size/search so each distinct combination
// is remembered separately.
const pageCache = new Map();
const inflight = new Map();

const fullKey = (cacheKey, page, pageSize, search) =>
  cacheKey ? `${cacheKey}|${page}|${pageSize}|${search ?? ''}` : null;

const defaultSelect = (res) => {
  const envelope = res?.data;
  if (envelope && (envelope.content !== undefined || envelope.totalElements !== undefined)) {
    return { rows: envelope.content ?? [], total: envelope.totalElements ?? 0 };
  }
  if (res && (res.content !== undefined || res.totalElements !== undefined)) {
    return { rows: res.content ?? [], total: res.totalElements ?? 0 };
  }
  return { rows: res?.rows ?? [], total: res?.total ?? 0 };
};

export function usePaginatedList({
  fetcher,
  defaultSize = 10,
  extraParams = {},
  cacheKey = null,
  select = defaultSelect,
  searchParam = 'name',
  errorMessage = 'Erreur de chargement',
}) {
  // Seed initial state from cache if the caller opted in and the (key, page=1,
  // size=defaultSize, search='') combo was visited before — that's the combo
  // every list view starts with.
  const initialFull = fullKey(cacheKey, 1, defaultSize, '');
  const initialCached = initialFull ? pageCache.get(initialFull) : null;

  const [rows, setRows] = useState(initialCached?.rows ?? []);
  const [total, setTotal] = useState(initialCached?.total ?? 0);
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(defaultSize);
  const [search, setSearchState] = useState('');
  // Only show the blocking loading state on a true cold load. SWR semantics:
  // when we already have something to display, the refetch runs silently.
  const [loading, setLoading] = useState(!initialCached);
  const [error, setError] = useState(null);

  // Guard against unstable `extraParams` references (inline object literals):
  // compare by value inside a ref and only swap the stored object when the
  // serialized form actually changes. The load callback then depends on the
  // stable serialized string, never on the object identity.
  const extraRef = useRef({ serialized: JSON.stringify(extraParams ?? {}), params: extraParams ?? {} });
  const nextSerialized = JSON.stringify(extraParams ?? {});
  if (nextSerialized !== extraRef.current.serialized) {
    extraRef.current = { serialized: nextSerialized, params: extraParams ?? {} };
  }
  const extraSerialized = extraRef.current.serialized;

  const fetcherRef = useRef(fetcher);
  fetcherRef.current = fetcher;
  const selectRef = useRef(select);
  selectRef.current = select;
  const errorMessageRef = useRef(errorMessage);
  errorMessageRef.current = errorMessage;

  // Monotonic request id: each load() invocation bumps it, and only the
  // latest invocation may commit state after its await. This prevents a
  // slow earlier request (different page/filter/search) from resolving last
  // and overwriting the newer page's rows/total.
  const seqRef = useRef(0);

  const load = useCallback(async () => {
    const seq = ++seqRef.current;
    const key = fullKey(cacheKey, page, pageSize, search);
    const cached = key ? pageCache.get(key) : null;

    if (cached) {
      // Optimistic: paint cached rows now, refetch silently to revalidate.
      setRows(cached.rows);
      setTotal(cached.total);
    } else {
      setLoading(true);
    }
    setError(null);

    try {
      const params = {
        page,
        size: pageSize,
        [searchParam]: search,
        ...extraRef.current.params,
      };
      // Dedupe identical concurrent requests — covers StrictMode dev
      // double-mount and rapid tab toggling.
      let promise = key ? inflight.get(key) : null;
      if (!promise) {
        promise = fetcherRef.current(params);
        if (key) {
          inflight.set(key, promise);
          promise.finally(() => inflight.delete(key));
        }
      }
      const res = await promise;
      const { rows: nextRows = [], total: nextTotal = 0 } = selectRef.current(res) ?? {};
      // Cache writes are keyed correctly, so they are safe even for stale
      // responses — only the on-screen state is guarded.
      if (key) pageCache.set(key, { rows: nextRows, total: nextTotal, ts: Date.now() });
      if (seq !== seqRef.current) return;
      setRows(nextRows);
      setTotal(nextTotal);
    } catch (e) {
      if (seq !== seqRef.current) return;
      setError(e?.message ?? errorMessageRef.current);
      setRows([]);
      setTotal(0);
    } finally {
      if (seq === seqRef.current) setLoading(false);
    }
  }, [page, pageSize, search, searchParam, extraSerialized, cacheKey]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    load();
  }, [load]);

  // A new search means a new result set — always restart from page 1.
  const setSearch = useCallback((value) => {
    setSearchState(value);
    setPage(1);
  }, []);

  // Explicit refresh (post-mutation, refresh button…): invalidate the current
  // cache slot so the user gets the usual spinner + fresh data, not a flash of
  // pre-mutation rows. Reactive reloads (mount, param change) still use cache.
  const refresh = useCallback(() => {
    const key = fullKey(cacheKey, page, pageSize, search);
    if (key) {
      pageCache.delete(key);
      // Also drop the dedupe entry: a silent SWR revalidation for this key may
      // still be in flight (pre-mutation data) — without this, load() would
      // reuse that stale promise instead of issuing a fresh request. The seq
      // guard discards the older invocation's late commit.
      inflight.delete(key);
    }
    return load();
  }, [load, cacheKey, page, pageSize, search]);

  return {
    rows,
    total,
    page,
    pageSize,
    search,
    loading,
    error,
    setPage,
    setPageSize,
    setSearch,
    refresh,
  };
}
