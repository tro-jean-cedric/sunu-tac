import { useRef, useEffect, useCallback } from 'react';

// ----------------------------------------------------------------------
// useDeepLinkDialog — auto-open a detail dialog/drawer when a deep-link
// value appears (notification click-through to `/list/:id`, `?open=<id>`…),
// without re-triggering on every re-render.
//
// The hook is router-agnostic: the caller extracts `paramValue` from
// whatever routing/query layer it uses and does its own `router.replace`
// on close. A ref guards the trigger so `onOpen(paramValue)` fires exactly
// once per distinct value; when the value becomes undefined/null the guard
// resets, so navigating to the same deep link again re-opens.
//
// Props (options object):
// - paramValue  the deep-link value (string/number) or undefined/null when
//               absent.
// - onOpen      `onOpen(paramValue)` — open your dialog/drawer (e.g.
//               `setDetailId(Number(paramValue))`).
//
// Returns:
// - clear()  resets the guard. Wire it into the dialog's onClose alongside
//            your own URL cleanup:
//              const onClose = () => { setDetailId(null); clear();
//                router.replace(listPath); };
// ----------------------------------------------------------------------

export function useDeepLinkDialog({ paramValue, onOpen }) {
  const openedRef = useRef(null);

  const onOpenRef = useRef(onOpen);
  onOpenRef.current = onOpen;

  useEffect(() => {
    if (paramValue == null || paramValue === '') {
      openedRef.current = null;
      return;
    }
    if (openedRef.current === paramValue) return;
    openedRef.current = paramValue;
    onOpenRef.current?.(paramValue);
  }, [paramValue]);

  const clear = useCallback(() => {
    openedRef.current = null;
  }, []);

  return { clear };
}
