import { useMemo, useState, useEffect, useCallback } from 'react';

// ----------------------------------------------------------------------
// useRowGrouping — visual grouping for sibling rows on the current page
// (e.g. requests submitted together sharing a `batchCode`).
//
// Every group key with 2+ visible members gets a stable accent color from
// the palette (in iteration order); `getRowClassName` + `sx` paint a 3px
// left border on those rows so the eye links siblings even without
// sorting/expansion. Setting `focusedKey` narrows `visibleRows` client-side
// to that group — a visual narrow on the current page, not a server filter,
// so per-row actions stay untouched.
//
// Props (options object):
// - rows      current page's rows.
// - getKey    (required) `getKey(row) => string | null` — the grouping key
//             (return null/undefined for ungrouped rows).
// - palette   ordered list of theme palette accents used for group colors
//             (default ['primary', 'warning', 'info', 'success',
//             'secondary', 'error']).
//
// Returns:
// - colorOf(key)          palette color assigned to a grouped key
//                         (undefined when the key isn't a visible group).
// - focusedKey / setFocusedKey  client-side focus state. Auto-cleared when
//                         the focused group disappears from the page (page
//                         change, refresh…), so the user is never stuck on
//                         an empty filtered view.
// - visibleRows           rows narrowed to the focused group (all rows when
//                         no focus).
// - getRowClassName(params)  feed to DataGrid/AsyncDataGrid.
// - sx                    feed (or spread into) the grid's sx — paints the
//                         left-border accents + focused row background.
// ----------------------------------------------------------------------

// Visual palette for row grouping. Each group key visible on the current page
// gets a stable color from this list (in iteration order). The left-border
// accent reuses the same index everywhere so the eye links members together.
const DEFAULT_PALETTE = ['primary', 'warning', 'info', 'success', 'secondary', 'error'];

export function useRowGrouping({ rows, getKey, palette = DEFAULT_PALETTE }) {
  const [focusedKey, setFocusedKey] = useState(null);

  // Derive the accent rules from the palette so custom palette entries get a
  // matching `.group-row--<color>` rule too (not just the six defaults).
  const sx = useMemo(
    () => ({
      '& .group-row': {
        borderLeft: '3px solid',
        borderLeftColor: 'divider',
      },
      ...Object.fromEntries(
        palette.map((color) => [`& .group-row--${color}`, { borderLeftColor: `${color}.main` }])
      ),
      '& .group-row--focused': {
        backgroundColor: (theme) => theme.palette.action.hover,
      },
    }),
    [palette]
  );

  // Collect siblings per key. Only treat a key as a "group" when 2+ members
  // are visible — a lone row is just a regular row and needs no visual cue.
  const members = useMemo(() => {
    const map = new Map();
    (rows ?? []).forEach((row) => {
      const key = getKey?.(row);
      if (key == null || key === '') return;
      const list = map.get(key);
      if (list) list.push(row);
      else map.set(key, [row]);
    });
    Array.from(map.entries()).forEach(([key, list]) => {
      if (list.length < 2) map.delete(key);
    });
    return map;
    // getKey is expected to be stable (module-scope or useCallback); the map
    // only needs to rebuild when the page's rows change.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [rows]);

  // Stable key -> palette color assignment, in iteration order.
  const colorIndex = useMemo(() => {
    const idx = new Map();
    let i = 0;
    Array.from(members.keys()).forEach((key) => {
      idx.set(key, palette[i % palette.length]);
      i += 1;
    });
    return idx;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [members]);

  const colorOf = useCallback((key) => colorIndex.get(key), [colorIndex]);

  const visibleRows = useMemo(() => {
    if (!focusedKey) return rows;
    return (rows ?? []).filter((row) => getKey?.(row) === focusedKey);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [rows, focusedKey]);

  // If the focused group disappears from the page (page change, refresh that
  // moved its members…), drop the focus so the user isn't stuck on an empty
  // filtered view.
  useEffect(() => {
    if (focusedKey && !members.has(focusedKey)) {
      setFocusedKey(null);
    }
  }, [focusedKey, members]);

  // Color-accented left border on rows that are part of a visible group.
  const getRowClassName = useCallback(
    (params) => {
      const key = getKey?.(params?.row);
      if (key == null || key === '' || !members.has(key)) return '';
      return `group-row group-row--${colorIndex.get(key)}${
        focusedKey === key ? ' group-row--focused' : ''
      }`;
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [members, colorIndex, focusedKey]
  );

  return {
    colorOf,
    focusedKey,
    setFocusedKey,
    visibleRows,
    getRowClassName,
    sx,
  };
}
