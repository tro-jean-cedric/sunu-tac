import { Box, Stack, Paper, Button, Typography } from '@mui/material';

import { Iconify } from 'src/components/iconify';

// ----------------------------------------------------------------------
// GroupFocusBanner — small neutral bar shown while a row group is
// focused, meant for AsyncDataGrid's `belowToolbar` slot. Pairs with
// useRowGrouping: render it when `focusedKey` is set and wire `onClear`
// to `() => setFocusedKey(null)`.
//
// Props:
// - label        main text (e.g. `Lot LOT-0032`). Rendered as `label (count)`
//                when `count` is provided.
// - count        number of group members visible on the current page.
// - description  optional secondary caption (e.g. "chaque demande reste
//                gérable individuellement").
// - icon         leading Iconify icon (default 'solar:layers-bold-duotone').
// - clearLabel   visible label of the clear button (default 'Annuler le
//                focus').
// - clearTooltip DEPRECATED alias of `clearLabel` (kept for back-compat;
//                `clearLabel` wins when both are set).
// - onClear      called when the user dismisses the focus.
// - sx           merged into the outer wrapper.
// ----------------------------------------------------------------------

export function GroupFocusBanner({
  label,
  count,
  description,
  icon = 'solar:layers-bold-duotone',
  clearLabel,
  clearTooltip,
  onClear,
  sx,
}) {
  const clearText = clearLabel ?? clearTooltip ?? 'Annuler le focus';

  return (
    <Box sx={[{ px: 2.5, pb: 1 }, ...(Array.isArray(sx) ? sx : [sx])]}>
      <Paper
        elevation={0}
        sx={(theme) => ({
          px: 1.5,
          py: 1,
          borderRadius: 1,
          bgcolor: theme.palette.action.hover,
          border: `1px solid ${theme.palette.divider}`,
        })}
      >
        <Stack direction="row" alignItems="center" spacing={1}>
          <Iconify icon={icon} width={18} sx={{ flexShrink: 0 }} />
          <Typography variant="body2" sx={{ fontWeight: 600 }}>
            {count != null ? `${label} (${count})` : label}
          </Typography>
          {description && (
            <Typography variant="caption" color="text.secondary" noWrap>
              {description}
            </Typography>
          )}
          <Box sx={{ flexGrow: 1 }} />
          <Button
            size="small"
            variant="text"
            color="inherit"
            startIcon={<Iconify icon="eva:close-fill" width={16} />}
            onClick={onClear}
          >
            {clearText}
          </Button>
        </Stack>
      </Paper>
    </Box>
  );
}
