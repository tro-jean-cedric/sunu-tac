import { useRef, useMemo, useState, useCallback } from 'react';

// ----------------------------------------------------------------------
// useMultiPageSelection — checkbox selection that survives server-side page
// changes. The DataGrid selection model only carries ids; this hook mirrors
// the full row payloads in a Map by id so bulk actions get complete objects
// even for rows selected on pages the user has since navigated away from.
//
// Pair with AsyncDataGrid / DataGrid:
//   const selection = useMultiPageSelection(rows);
//   <AsyncDataGrid
//     checkboxSelection
//     rowSelectionModel={selection.model}
//     onRowSelectionModelChange={selection.onChange}
//     keepNonExistentRowsSelected   // required for off-page ids to persist
//     ...
//   />
//
// Arguments:
// - rows      the current page's rows (used to pick up newly selected
//             payloads).
// - getRowId  id extractor, default `(row) => row.id`. Ids are compared as
//             strings so numeric/string id mismatches don't drop rows.
//
// Returns:
// - model         selection model (array of ids) for `rowSelectionModel`.
// - selectedRows  full row payloads, in model order, for bulk actions.
// - onChange      wire to `onRowSelectionModelChange`. Reconciles against
//                 the current page without dropping off-page ids.
// - clear()       empties the selection (e.g. after the bulk action ran, or
//                 when the surrounding scope/tab changes).
// - count         number of selected rows.
// ----------------------------------------------------------------------

export function useMultiPageSelection(rows, getRowId = (row) => row.id) {
  const [model, setModel] = useState([]);
  // id (string) -> full row payload, kept across page changes.
  const [byId, setById] = useState(() => new Map());

  // Latest page rows / id extractor, without making onChange unstable.
  const rowsRef = useRef(rows);
  rowsRef.current = rows;
  const getRowIdRef = useRef(getRowId);
  getRowIdRef.current = getRowId;

  const onChange = useCallback((newModel) => {
    const list = Array.from(newModel ?? []);
    setModel(list);
    // Persist the row payloads so bulk actions get full objects, not just ids.
    setById((prev) => {
      const ids = new Set(list.map(String));
      const next = new Map();
      // Keep previously-cached rows that are still selected (other pages).
      prev.forEach((row, id) => {
        if (ids.has(id)) next.set(id, row);
      });
      // Pick up any newly selected rows from the current page.
      (rowsRef.current ?? []).forEach((row) => {
        const id = String(getRowIdRef.current(row));
        if (ids.has(id)) next.set(id, row);
      });
      return next;
    });
  }, []);

  const clear = useCallback(() => {
    setModel([]);
    setById(new Map());
  }, []);

  const selectedRows = useMemo(
    () => model.map((id) => byId.get(String(id))).filter(Boolean),
    [model, byId]
  );

  return { model, selectedRows, onChange, clear, count: model.length };
}
