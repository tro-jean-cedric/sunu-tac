import { useState, useCallback } from 'react';

// ----------------------------------------------------------------------
// useRefreshSignal — integer counter for telling an already-open drawer or
// dialog to silently re-fetch its own data after a sibling mutation (e.g.
// so a detail drawer's Budget tab enables right after a budget is assigned
// from a sibling dialog).
//
// Usage:
//   const { signal, bump } = useRefreshSignal();
//   const handleActionDone = () => { refresh(); bump(); };
//   <DetailDrawer refreshSignal={signal} ... />
// The drawer lists `refreshSignal` in its fetch effect's deps and refetches
// (without a blocking spinner) whenever it changes.
//
// Returns { signal, bump } — `signal` is a monotonically increasing
// integer, `bump()` increments it.
// ----------------------------------------------------------------------

export function useRefreshSignal() {
  const [signal, setSignal] = useState(0);
  const bump = useCallback(() => setSignal((n) => n + 1), []);
  return { signal, bump };
}
