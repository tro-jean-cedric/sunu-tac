import { Box, Stack, Dialog, AppBar, Button, Toolbar, Typography, IconButton } from '@mui/material';

import { Iconify } from 'src/components/iconify';

// ----------------------------------------------------------------------
// FullScreenDialogShell — the chrome shared by every v2 fullscreen dialog
// (budget lines, budget histories, purchase-order form / details, …):
// a fullScreen <Dialog> with a sticky default-colored AppBar (elevation 1,
// bgcolor background.paper) whose Toolbar holds, left to right:
//   * an edge-start close IconButton (mingcute:close-line),
//   * a flex-1 title Stack — noWrap h6 `title`, optional caption `subtitle`
//     underneath, then `headerExtras` (e.g. a status <Label>),
//   * `actions` (right-aligned contextual buttons supplied by the caller),
//   * an explicit contained error-colored close Button.
// The body is a flex-1 Box on background.neutral with responsive padding
// (p: { xs: 2, md: 3 }); the dialog paper scrolls under the sticky AppBar.
//
// Props:
//   open, onClose        — dialog control. onClose receives (event, reason).
//   title                — main toolbar title (node or string, noWrap h6).
//   subtitle?            — caption line under the title (noWrap, text.secondary).
//   headerExtras?        — ReactNode rendered under the title/subtitle, e.g.
//                          a "Statut : <Label/>" row (details dialogs).
//   actions?             — ReactNode, right-aligned contextual buttons placed
//                          before the close Button.
//   closeLabel = 'Fermer' — label of the explicit close Button and aria-label
//                          of the edge close IconButton.
//   hideCloseButton      — hides the explicit close Button (icon stays).
//   busy = false         — disables both close controls and ignores
//                          backdrop / Escape while a save is in flight.
//   contentSx?           — sx merged onto the content Box.
//   children             — dialog body.

export function FullScreenDialogShell({
  open,
  onClose,
  title,
  subtitle,
  headerExtras,
  actions,
  closeLabel = 'Fermer',
  hideCloseButton = false,
  busy = false,
  contentSx,
  children,
}) {
  // Single close path: while `busy`, swallow every close attempt (edge icon,
  // explicit button, backdrop click, Escape) so an in-flight request can't be
  // interrupted mid-save.
  const handleClose = (event, reason) => {
    if (busy) return;
    onClose?.(event, reason);
  };

  return (
    <Dialog fullScreen open={open} onClose={handleClose}>
      <AppBar position="sticky" color="default" elevation={1} sx={{ bgcolor: 'background.paper' }}>
        <Toolbar sx={{ gap: 1 }}>
          <IconButton edge="start" onClick={handleClose} disabled={busy} aria-label={closeLabel}>
            <Iconify icon="mingcute:close-line" width={20} />
          </IconButton>

          <Stack sx={{ ml: 1, flex: 1, minWidth: 0 }}>
            <Typography variant="h6" noWrap sx={{ lineHeight: 1.2 }}>
              {title}
            </Typography>
            {subtitle != null && subtitle !== '' && (
              <Typography variant="caption" color="text.secondary" noWrap>
                {subtitle}
              </Typography>
            )}
            {headerExtras}
          </Stack>

          <Stack direction="row" spacing={1} alignItems="center">
            {actions}
            {!hideCloseButton && (
              <Button
                variant="contained"
                color="error"
                startIcon={<Iconify icon="mingcute:close-line" />}
                onClick={handleClose}
                disabled={busy}
              >
                {closeLabel}
              </Button>
            )}
          </Stack>
        </Toolbar>
      </AppBar>

      <Box
        sx={[
          { flex: 1, p: { xs: 2, md: 3 }, bgcolor: 'background.neutral' },
          ...(Array.isArray(contentSx) ? contentSx : [contentSx]),
        ]}
      >
        {children}
      </Box>
    </Dialog>
  );
}
