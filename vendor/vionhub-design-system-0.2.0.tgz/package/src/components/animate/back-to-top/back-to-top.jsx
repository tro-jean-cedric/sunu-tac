import { useState } from 'react';
import { useScroll, useMotionValueEvent } from 'framer-motion';

import Fab from '@mui/material/Fab';

import { Iconify } from 'src/components/iconify';

// ----------------------------------------------------------------------

/**
 * @typedef {object} BackToTopOwnProps
 * @property {number} [value] Scroll percentage past which the button appears. Default 90.
 */

/** @typedef {BackToTopOwnProps & import('@mui/material').FabProps} BackToTopProps */

/**
 * A floating "scroll to top" FAB that scales in once the page is `value`%
 * scrolled.
 *
 * Fixed to the bottom-right at `theme.zIndex.speedDial`; mount it once per
 * scrollable page. Watches the window scroll, so it does nothing inside a
 * scrolling container.
 *
 * @param {BackToTopProps} props
 * @returns {import('react').JSX.Element}
 */
export function BackToTop({ value = 90, sx, ...other }) {
  const { scrollYProgress } = useScroll();

  const [show, setShow] = useState(false);

  const backToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  useMotionValueEvent(scrollYProgress, 'change', (latest) => {
    const isEnd = Math.floor(latest * 100) > value; // unit is %
    setShow(isEnd);
  });

  return (
    <Fab
      aria-label="Back to top"
      onClick={backToTop}
      sx={{
        width: 48,
        height: 48,
        position: 'fixed',
        transform: 'scale(0)',
        right: { xs: 24, md: 32 },
        bottom: { xs: 24, md: 32 },
        zIndex: (theme) => theme.zIndex.speedDial,
        transition: (theme) => theme.transitions.create(['transform']),
        ...(show && { transform: 'scale(1)' }),
        ...sx,
      }}
      {...other}
    >
      <Iconify width={24} icon="solar:double-alt-arrow-up-bold-duotone" />
    </Fab>
  );
}
