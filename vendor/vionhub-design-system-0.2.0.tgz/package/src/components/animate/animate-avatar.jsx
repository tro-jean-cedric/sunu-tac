import { m } from 'framer-motion';

import Box from '@mui/material/Box';
import Avatar from '@mui/material/Avatar';

// ----------------------------------------------------------------------

/**
 * @typedef {object} AnimateAvatarSlotProps
 * @property {import('@mui/material').AvatarProps} [avatar] Props for the inner `Avatar` (`src`, `alt`, `sx`, ...).
 * @property {{ color?: string, border?: number, spacing?: number }} [overlay] Ring appearance: any CSS background (`color`, default a conic rainbow), ring thickness in px (`border`, default 2) and the gap between ring and avatar in px (`spacing`, default 2).
 * @property {{ transition?: import('framer-motion').Transition }} [animate] Overrides for the rotation, which defaults to a linear 8s infinite lap.
 */

/**
 * @typedef {object} AnimateAvatarOwnProps
 * @property {import('react').ReactNode} [children] Fallback content for the `Avatar` (initials).
 * @property {number} [width] Outer diameter in px, height included. Default 40.
 * @property {AnimateAvatarSlotProps} [slotProps]
 */

/** @typedef {AnimateAvatarOwnProps & import('@mui/material').BoxProps} AnimateAvatarProps */

/**
 * An avatar inside a slowly rotating gradient ring.
 *
 * ```jsx
 * <AnimateAvatar width={56} slotProps={{ avatar: { src: user.photoURL }, overlay: { color: theme.palette.primary.main } }}>
 *   {user.displayName.charAt(0)}
 * </AnimateAvatar>
 * ```
 *
 * Requires a `MotionLazy` ancestor.
 *
 * @param {AnimateAvatarProps} props
 * @returns {import('react').JSX.Element}
 */
export function AnimateAvatar({ sx, slotProps, children, width = 40, ...other }) {
  const borderWidth = slotProps?.overlay?.border ?? 2;

  const spacing = slotProps?.overlay?.spacing ?? 2;

  return (
    <Box
      sx={{
        width,
        height: width,
        flexShrink: 0,
        borderRadius: '50%',
        position: 'relative',
        alignItems: 'center',
        display: 'inline-flex',
        justifyContent: 'center',
        ...sx,
      }}
      {...other}
    >
      <Avatar
        alt={slotProps?.avatar?.alt ?? 'My avtar'}
        src={slotProps?.avatar?.src}
        sx={{
          zIndex: 1,
          width: `calc(100% - ${borderWidth * 2 + spacing * 2}px)`,
          height: `calc(100% - ${borderWidth * 2 + spacing * 2}px)`,
          ...slotProps?.avatar?.sx,
        }}
        {...slotProps?.avatar}
      >
        {children}
      </Avatar>

      <Box
        component={m.span}
        animate={{ rotate: 360 }}
        transition={{
          duration: 8,
          ease: 'linear',
          repeat: Infinity,
          ...slotProps?.animate?.transition,
        }}
        sx={{
          top: 0,
          left: 0,
          width: 1,
          height: 1,
          position: 'absolute',
          borderRadius: 'inherit',
          background: slotProps?.overlay?.color ?? 'conic-gradient(cyan, magenta, yellow, cyan)',
          mask: 'linear-gradient(#FFF 0 0) content-box, linear-gradient(#FFF 0 0)',
          WebkitMask: 'linear-gradient(#FFF 0 0) content-box, linear-gradient(#FFF 0 0)',
          maskComposite: 'exclude',
          WebkitMaskComposite: 'xor',
          p: `${borderWidth}px`,
        }}
      />
    </Box>
  );
}
