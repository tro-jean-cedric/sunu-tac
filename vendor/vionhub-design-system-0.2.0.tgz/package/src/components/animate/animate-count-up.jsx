import { useRef, useEffect } from 'react';
import { m, animate, useInView, useTransform, useMotionValue } from 'framer-motion';

import Typography from '@mui/material/Typography';

// ----------------------------------------------------------------------

/**
 * @typedef {object} AnimateCountUpOwnProps
 * @property {number} to Final value.
 * @property {number} [from] Starting value. Default 0.
 * @property {string} [unit] Suffix rendered after the number, e.g. `'%'` or `' XOF'`.
 * @property {number} [toFixed] Decimal places. Default 0.
 * @property {number} [duration] Count duration in SECONDS. Default 2.
 * @property {boolean} [once] Count only the first time it scrolls into view. Default `true`.
 * @property {number} [amount] Fraction of the element that must be visible to start. Default 0.5.
 */

/** @typedef {AnimateCountUpOwnProps & Omit<import('@mui/material').TypographyProps, 'children'>} AnimateCountUpProps */

/**
 * A number that counts up from `from` to `to` when it scrolls into view.
 *
 * ```jsx
 * <AnimateCountUp to={1280} unit=" demandes" variant="h3" />
 * ```
 *
 * Renders as a `Typography` (override the tag with `component`). Requires a
 * `MotionLazy` ancestor — without one the value renders as `from` and never
 * moves.
 *
 * @param {AnimateCountUpProps} props
 * @returns {import('react').JSX.Element}
 */
export function AnimateCountUp({
  to,
  sx,
  from = 0,
  unit = '',
  toFixed = 0,
  duration = 2,
  once = true,
  amount = 0.5,
  component = 'p',
  ...other
}) {
  const ref = useRef(null);

  const inView = useInView(ref, { once, amount });

  const count = useMotionValue(from);

  const rounded = useTransform(count, (latest) => latest.toFixed(toFixed));

  useEffect(() => {
    if (inView) {
      animate(count, to, { duration });
    }
  }, [count, duration, inView, to]);

  return (
    <Typography
      component={component}
      sx={{
        display: 'inline-flex',
        p: 0,
        m: 0,
        ...sx,
      }}
      {...other}
    >
      <m.span ref={ref}>{rounded}</m.span>
      {unit}
    </Typography>
  );
}
