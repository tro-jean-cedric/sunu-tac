// ----------------------------------------------------------------------

/**
 * Options for the `varBg*` background animations.
 *
 * @typedef {object} VarBackgroundProps
 * @property {string[]} [colors] Colour stops. `varBgColor` cycles through them; `varBgPan` builds a gradient from them.
 * @property {number} [duration] Duration in SECONDS. Default 5.
 * @property {import('framer-motion').Easing | import('framer-motion').Easing[]} [ease] Easing. Default `'linear'` (`'easeOut'` for `varBgKenburns`).
 */

/**
 * Cycles an element's `background` through `colors`.
 *
 * @param {VarBackgroundProps} [props]
 * @returns {import('framer-motion').Variants}
 */
export const varBgColor = (props) => {
  const colors = props?.colors || ['#19dcea', '#b22cff'];
  const duration = props?.duration || 5;
  const ease = props?.ease || 'linear';

  return { animate: { background: colors, transition: { duration, ease } } };
};

// ----------------------------------------------------------------------

/**
 * Ken Burns effect: a slow scale-and-drift, anchored to the named edge. Pick
 * the direction the subject of the image sits toward.
 *
 * ```jsx
 * <m.img variants={varBgKenburns().top} animate="animate" />
 * ```
 *
 * @param {VarBackgroundProps} [props]
 * @returns {Record<'top' | 'bottom' | 'left' | 'right', import('framer-motion').Variants>}
 */
export const varBgKenburns = (props) => {
  const duration = props?.duration || 5;
  const ease = props?.ease || 'easeOut';

  return {
    top: {
      animate: {
        scale: [1, 1.25],
        y: [0, -15],
        transformOrigin: ['50% 16%', '50% top'],
        transition: { duration, ease },
      },
    },
    bottom: {
      animate: {
        scale: [1, 1.25],
        y: [0, 15],
        transformOrigin: ['50% 84%', '50% bottom'],
        transition: { duration, ease },
      },
    },
    left: {
      animate: {
        scale: [1, 1.25],
        x: [0, 20],
        y: [0, 15],
        transformOrigin: ['16% 50%', '0% left'],
        transition: { duration, ease },
      },
    },
    right: {
      animate: {
        scale: [1, 1.25],
        x: [0, -20],
        y: [0, -15],
        transformOrigin: ['84% 50%', '0% right'],
        transition: { duration, ease },
      },
    },
  };
};

// ----------------------------------------------------------------------

/**
 * Pans an oversized multi-colour gradient across the element, in the named
 * direction.
 *
 * @param {VarBackgroundProps} [props]
 * @returns {Record<'top' | 'right' | 'bottom' | 'left', import('framer-motion').Variants>}
 */
export const varBgPan = (props) => {
  const colors = props?.colors || ['#ee7752', '#e73c7e', '#23a6d5', '#23d5ab'];
  const duration = props?.duration || 5;
  const ease = props?.ease || 'linear';

  const gradient = (deg) => `linear-gradient(${deg}deg, ${colors})`;

  return {
    top: {
      animate: {
        backgroundImage: [gradient(0), gradient(0)],
        backgroundPosition: ['center 99%', 'center 1%'],
        backgroundSize: ['100% 600%', '100% 600%'],
        transition: { duration, ease },
      },
    },
    right: {
      animate: {
        backgroundPosition: ['1% center', '99% center'],
        backgroundImage: [gradient(270), gradient(270)],
        backgroundSize: ['600% 100%', '600% 100%'],
        transition: { duration, ease },
      },
    },
    bottom: {
      animate: {
        backgroundImage: [gradient(0), gradient(0)],
        backgroundPosition: ['center 1%', 'center 99%'],
        backgroundSize: ['100% 600%', '100% 600%'],
        transition: { duration, ease },
      },
    },
    left: {
      animate: {
        backgroundPosition: ['99% center', '1% center'],
        backgroundImage: [gradient(270), gradient(270)],
        backgroundSize: ['600% 100%', '600% 100%'],
        transition: { duration, ease },
      },
    },
  };
};
