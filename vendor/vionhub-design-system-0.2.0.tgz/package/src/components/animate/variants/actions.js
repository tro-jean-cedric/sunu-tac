// ----------------------------------------------------------------------

/**
 * `hover` / `tap` scale variants for a pressable element.
 *
 * ```jsx
 * <m.button variants={varHover()} whileHover="hover" whileTap="tap" />
 * ```
 *
 * @param {number} [hover] Scale while hovered. Default 1.09.
 * @param {number} [tap] Scale while pressed. Default 0.97.
 * @returns {import('framer-motion').Variants}
 */
export const varHover = (hover = 1.09, tap = 0.97) => ({
  hover: { scale: hover },
  tap: { scale: tap },
});
