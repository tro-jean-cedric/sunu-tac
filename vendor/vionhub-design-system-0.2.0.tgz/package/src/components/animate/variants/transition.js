// ----------------------------------------------------------------------
// Motion timing: the library defaults (`varTran*`) and the design tokens
// (`motion*`).
//
// TWO TIMING SYSTEMS LIVE HERE ON PURPOSE — read this before picking one.
//
// 1. THE LIBRARY DEFAULTS — `varTranEnter` / `varTranExit` / `varTranHover`.
//    Inherited from the Minimals template: enter 0.64s, exit 0.48s, hover
//    0.32s, all on the ease `[0.43, 0.13, 0.23, 0.96]` (a slow, slightly
//    overshooting curve). Every `var*` factory in this folder uses them, and
//    every screen already built on top of them is tuned to that feel. They are
//    UNCHANGED and will stay unchanged.
//
// 2. THE TOKENS — `motionDurations` / `motionEasings` / `motionStagger`.
//    A faster, flatter, Material-style set (enter 280ms on
//    `cubic-bezier(0, 0, 0.2, 1)`) seeded from the reference consumer app's
//    hand-rolled `src/motion.tsx`, so an app can reproduce those animations
//    with library tokens instead of re-deriving them. They exist in BOTH plain
//    CSS form (ms + `cubic-bezier(...)` string) and framer form (seconds +
//    `[x1, y1, x2, y2]` array), because an app animates with both.
//
// THEY ARE NOT DROP-IN REPLACEMENTS FOR EACH OTHER. The defaults are 2-3x
// slower and use a different curve:
//
//   | phase | library default          | token                  |
//   | ----- | ------------------------ | ---------------------- |
//   | enter | 640ms, [.43,.13,.23,.96] | 280ms, [0, 0, .2, 1]   |
//   | exit  | 480ms, [.43,.13,.23,.96] | 200ms, [.4, 0, 1, 1]   |
//   | hover | 320ms, [.43,.13,.23,.96] | 180ms, [.4, 0, .2, 1]  |
//
// Swapping one for the other IS a visual change. To move a `var*` animation
// onto the tokens, pass `motionTokenVariantProps` to the factory explicitly:
//
//   <m.div variants={varFade(motionTokenVariantProps).inUp} />
//
// REDUCED MOTION. `varTranEnter` / `varTranExit` / `varTranHover` and
// `motionTransition` all collapse their duration to 0 when the OS asks for
// reduced motion, so the element jumps straight to its end state instead of
// travelling. That check is a one-shot `matchMedia` read at the moment the
// transition object is built (see `prefersReducedMotion`); for a fully reactive
// guard that also strips transforms, render inside `<MotionLazy>`, which wraps
// its children in framer's `<MotionConfig reducedMotion="user">`.
// ----------------------------------------------------------------------

/**
 * True when the OS/browser asks for reduced motion
 * (`@media (prefers-reduced-motion: reduce)`).
 *
 * Safe to call during SSR or in a non-DOM environment — it returns `false`
 * when `window.matchMedia` is unavailable. This is a plain read, NOT a hook:
 * it does not re-render on change. Use it where you build a transition object;
 * use framer's `useReducedMotion()` (re-exported from `@vionhub/design-system`)
 * where you need a reactive value inside a component.
 *
 * @returns {boolean}
 */
export function prefersReducedMotion() {
  if (typeof window === 'undefined' || typeof window.matchMedia !== 'function') {
    return false;
  }
  return window.matchMedia('(prefers-reduced-motion: reduce)').matches;
}

// ----------------------------------------------------------------------
// 1. Library defaults (timings unchanged).
// ----------------------------------------------------------------------

/**
 * Options accepted by every `var*` variant factory in this folder. All fields
 * are optional; anything omitted falls back to the library default timing
 * described at the top of this file.
 *
 * @typedef {object} VarTransitionProps
 * @property {number} [distance] Travel distance in px, for the factories that move (`varFade`, `varSlide`, `varZoom`).
 * @property {number} [durationIn] Enter duration, in SECONDS (framer's unit). Default 0.64.
 * @property {number} [durationOut] Exit duration, in seconds. Default 0.48.
 * @property {number} [duration] Hover/tap duration, in seconds. Default 0.32.
 * @property {import('framer-motion').Easing | import('framer-motion').Easing[]} [easeIn] Enter easing.
 * @property {import('framer-motion').Easing | import('framer-motion').Easing[]} [easeOut] Exit easing.
 * @property {import('framer-motion').Easing | import('framer-motion').Easing[]} [ease] Hover/tap easing.
 */

/**
 * Hover/tap transition — the library default is 0.32s on
 * `[0.43, 0.13, 0.23, 0.96]`. Collapses to 0s under reduced motion.
 *
 * @param {VarTransitionProps} [props]
 * @returns {import('framer-motion').Transition}
 */
export const varTranHover = (props) => {
  const duration = props?.duration || 0.32;
  const ease = props?.ease || [0.43, 0.13, 0.23, 0.96];

  return { duration: prefersReducedMotion() ? 0 : duration, ease };
};

/**
 * Enter transition — the library default is 0.64s on
 * `[0.43, 0.13, 0.23, 0.96]`. Collapses to 0s under reduced motion.
 *
 * @param {VarTransitionProps} [props]
 * @returns {import('framer-motion').Transition}
 */
export const varTranEnter = (props) => {
  const duration = props?.durationIn || 0.64;
  const ease = props?.easeIn || [0.43, 0.13, 0.23, 0.96];

  return { duration: prefersReducedMotion() ? 0 : duration, ease };
};

/**
 * Exit transition — the library default is 0.48s on
 * `[0.43, 0.13, 0.23, 0.96]`. Collapses to 0s under reduced motion.
 *
 * @param {VarTransitionProps} [props]
 * @returns {import('framer-motion').Transition}
 */
export const varTranExit = (props) => {
  const duration = props?.durationOut || 0.48;
  const ease = props?.easeOut || [0.43, 0.13, 0.23, 0.96];

  return { duration: prefersReducedMotion() ? 0 : duration, ease };
};

// ----------------------------------------------------------------------
// 2. Tokens.
// ----------------------------------------------------------------------

/**
 * Duration tokens, in MILLISECONDS (the CSS unit). Divide by 1000 for framer,
 * or use `motionDurationsSec`.
 *
 * @typedef {object} MotionDurationTokens
 * @property {number} micro 180 — hover, colour/shadow/transform state changes, data swaps.
 * @property {number} enter 280 — an element or card entering.
 * @property {number} exit 200 — an element leaving. Always shorter than `enter`.
 * @property {number} collapse 240 — height changes (MUI `Collapse`, accordions).
 * @property {number} progress 600 — progress/ratio bars filling from 0.
 */

/**
 * Duration tokens in milliseconds.
 *
 * Use for CSS (`transition`, `animation`, `animationDelay`) and for MUI
 * `timeout` / `theme.transitions.create({ duration })`, which are both ms.
 *
 * NOT the library's own `var*` defaults — see the table at the top of this
 * file. `motionDurations.enter` (280ms) is less than half of `varTranEnter`'s
 * 640ms.
 *
 * @type {MotionDurationTokens}
 */
export const motionDurations = {
  micro: 180,
  enter: 280,
  exit: 200,
  collapse: 240,
  progress: 600,
};

/**
 * The same duration tokens in SECONDS, framer-motion's unit. Pass straight
 * into a framer `transition`: `{ duration: motionDurationsSec.enter }`.
 *
 * @type {MotionDurationTokens}
 */
export const motionDurationsSec = {
  micro: motionDurations.micro / 1000,
  enter: motionDurations.enter / 1000,
  exit: motionDurations.exit / 1000,
  collapse: motionDurations.collapse / 1000,
  progress: motionDurations.progress / 1000,
};

/**
 * One easing curve in both the forms an app needs: a CSS `cubic-bezier(...)`
 * string and framer-motion's four-number control-point array.
 *
 * @typedef {object} MotionEasingToken
 * @property {string} css A `cubic-bezier(x1, y1, x2, y2)` string, for CSS `transition`/`animation`.
 * @property {[number, number, number, number]} array The same curve in framer's `ease` array form.
 */

/**
 * @typedef {object} MotionEasingTokens
 * @property {MotionEasingToken} standard Accelerate then decelerate. State changes that start and end on screen (hover, colour, size).
 * @property {MotionEasingToken} out Decelerate only. Things ENTERING — they arrive fast and settle.
 * @property {MotionEasingToken} in Accelerate only. Things LEAVING — they start slow and shoot off.
 */

/**
 * Easing tokens. The Material standard/decelerate/accelerate trio — flatter
 * and less bouncy than the library's own `[0.43, 0.13, 0.23, 0.96]` default.
 *
 * @type {MotionEasingTokens}
 */
export const motionEasings = {
  standard: { css: 'cubic-bezier(0.4, 0, 0.2, 1)', array: [0.4, 0, 0.2, 1] },
  out: { css: 'cubic-bezier(0, 0, 0.2, 1)', array: [0, 0, 0.2, 1] },
  in: { css: 'cubic-bezier(0.4, 0, 1, 1)', array: [0.4, 0, 1, 1] },
};

/**
 * @typedef {object} MotionStaggerTokens
 * @property {number} step 40 — ms between consecutive items in a list entrance.
 * @property {number} max 12 — items past this index share the last delay, capping the wait at `step * max` (480ms). Without a cap the 200th row of a table would start animating 8 seconds in.
 */

/**
 * List-entrance stagger tokens.
 *
 * @type {MotionStaggerTokens}
 */
export const motionStagger = {
  step: 40,
  max: 12,
};

/**
 * Entrance delay for item `index` of a staggered list, in milliseconds,
 * clamped at `motionStagger.max` items.
 *
 * ```js
 * sx={{ animationDelay: `${motionStaggerDelay(rowIndex)}ms` }}
 * ```
 *
 * @param {number} [index] Zero-based position in the list.
 * @returns {number} Delay in ms. Always `0` under reduced motion.
 */
export function motionStaggerDelay(index = 0) {
  if (prefersReducedMotion()) return 0;
  return Math.min(Math.max(index, 0), motionStagger.max) * motionStagger.step;
}

/**
 * Build a framer-motion `Transition` from the tokens.
 *
 * ```js
 * <m.div animate={{ opacity: 1 }} transition={motionTransition('enter', 'out')} />
 * ```
 *
 * Collapses to `duration: 0` under reduced motion.
 *
 * @param {keyof MotionDurationTokens} [duration] Duration token name. Default `'enter'`.
 * @param {keyof MotionEasingTokens} [easing] Easing token name. Default `'out'`.
 * @returns {import('framer-motion').Transition}
 */
export function motionTransition(duration = 'enter', easing = 'out') {
  return {
    duration: prefersReducedMotion() ? 0 : motionDurationsSec[duration],
    ease: motionEasings[easing].array,
  };
}

/**
 * Build a CSS `transition` shorthand from the tokens, for `sx`/`style` on
 * elements that are not framer components.
 *
 * ```js
 * sx={{ transition: motionCssTransition(['transform', 'box-shadow'], 'micro', 'standard') }}
 * ```
 *
 * Returns `'none'` under reduced motion.
 *
 * @param {string[]} [properties] CSS properties to transition. Default `['all']`.
 * @param {keyof MotionDurationTokens} [duration] Duration token name. Default `'micro'`.
 * @param {keyof MotionEasingTokens} [easing] Easing token name. Default `'standard'`.
 * @returns {string}
 */
export function motionCssTransition(properties = ['all'], duration = 'micro', easing = 'standard') {
  if (prefersReducedMotion()) return 'none';
  return properties
    .map((property) => `${property} ${motionDurations[duration]}ms ${motionEasings[easing].css}`)
    .join(', ');
}

/**
 * Ready-made options that put ANY `var*` factory on the token timing instead
 * of the library defaults. Opt-in — nothing applies this for you.
 *
 * ```js
 * // library default feel: 640ms, 120px of travel
 * <m.div variants={varFade().inUp} />
 * // token feel: 280ms, 8px of travel — matches the consumer app's `revealSx`
 * <m.div variants={varFade(motionTokenVariantProps).inUp} />
 * ```
 *
 * `distance: 8` is deliberate: the tokens describe a subtle 8px rise, whereas
 * `varFade`'s own default travels 120px. At 280ms a 120px slide reads as a
 * lurch.
 *
 * @type {VarTransitionProps}
 */
export const motionTokenVariantProps = {
  distance: 8,
  duration: motionDurationsSec.micro,
  durationIn: motionDurationsSec.enter,
  durationOut: motionDurationsSec.exit,
  ease: motionEasings.standard.array,
  easeIn: motionEasings.out.array,
  easeOut: motionEasings.in.array,
};
