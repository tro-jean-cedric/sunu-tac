// ----------------------------------------------------------------------

/**
 * The 2-second transition `varPath` draws on. Exported under a very generic
 * name for backwards compatibility; prefer `motionTransition()` for new code.
 *
 * @type {import('framer-motion').Transition}
 */
export const TRANSITION = { duration: 2, ease: [0.43, 0.13, 0.23, 0.96] };

/**
 * SVG line-drawing variants: traces an outline then fills it. Apply to an
 * `m.path` whose `d` describes a closed shape.
 *
 * ```jsx
 * <m.path d={d} variants={varPath} animate="animate" />
 * ```
 *
 * @type {import('framer-motion').Variants}
 */
export const varPath = {
  animate: { fillOpacity: [0, 0, 1], pathLength: [1, 0.4, 0], transition: TRANSITION },
};
