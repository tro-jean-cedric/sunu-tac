/**
 * Stagger options for `varContainer`. All values are in SECONDS.
 *
 * @typedef {object} VarContainerProps
 * @property {number} [staggerIn] Delay between children entering. Default 0.05.
 * @property {number} [delayIn] Delay before the first child enters. Default 0.05.
 * @property {number} [staggerOut] Delay between children leaving. Default 0.05.
 */

/**
 * Parent variants that stagger the children's `initial`/`animate`/`exit`
 * states. Put it on the wrapper, put a `var*` variant on each child:
 *
 * ```jsx
 * <m.div variants={varContainer()} initial="initial" animate="animate">
 *   {items.map((item) => <m.div key={item.id} variants={varFade().inUp} />)}
 * </m.div>
 * ```
 *
 * `MotionContainer` and `MotionViewport` apply this for you.
 *
 * NOTE: `delayIn` and `staggerOut` used to read `props.staggerIn`, so passing
 * them had no effect. They are honoured now and the defaults are unchanged, so
 * no screen *inside this package* moves — nothing here passes these options.
 * A CONSUMER passing `staggerIn` does move: `varContainer({ staggerIn: 0.2 })`
 * used to yield `delayChildren: 0.2` and an exit `staggerChildren: 0.2`, and
 * now yields the default `0.05` for both. See CHANGELOG breaking change 12.
 *
 * @param {VarContainerProps} [props]
 * @returns {import('framer-motion').Variants}
 */
export const varContainer = (props) => {
  const staggerIn = props?.staggerIn || 0.05;
  const delayIn = props?.delayIn || 0.05;
  const staggerOut = props?.staggerOut || 0.05;

  return {
    animate: { transition: { staggerChildren: staggerIn, delayChildren: delayIn } },
    exit: { transition: { staggerChildren: staggerOut, staggerDirection: -1 } },
  };
};
