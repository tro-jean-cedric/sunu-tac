import { useRef, useMemo } from 'react';
import { useScroll } from 'framer-motion';

// ----------------------------------------------------------------------

/**
 * @typedef {object} UseScrollProgressReturn
 * @property {import('react').RefObject<HTMLElement>} elementRef Attach to the scrolling element. Only used when `target` is `'container'`.
 * @property {import('framer-motion').MotionValue<number>} scrollXProgress Horizontal scroll position, 0 to 1.
 * @property {import('framer-motion').MotionValue<number>} scrollYProgress Vertical scroll position, 0 to 1.
 */

/**
 * Tracks scroll position as a 0-1 `MotionValue`, for the whole document or for
 * one container.
 *
 * ```jsx
 * const { scrollYProgress } = useScrollProgress();
 * return <ScrollProgress variant="linear" progress={scrollYProgress} />;
 * ```
 *
 * These are `MotionValue`s, not React state — they update outside the render
 * cycle, so reading `.get()` in a render will not re-render on change. Feed
 * them to a motion component's `style`, or to `ScrollProgress`.
 *
 * @param {'document' | 'container'} [target] Default `'document'`. With `'container'`, put the returned `elementRef` on the scrolling element.
 * @returns {UseScrollProgressReturn}
 */
export function useScrollProgress(target = 'document') {
  const elementRef = useRef(null);

  const options = { container: elementRef };

  const { scrollYProgress, scrollXProgress } = useScroll(
    target === 'container' ? options : undefined
  );

  const memoizedValue = useMemo(
    () => ({ elementRef, scrollXProgress, scrollYProgress }),
    [elementRef, scrollXProgress, scrollYProgress]
  );

  return memoizedValue;
}
