import { useRef, useEffect } from 'react';
import { m, useInView, useAnimation } from 'framer-motion';

import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';

import { varFade, varContainer } from './variants';

// ----------------------------------------------------------------------

/**
 * Class names `AnimateText` puts on its parts, so you can target them from
 * `sx` (`[`& .${animateTextClasses.char}`]: { ... }`).
 *
 * @type {{ root: string, lines: string, line: string, word: string, char: string, space: string, srOnly: string, dataIndex: string }}
 */
export const animateTextClasses = {
  root: 'animate-text-root',
  lines: 'animate-text-lines',
  line: 'animate-text-line',
  word: 'animate-text-word',
  char: 'animate-text-char',
  space: 'animate-text-space',
  srOnly: 'sr-only',
  dataIndex: '[data-columns="3"]',
};

/**
 * @typedef {object} AnimateTextOwnProps
 * @property {string | string[]} text The text. An array renders one block-level
 *   line per entry. Required, but `''`, `[]` and holes in the array are
 *   tolerated (they render as nothing) — text arriving from a fetch is the
 *   common case, and it should not throw on the first render.
 * @property {import('framer-motion').Variants} [variants] Per-character variants. Default `varFade().in`.
 * @property {boolean} [once] Play only the first time it scrolls into view. Default `true`.
 * @property {number} [amount] Fraction visible before it plays. Default 1/3.
 * @property {number} [repeatDelay] Milliseconds to wait before replaying from the start; `0` plays once. Default 500.
 */

/** @typedef {AnimateTextOwnProps & Omit<import('@mui/material').TypographyProps, 'children'>} AnimateTextProps */

/**
 * Reveals text one character at a time, staggered.
 *
 * The visible characters are `aria-hidden`; the full string is also rendered
 * in a visually-hidden span so screen readers announce it once, normally.
 *
 * Cost scales with character count — one animated element per character. Use
 * it on headings, never on a paragraph. Requires a `MotionLazy` ancestor.
 *
 * @param {AnimateTextProps} props
 * @returns {import('react').JSX.Element}
 */
export function AnimateText({
  sx,
  text,
  variants,
  once = true,
  amount = 1 / 3,
  component = 'p',
  repeatDelay = 500, // 1000 = 1s
  ...other
}) {
  const ref = useRef(null);

  const controls = useAnimation();

  // Normalise to an array of strings. `text` is typed required, but it very
  // often arrives from a fetch, so a missing / null entry must render as an
  // empty line rather than blowing up on `line.split(' ')`.
  const textArray = (Array.isArray(text) ? text : [text]).map((line) => line ?? '');

  const isInView = useInView(ref, { once, amount });

  useEffect(() => {
    let timeout;

    const show = () => {
      if (repeatDelay) {
        timeout = setTimeout(async () => {
          await controls.start('initial');
          controls.start('animate');
        }, repeatDelay);
      } else {
        controls.start('animate');
      }
    };

    if (isInView) {
      show();
    } else {
      controls.start('initial');
    }

    return () => clearTimeout(timeout);
  }, [controls, isInView, repeatDelay]);

  return (
    <Typography
      component={component}
      className={animateTextClasses.root}
      sx={{
        p: 0,
        m: 0,
        /**
         * Utilities for improving accessibility with screen readers.
         * https://v1.tailwindcss.com/docs/screen-readers
         */
        [`& .${animateTextClasses.srOnly}`]: {
          p: 0,
          width: '1px',
          height: '1px',
          margin: '-1px',
          borderWidth: 0,
          overflow: 'hidden',
          position: 'absolute',
          whiteSpace: 'nowrap',
          clip: 'rect(0, 0, 0, 0)',
        },
        ...sx,
      }}
      {...other}
    >
      <span className={animateTextClasses.srOnly}>{textArray.join(' ')}</span>

      <Box
        component={m.span}
        ref={ref}
        initial="initial"
        animate={controls}
        exit="exit"
        variants={varContainer()}
        aria-hidden
        className={animateTextClasses.lines}
      >
        {textArray.map((line, lineIndex) => (
          <Box
            component="span"
            key={`${line}-${lineIndex}`}
            data-index={lineIndex}
            className={animateTextClasses.line}
            sx={{ display: 'block' }}
          >
            {line.split(' ').map((word, wordIndex) => {
              const lastWordInline = line.split(' ')[line.split(' ').length - 1];

              return (
                <Box
                  component="span"
                  key={`${word}-${wordIndex}`}
                  data-index={wordIndex}
                  className={animateTextClasses.word}
                  sx={{ display: 'inline-block' }}
                >
                  {word.split('').map((char, charIndex) => (
                    <Box
                      component={m.span}
                      key={`${char}-${charIndex}`}
                      variants={variants ?? varFade().in}
                      data-index={charIndex}
                      className={animateTextClasses.char}
                      sx={{ display: 'inline-block' }}
                    >
                      {char}
                    </Box>
                  ))}

                  {lastWordInline !== word && (
                    <Box
                      component="span"
                      className={animateTextClasses.space}
                      sx={{ display: 'inline-block' }}
                    >
                      &nbsp;
                    </Box>
                  )}
                </Box>
              );
            })}
          </Box>
        ))}
      </Box>
    </Typography>
  );
}
