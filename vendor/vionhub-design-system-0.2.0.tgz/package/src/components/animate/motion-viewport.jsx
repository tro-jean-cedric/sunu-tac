import { m } from 'framer-motion';
import { forwardRef } from 'react';

import Box from '@mui/material/Box';

import { useResponsive } from 'src/hooks/use-responsive';

import { varContainer } from './variants';

/**
 * @typedef {object} MotionViewportOwnProps
 * @property {import('react').ReactNode} [children]
 * @property {boolean} [disableAnimate] Default `true` — SKIP the animation on screens below the `sm` breakpoint. Pass `false` to animate on phones too.
 */

/** @typedef {MotionViewportOwnProps & import('@mui/material').BoxProps} MotionViewportProps */

/**
 * A `Box` that plays its children's variants when it scrolls into view, once.
 *
 * Applies `varContainer()` to itself, so direct children carrying a `var*`
 * variant animate in sequence:
 *
 * ```jsx
 * <MotionViewport>
 *   {rows.map((row) => (
 *     <m.div key={row.id} variants={varFade().inUp}>{row.label}</m.div>
 *   ))}
 * </MotionViewport>
 * ```
 *
 * Triggers at 30% visibility and never replays. Requires a `MotionLazy`
 * ancestor — without one it renders but never animates.
 *
 * @type {import('react').ForwardRefExoticComponent<MotionViewportProps & import('react').RefAttributes<HTMLDivElement>>}
 */
export const MotionViewport = forwardRef(({ children, disableAnimate = true, ...other }, ref) => {
  const smDown = useResponsive('down', 'sm');

  const disabled = smDown && disableAnimate;

  const props = disabled
    ? {}
    : {
        component: m.div,
        initial: 'initial',
        whileInView: 'animate',
        variants: varContainer(),
        viewport: { once: true, amount: 0.3 },
      };

  return (
    <Box ref={ref} {...props} {...other}>
      {children}
    </Box>
  );
});
