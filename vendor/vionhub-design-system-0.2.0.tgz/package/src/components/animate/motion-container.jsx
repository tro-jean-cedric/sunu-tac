import { m } from 'framer-motion';
import { forwardRef } from 'react';

import Box from '@mui/material/Box';

import { varContainer } from './variants';

/**
 * @typedef {object} MotionContainerOwnProps
 * @property {import('react').ReactNode} [children]
 * @property {boolean} [action] Switch to controlled mode: the container plays `animate` or `exit` according to the `animate` prop instead of animating in on mount.
 * @property {boolean} [animate] Controlled state, only read when `action` is `true`. `true` -> play `animate`, `false` -> play `exit`.
 */

/** @typedef {MotionContainerOwnProps & Omit<import('@mui/material').BoxProps, 'animate'>} MotionContainerProps */

/**
 * A `Box` that staggers its children's variants (`varContainer()`).
 *
 * Two modes:
 * - uncontrolled (default) — animates in on mount, and animates out via
 *   `AnimatePresence` when unmounted.
 * - controlled (`action`) — no mount animation; you drive it with `animate`.
 *   Use this for menus and popovers whose open state you already hold.
 *
 * ```jsx
 * <MotionContainer action animate={open}>
 *   <m.div variants={varFade().inUp}>...</m.div>
 * </MotionContainer>
 * ```
 *
 * Requires a `MotionLazy` ancestor.
 *
 * @type {import('react').ForwardRefExoticComponent<MotionContainerProps & import('react').RefAttributes<HTMLDivElement>>}
 */
export const MotionContainer = forwardRef(
  ({ animate, action = false, children, ...other }, ref) => {
    const commonProps = {
      ref,
      component: m.div,
      variants: varContainer(),
      initial: action ? false : 'initial',
      animate: action ? (animate ? 'animate' : 'exit') : 'animate',
      exit: action ? undefined : 'exit',
      ...other,
    };

    return <Box {...commonProps}>{children}</Box>;
  }
);
