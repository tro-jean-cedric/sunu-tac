import { domMax, LazyMotion, MotionConfig } from 'framer-motion';

// ----------------------------------------------------------------------

/**
 * @typedef {object} MotionLazyProps
 * @property {import('react').ReactNode} [children]
 * @property {boolean} [strict] Default `true`. Read the note below before turning it off.
 * @property {import('framer-motion').FeatureBundle | import('framer-motion').LazyFeatureBundle} [features] Feature bundle to load. Default `domMax` (everything: gestures, layout projection, drag).
 * @property {'never' | 'always' | 'user'} [reducedMotion] Passed to framer's `MotionConfig`. Default `'user'` — honour the OS setting.
 */

/**
 * Loads framer-motion's feature bundle once, for the whole subtree, and turns
 * on the reduced-motion guard.
 *
 * MOUNT THIS ONCE, HIGH UP — above the router, next to `ThemeProvider`:
 *
 * ```jsx
 * <ThemeProvider>
 *   <MotionLazy>
 *     <App />
 *   </MotionLazy>
 * </ThemeProvider>
 * ```
 *
 * WHY IT IS NOT OPTIONAL — AND WHY FORGETTING IT IS WORSE THAN "NO ANIMATION".
 * Every animated component in this library (and every `var*` variant) is built
 * on framer's `m` component — the ~5kb build with NO features compiled in. `m`
 * gets its features from the nearest `LazyMotion` ancestor. With no ancestor
 * it renders, but nothing ever drives it, so it is STUCK ON ITS `initial`
 * STATE — and almost every entrance variant starts at `opacity: 0`. The
 * content is not un-animated, it is INVISIBLE, permanently. Measured in the
 * demo app with the provider removed: `m.div` sat at
 * `opacity: 0; transform: translateY(8px)`, `AnimateCountUp` stayed on its
 * `from` value, `MotionViewport` children never appeared — with zero errors
 * and zero console warnings. If a screen renders blank where it should show
 * animated content, a missing `MotionLazy` is the first thing to check.
 *
 * `strict` (on by default) THROWS in development if a full `motion.*`
 * component is rendered anywhere inside this subtree, because that defeats the
 * whole point — `motion.div` statically pulls in the entire feature bundle
 * that `LazyMotion` exists to load lazily. The message reads: *"You have
 * rendered a `motion` component within a `LazyMotion` component. This will
 * break tree shaking. Import and render a `m` component instead."* The fix is
 * to import `m` instead of `motion` (both are re-exported from
 * `@vionhub/design-system`); `strict={false}` downgrades it to a console warning
 * if you must. Production builds never throw.
 *
 * `reducedMotion="user"` makes framer skip transform and layout animations for
 * users with `prefers-reduced-motion: reduce`, while keeping opacity and colour
 * changes. It is reactive — unlike the one-shot `prefersReducedMotion()` read
 * inside `varTranEnter`/`varTranExit`, which is the fallback for animations
 * built outside this provider.
 *
 * @param {MotionLazyProps} props
 * @returns {import('react').JSX.Element}
 */
export function MotionLazy({ children, strict = true, features = domMax, reducedMotion = 'user' }) {
  return (
    <LazyMotion strict={strict} features={features}>
      <MotionConfig reducedMotion={reducedMotion}>{children}</MotionConfig>
    </LazyMotion>
  );
}
