import {
  Box,
  Stack,
  Drawer,
  Tooltip,
  Typography,
  IconButton,
  CircularProgress,
} from '@mui/material';

import { Iconify } from 'src/components/iconify';
import { Scrollbar } from 'src/components/scrollbar';
import { EmptyContent } from 'src/components/empty-content';
import { DetailHeaderActions } from 'src/components/action-buttons';

// ----------------------------------------------------------------------
// Right-anchored record viewer shell — the drawer skeleton shared by the
// app's product and request detail drawers: responsive right Drawer, sticky
// bordered header (leading icon + title + action icon row + close), then a
// scrollable body that switches between loading / not-found / content, and
// an optional sticky footer.
//
// The shell is data-agnostic: it never fetches. `loading` and `notFound`
// are controlled by the caller, which owns the data. Typical recipe:
//
//   const [record, setRecord] = useState(null);
//   const [loading, setLoading] = useState(false);
//   useEffect(() => {
//     if (!open || !recordId) return;
//     setLoading(true);
//     fetchRecord(recordId)
//       .then((res) => setRecord(res ?? null))
//       .finally(() => setLoading(false));
//   }, [open, recordId]);
//   ...
//   <DetailsDrawerShell open={open} loading={loading} notFound={!record} ...>
//
// Props:
// - open, onClose        — controlled visibility.
// - icon                 — optional Iconify name rendered before the title
//                          (primary colour, width 22).
// - title                — header title (h6).
// - subtitle             — optional caption line under the title.
// - width                — Drawer paper width. Default
//                          { xs: '100%', sm: 480, md: 560 }.
// - actions              — either an array of ActionDef descriptors
//                          [{ key?, icon, label, color?, hidden?, disabled?,
//                          confirm?, onClick }] rendered via
//                          <DetailHeaderActions asIcons /> as filled circular
//                          ActionIconButtons (color: 'default' | 'primary' |
//                          'success' | 'info' | 'warning' | 'error'; `label`
//                          is the tooltip; `tooltip` is accepted as a
//                          back-compat alias for `label`; `confirm` shows a
//                          confirmation dialog before onClick), or a
//                          ReactNode rendered as-is. Either way a close
//                          button is always appended.
// - loading              — body shows a centered CircularProgress.
// - notFound             — body shows an EmptyContent (when not loading).
// - emptyTitle           — EmptyContent title. Default 'Introuvable'.
// - emptyDescription     — optional EmptyContent description.
// - closeTooltip         — close button tooltip. Default 'Fermer'.
// - headerExtras         — optional node rendered after the title block
//                          (status pill, counters...).
// - footer               — optional sticky footer slot (bordered, paper bg).
// - children             — drawer body, hosted in a Scrollbar with p: 2.5.

// ----------------------------------------------------------------------

export function DetailsDrawerShell({
  open,
  onClose,
  icon,
  title,
  subtitle,
  width = { xs: '100%', sm: 480, md: 560 },
  actions,
  loading = false,
  notFound = false,
  emptyTitle = 'Introuvable',
  emptyDescription,
  closeTooltip = 'Fermer',
  headerExtras,
  footer,
  children,
}) {
  // `tooltip` is kept as a back-compat alias for the system-wide ActionDef
  // `label` key; DetailHeaderActions handles hidden/disabled/confirm.
  const actionItems = Array.isArray(actions)
    ? actions.filter(Boolean).map((action) => ({ ...action, label: action.label ?? action.tooltip }))
    : null;

  return (
    <Drawer
      anchor="right"
      open={open}
      onClose={onClose}
      PaperProps={{
        sx: {
          width,
          bgcolor: 'background.default',
        },
      }}
    >
      {/* ===== Sticky header: icon + title + action icons + close ===== */}
      <Stack
        direction="row"
        alignItems="center"
        justifyContent="space-between"
        spacing={2}
        sx={{
          p: 2.5,
          position: 'sticky',
          top: 0,
          zIndex: 10,
          bgcolor: 'background.paper',
          borderBottom: 1,
          borderColor: 'divider',
        }}
      >
        <Stack direction="row" alignItems="center" spacing={1.5} sx={{ minWidth: 0 }}>
          {icon && (
            <Iconify icon={icon} width={22} sx={{ color: 'primary.main', flexShrink: 0 }} />
          )}
          <Box sx={{ minWidth: 0 }}>
            <Typography variant="h6" noWrap>
              {title}
            </Typography>
            {subtitle && (
              <Typography variant="caption" noWrap sx={{ display: 'block', color: 'text.secondary' }}>
                {subtitle}
              </Typography>
            )}
          </Box>
          {headerExtras}
        </Stack>

        <Stack
          direction="row"
          alignItems="center"
          justifyContent="flex-end"
          spacing={1.25}
          flexWrap="wrap"
          sx={{ flexShrink: 0 }}
        >
          {actionItems ? (
            <DetailHeaderActions asIcons actions={actionItems} spacing={1.25} />
          ) : (
            actions
          )}

          <Tooltip title={closeTooltip}>
            <IconButton onClick={onClose}>
              <Iconify icon="mingcute:close-line" />
            </IconButton>
          </Tooltip>
        </Stack>
      </Stack>

      {/* ===== Body ===== */}
      {loading && (
        <Stack alignItems="center" justifyContent="center" sx={{ flexGrow: 1, py: 8 }}>
          <CircularProgress />
        </Stack>
      )}

      {!loading && notFound && (
        <EmptyContent
          title={emptyTitle}
          description={emptyDescription}
          sx={{ flexGrow: 1, py: 10 }}
        />
      )}

      {!loading && !notFound && (
        <Scrollbar fillContent sx={{ flexGrow: 1, minHeight: 0 }}>
          <Box sx={{ p: 2.5 }}>{children}</Box>
        </Scrollbar>
      )}

      {/* ===== Sticky footer slot ===== */}
      {footer && (
        <Box
          sx={{
            position: 'sticky',
            bottom: 0,
            zIndex: 10,
            p: 2.5,
            bgcolor: 'background.paper',
            borderTop: 1,
            borderColor: 'divider',
          }}
        >
          {footer}
        </Box>
      )}
    </Drawer>
  );
}
