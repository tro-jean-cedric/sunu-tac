export * from './details-drawer-shell';
