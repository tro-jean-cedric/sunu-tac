import Box from '@mui/material/Box';
import Link from '@mui/material/Link';
import Stack from '@mui/material/Stack';
import Breadcrumbs from '@mui/material/Breadcrumbs';

import { Iconify } from 'src/components/iconify';

import { BreadcrumbsLink } from './breadcrumb-link';

// ----------------------------------------------------------------------

/**
 * One breadcrumb entry. Without `href` the entry renders as plain text
 * (the current page).
 *
 * @typedef {object} CustomBreadcrumbsLink
 * @property {string} [name]
 * @property {string} [href]
 * @property {import('react').ReactNode} [icon]
 * @property {boolean} [iconOnly]
 */

/**
 * Per-slot style overrides.
 *
 * @typedef {object} CustomBreadcrumbsSlotProps
 * @property {import('@mui/material').SxProps<import('@mui/material').Theme>} [breadcrumbs]
 * @property {import('@mui/material').SxProps<import('@mui/material').Theme>} [action]
 * @property {import('@mui/material').SxProps<import('@mui/material').Theme>} [moreLink]
 */

/**
 * @typedef {object} CustomBreadcrumbsOwnProps
 * @property {CustomBreadcrumbsLink[]} links The first link is always rendered as
 *   a home icon. Required, but an empty array is tolerated: the trail is then
 *   simply not rendered, so a page that builds its trail asynchronously can
 *   render `links={[]}` on the first pass without crashing.
 * @property {string} [heading]
 * @property {import('react').ReactNode} [action]
 * @property {string[]} [moreLink]
 * @property {boolean} [activeLast]
 * @property {CustomBreadcrumbsSlotProps} [slotProps]
 */

/**
 * `sx` is applied to the wrapping `Stack`; the remaining props are spread onto
 * the MUI `Breadcrumbs`. `sx` accepts an array as well as an object.
 *
 * @typedef {CustomBreadcrumbsOwnProps & Omit<import('@mui/material').BreadcrumbsProps, 'children' | 'slotProps'>} CustomBreadcrumbsProps
 */

/**
 * @param {CustomBreadcrumbsProps} props
 * @returns {import('react').JSX.Element}
 */
export function CustomBreadcrumbs({
  links = [],
  action,
  heading,
  moreLink,
  activeLast,
  slotProps,
  sx,
  ...other
}) {
  const transformedLinks = links.map((link, index) =>
    index === 0
      ? {
          ...link,
          icon: <Iconify icon="solar:home-2-outline" width={20} />,
          name: '',
          iconOnly: true,
        }
      : link
  );
  // NB: no `transformedLinks[length - 1]` dereference here. There used to be
  // one, feeding a `lastLink` binding that nothing read — so an empty `links`
  // (a trail still loading, a page with no ancestors) threw a TypeError before
  // the `!!links.length` guard below ever got a chance to suppress the trail.

  const renderLinks = (
    <Breadcrumbs separator={<Separator />} sx={slotProps?.breadcrumbs} {...other}>
      {transformedLinks.map((link, index) => (
        <BreadcrumbsLink
          key={index}
          link={link}
          activeLast={activeLast}
          disabled={index === transformedLinks.length - 1}
        />
      ))}
    </Breadcrumbs>
  );

  const renderAction = (
    <Box
      sx={{
        flexShrink: 0,
        display: 'flex',
        gap: 1,
        '& .MuiButton-contained': {
          bgcolor: 'primary.main',
          color: '#ffffff',
          boxShadow: 'none',
          borderRadius: '20px',
          padding: '12px 17px',
          '&:hover': {
            bgcolor: '#000000',
            color: '#ffffff',
            boxShadow: 'none',
          },
        },
        '& .MuiButton-outlined': {
          borderColor: 'common.white',
          color: 'common.white',
          bgcolor: 'transparent',
          '&:hover': {
            borderColor: 'common.white',
            bgcolor: 'rgba(255,255,255,0.12)',
          },
        },
        '& .MuiButton-text': {
          color: 'common.white',
          '&:hover': { bgcolor: 'rgba(255,255,255,0.12)' },
        },
        '& .MuiIconButton-root': {
          color: 'common.white',
          '&:hover': { bgcolor: 'rgba(255,255,255,0.12)' },
        },
        ...slotProps?.action,
      }}
    >
      {' '}
      {action}{' '}
    </Box>
  );

  const renderMoreLink = (
    <Box component="ul">
      {moreLink?.map((href) => (
        <Box key={href} component="li" sx={{ display: 'flex' }}>
          <Link href={href} variant="body2" target="_blank" rel="noopener" sx={slotProps?.moreLink}>
            {href}
          </Link>
        </Box>
      ))}
    </Box>
  );

  return (
    <Stack spacing={2} sx={sx}>
      <Stack
        direction="row"
        alignItems="center"
        sx={{
          mt: 'calc(var(--layout-dashboard-content-pt) * -1)',
          position: 'relative',
          py: 2,
          '&::before': {
            content: '""',
            position: 'absolute',
            top: 0,
            bottom: 0,
            left: 'calc(50% - 50vw)',
            right: 'calc(50% - 60vw)',
            bgcolor: '#cb3b2a',
            zIndex: 0,
          },
          '& > *': { position: 'relative', zIndex: 1 },
        }}
      >
        <Box sx={{ flexGrow: 1 }}>{!!links.length && renderLinks}</Box>

        {action && renderAction}
      </Stack>

      {!!moreLink && renderMoreLink}
    </Stack>
  );
}

// ----------------------------------------------------------------------

function Separator() {
  return (
    <Box
      component="span"
      sx={{
        color: 'common.white',
        fontWeight: 600,
        fontSize: 14,
        lineHeight: 1,
      }}
    >
      /
    </Box>
  );
}
