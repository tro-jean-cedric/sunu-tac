import { useState, useEffect } from 'react';

import LoadingButton from '@mui/lab/LoadingButton';
import {
  Box,
  Stack,
  Dialog,
  Button,
  Typography,
  DialogTitle,
  DialogContent,
  DialogActions,
} from '@mui/material';

import { toast } from 'src/components/snackbar';
import { Iconify } from 'src/components/iconify';
import { DialogCloseButton } from 'src/components/custom-dialog';

import { StepCard } from './step-card';
import { PreviewTable } from './preview-table';

// ----------------------------------------------------------------------
// Guided "import from spreadsheet" dialog, data-agnostic. Three StepCards:
// (1) download the template, (2) pick the filled-out file, (3) parse it —
// parsed rows land in an editable preview table before the final import.
// The consumer supplies the parsing and importing logic as async callbacks
// (any parent association — e.g. the target annual budget — is folded in by
// the caller inside `onImport`).
//
// Props:
//  - open, onClose  : controlled Dialog state. Every open resets file/rows/
//                     loading state. Backdrop clicks never close; Escape and
//                     buttons are guarded while parsing / importing.
//  - title          : dialog heading
//  - subtitle       : optional caption under the heading
//  - templateUrl    : href of the downloadable template. Step 1 is hidden
//                     when absent.
//  - accept         : file input filter (default '.xlsx,.xls,.csv')
//  - onParse        : async (file) => { ok, rows?, message?, errors? }.
//                     On ok, `rows` fill the editable preview.
//  - onImport       : async (rows) => { ok, message?, errors? }. On ok the
//                     dialog notifies success, calls onDone?.() then onClose.
//  - previewColumns : [{ key, label, type: 'text'|'number', align?, width? }]
//                     — one editable cell per column in the preview table.
//  - onDone         : optional callback after a successful import (refresh).
//  - notify         : (message, severity) => void — defaults to the DS toast.
//                     Multi-line error payloads (an `errors` array, or a
//                     `message` split on '\n') are emitted one call each.
//  - labels         : overridable French UI strings — see DEFAULT_LABELS
//                     (includes `rowsCount: (n) => string` and `step`, the
//                     StepCard header word).
//  - maxWidth       : Dialog maxWidth (default 'lg')
// ----------------------------------------------------------------------

const DEFAULT_LABELS = {
  step: 'Étape',
  downloadStep: 'Téléchargez le modèle Excel',
  download: 'Télécharger le template',
  pickStep: 'Sélectionnez le fichier rempli',
  pickFile: 'Sélectionner un fichier excel',
  changeFile: 'Changer de fichier',
  parseStep: 'Analysez le fichier',
  parse: 'Charger',
  import: 'Importer',
  close: 'Fermer',
  preview: 'Aperçu',
  rowsCount: (n) => `${n} ligne${n > 1 ? 's' : ''}`,
  previewHint: "Vous pouvez éditer ou retirer une ligne avant l'import.",
  removeRow: 'Retirer',
  noFile: 'Veuillez sélectionner un fichier excel',
  parseSuccess: 'Fichier analysé',
  parseFailed: "Échec de l'analyse du fichier",
  noRows: 'Aucune ligne à importer',
  importSuccess: 'Import effectué',
  importFailed: "Échec de l'import",
};

const defaultNotify = (message, severity) => {
  if (severity && typeof toast[severity] === 'function') toast[severity](message);
  else toast(message);
};

// Emit every line of an error payload as its own notification: a non-empty
// `errors` array wins, otherwise `message` is split on newlines; `fallback`
// covers empty payloads.
function notifyErrors(notify, res, fallback) {
  const fromErrors = Array.isArray(res?.errors) ? res.errors.filter(Boolean) : [];
  const messages = fromErrors.length
    ? fromErrors
    : (res?.message ?? '').split('\n').filter(Boolean);
  if (messages.length) messages.forEach((m) => notify(m, 'error'));
  else notify(fallback, 'error');
}

export function ExcelImportDialog({
  open,
  onClose,
  title,
  subtitle,
  templateUrl,
  accept = '.xlsx,.xls,.csv',
  onParse,
  onImport,
  previewColumns = [],
  onDone,
  notify = defaultNotify,
  labels: labelsProp,
  maxWidth = 'lg',
}) {
  const labels = { ...DEFAULT_LABELS, ...labelsProp };

  const [file, setFile] = useState(null);
  const [parsing, setParsing] = useState(false);
  const [importing, setImporting] = useState(false);
  const [rows, setRows] = useState([]);
  const [templateDownloaded, setTemplateDownloaded] = useState(false);

  // Reset transient state every time the dialog opens for a new target.
  useEffect(() => {
    if (!open) return;
    setFile(null);
    setRows([]);
    setParsing(false);
    setImporting(false);
    setTemplateDownloaded(false);
  }, [open]);

  const handlePickFile = (e) => {
    const next = e.target.files?.[0] ?? null;
    setFile(next);
    setRows([]);
    e.target.value = '';
  };

  const parse = async () => {
    if (!file) {
      notify(labels.noFile, 'error');
      return;
    }
    setParsing(true);
    try {
      const res = await onParse?.(file);
      if (!res?.ok) {
        notifyErrors(notify, res, labels.parseFailed);
        return;
      }
      notify(res.message ?? labels.parseSuccess, 'success');
      setRows((res.rows ?? []).map((r) => ({ ...r })));
    } catch (error) {
      console.error(error);
      notify(labels.parseFailed, 'error');
    } finally {
      setParsing(false);
    }
  };

  const updateRow = (idx, key, value) => {
    setRows((prev) => {
      const next = [...prev];
      next[idx] = { ...next[idx], [key]: value };
      return next;
    });
  };

  const removeRow = (idx) => {
    setRows((prev) => prev.filter((_, i) => i !== idx));
  };

  const submit = async () => {
    if (!rows.length) {
      notify(labels.noRows, 'error');
      return;
    }
    setImporting(true);
    try {
      const res = await onImport?.(rows);
      if (res?.ok) {
        notify(res.message ?? labels.importSuccess, 'success');
        onDone?.();
        onClose?.();
      } else {
        notifyErrors(notify, res, labels.importFailed);
      }
    } catch (error) {
      console.error(error);
      notify(labels.importFailed, 'error');
    } finally {
      setImporting(false);
    }
  };

  const isWorking = parsing || importing;

  // Backdrop clicks never close the dialog; Escape (and the buttons) only
  // close while no async work is in flight.
  const handleDialogClose = (event, reason) => {
    if (reason === 'backdropClick') return;
    if (isWorking) return;
    onClose?.(event, reason);
  };

  return (
    <Dialog
      fullWidth
      maxWidth={maxWidth}
      open={open}
      onClose={handleDialogClose}
      PaperProps={{ sx: { borderRadius: 2 } }}
    >
      <DialogCloseButton
        onClick={() => {
          if (!isWorking) onClose?.();
        }}
      />
      <DialogTitle>
        <Stack spacing={0.25}>
          <Typography variant="h6">{title}</Typography>
          {subtitle && (
            <Typography variant="caption" color="text.secondary">
              {subtitle}
            </Typography>
          )}
        </Stack>
      </DialogTitle>

      <DialogContent dividers sx={{ display: 'flex', flexDirection: 'column', gap: 2.5 }}>
        {/* steps row */}
        <Stack direction={{ xs: 'column', md: 'row' }} spacing={2}>
          {templateUrl && (
            <StepCard
              index={1}
              title={labels.downloadStep}
              done={templateDownloaded}
              stepLabel={labels.step}
            >
              <Button
                component="a"
                href={templateUrl}
                download
                variant="contained"
                startIcon={<Iconify icon="solar:download-minimalistic-bold" />}
                onClick={() => setTemplateDownloaded(true)}
              >
                {labels.download}
              </Button>
            </StepCard>
          )}

          <StepCard
            index={templateUrl ? 2 : 1}
            title={labels.pickStep}
            done={!!file}
            stepLabel={labels.step}
          >
            <Button
              component="label"
              variant="contained"
              startIcon={<Iconify icon="solar:cloud-upload-bold" />}
              disabled={isWorking}
            >
              {file ? labels.changeFile : labels.pickFile}
              <input hidden type="file" accept={accept} onChange={handlePickFile} />
            </Button>
            {file && (
              <Typography variant="caption" color="text.secondary" noWrap>
                {file.name}
              </Typography>
            )}
          </StepCard>

          <StepCard
            index={templateUrl ? 3 : 2}
            title={labels.parseStep}
            done={rows.length > 0}
            stepLabel={labels.step}
          >
            <LoadingButton
              variant="contained"
              loading={parsing}
              disabled={!file || importing}
              startIcon={<Iconify icon="solar:document-text-bold" />}
              onClick={parse}
            >
              {labels.parse}
            </LoadingButton>
          </StepCard>
        </Stack>

        {/* parsed rows */}
        {rows.length > 0 && (
          <PreviewTable
            rows={rows}
            columns={previewColumns}
            onChangeCell={updateRow}
            onRemoveRow={removeRow}
            disabled={importing}
            labels={labels}
          />
        )}
      </DialogContent>

      <DialogActions sx={{ px: 3, py: 2, gap: 1 }}>
        <Button onClick={onClose} color="inherit" disabled={isWorking}>
          {labels.close}
        </Button>
        <Box sx={{ flex: 1 }} />
        <LoadingButton
          variant="contained"
          loading={importing}
          disabled={parsing || rows.length === 0}
          startIcon={<Iconify icon="solar:upload-square-bold" />}
          onClick={submit}
        >
          {labels.import}
        </LoadingButton>
      </DialogActions>
    </Dialog>
  );
}
