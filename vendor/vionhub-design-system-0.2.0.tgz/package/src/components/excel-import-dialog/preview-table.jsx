import {
  Box,
  Stack,
  Table,
  Paper,
  Tooltip,
  TableRow,
  TextField,
  TableBody,
  TableCell,
  TableHead,
  Typography,
  IconButton,
  TableContainer,
} from '@mui/material';

import { Iconify } from 'src/components/iconify';
import { NumberFormatInput } from 'src/components/number-format-input';

// ----------------------------------------------------------------------
// Editable preview of the parsed rows (internal to excel-import-dialog).
// Sticky-header table with an index column, one editable cell per entry of
// `columns` (TextField for 'text', NumberFormatInput for 'number') and a
// per-row remove button. The caption above shows the row count and an edit
// hint.
//
// Props:
//  - rows     : array of plain row objects
//  - columns  : [{ key, label, type: 'text'|'number', align?, width? }]
//  - onChangeCell(rowIndex, key, value)
//  - onRemoveRow(rowIndex)
//  - disabled : freeze editing while parsing / importing
//  - labels   : { preview, rowsCount: (n) => string, previewHint, removeRow }
// ----------------------------------------------------------------------

export function PreviewTable({ rows, columns, onChangeCell, onRemoveRow, disabled, labels }) {
  return (
    <Box>
      <Stack direction="row" alignItems="center" justifyContent="space-between" sx={{ mb: 1 }}>
        <Typography variant="subtitle2" sx={{ fontWeight: 700 }}>
          {labels.preview} ({labels.rowsCount(rows.length)})
        </Typography>
        <Typography variant="caption" color="text.secondary">
          {labels.previewHint}
        </Typography>
      </Stack>

      <TableContainer component={Paper} variant="outlined" sx={{ borderRadius: 1.5, maxHeight: 360 }}>
        <Table size="small" stickyHeader>
          <TableHead>
            <TableRow>
              <TableCell sx={{ width: 50, fontWeight: 700 }}>#</TableCell>
              {columns.map((col) => (
                <TableCell
                  key={col.key}
                  align={col.align}
                  sx={{ width: col.width, fontWeight: 700 }}
                >
                  {col.label}
                </TableCell>
              ))}
              <TableCell sx={{ width: 60 }} />
            </TableRow>
          </TableHead>
          <TableBody>
            {rows.map((row, idx) => (
              <TableRow key={idx} hover>
                <TableCell>{idx + 1}</TableCell>
                {columns.map((col) => (
                  <TableCell key={col.key} align={col.align}>
                    {col.type === 'number' ? (
                      <NumberFormatInput
                        size="small"
                        value={row[col.key] ?? ''}
                        onChange={(val) => onChangeCell(idx, col.key, val)}
                        disabled={disabled}
                        inputProps={{ style: { textAlign: col.align ?? 'right' } }}
                        sx={{ width: 140 }}
                      />
                    ) : (
                      <TextField
                        size="small"
                        fullWidth
                        value={row[col.key] ?? ''}
                        onChange={(e) => onChangeCell(idx, col.key, e.target.value)}
                        disabled={disabled}
                      />
                    )}
                  </TableCell>
                ))}
                <TableCell>
                  <Tooltip title={labels.removeRow}>
                    <IconButton
                      size="small"
                      color="error"
                      disabled={disabled}
                      onClick={() => onRemoveRow(idx)}
                    >
                      <Iconify icon="solar:trash-bin-trash-bold" width={18} />
                    </IconButton>
                  </Tooltip>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </Box>
  );
}
