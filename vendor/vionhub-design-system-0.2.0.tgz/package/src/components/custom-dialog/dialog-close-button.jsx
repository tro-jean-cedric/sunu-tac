import { Tooltip, IconButton } from '@mui/material';

import { Iconify } from 'src/components/iconify';

// Top-right close affordance for any MUI Dialog. Drop it as the first child
// of the Dialog (sibling of DialogTitle/Content/Actions) — it positions itself
// absolutely so it doesn't interfere with the title text.
export function DialogCloseButton({ onClick, sx, ...other }) {
  return (
    <Tooltip title="Fermer">
      <IconButton
        onClick={onClick}
        sx={{
          position: 'absolute',
          top: 8,
          right: 8,
          color: 'common.white',
          zIndex: 1,
          ...sx,
        }}
        {...other}
      >
        <Iconify icon="mingcute:close-line" width={20} />
      </IconButton>
    </Tooltip>
  );
}
