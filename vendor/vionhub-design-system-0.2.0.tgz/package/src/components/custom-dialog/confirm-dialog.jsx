import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import DialogTitle from '@mui/material/DialogTitle';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';

// ----------------------------------------------------------------------

/**
 * Wraps a Dialog onClose so that clicks on the backdrop are ignored.
 * Escape key presses still close the dialog. (Inlined from src/utils/dialog.)
 */
function staticDialog(onClose) {
  return (event, reason) => {
    if (reason === 'backdropClick') return;
    onClose?.(event, reason);
  };
}

export function ConfirmDialog({
  title,
  content,
  action,
  open,
  onClose,
  cancelText = 'Annuler',
  ...other
}) {
  return (
    <Dialog fullWidth maxWidth="xs" open={open} onClose={staticDialog(onClose)} {...other}>
      <DialogTitle sx={{ pb: 2 }}>{title}</DialogTitle>

      {content && <DialogContent sx={{ typography: 'body2' }}> {content} </DialogContent>}

      <DialogActions>
        {action}

        <Button variant="outlined" color="inherit" onClick={onClose}>
          {cancelText}
        </Button>
      </DialogActions>
    </Dialog>
  );
}
