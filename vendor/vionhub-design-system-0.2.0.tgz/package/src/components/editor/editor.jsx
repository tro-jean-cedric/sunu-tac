import { common, createLowlight } from 'lowlight';
import LinkExtension from '@tiptap/extension-link';
import TableExtension from '@tiptap/extension-table';
import ImageExtension from '@tiptap/extension-image';
import StarterKitExtension from '@tiptap/starter-kit';
import TableRowExtension from '@tiptap/extension-table-row';
import TableCellExtension from '@tiptap/extension-table-cell';
import TextAlignExtension from '@tiptap/extension-text-align';
import PlaceholderExtension from '@tiptap/extension-placeholder';
import TableHeaderExtension from '@tiptap/extension-table-header';
import { useRef, useState, useEffect, forwardRef, useCallback } from 'react';
import CodeBlockLowlightExtension from '@tiptap/extension-code-block-lowlight';
import { useEditor, EditorContent, ReactNodeViewRenderer } from '@tiptap/react';

import Stack from '@mui/material/Stack';
import Portal from '@mui/material/Portal';
import Backdrop from '@mui/material/Backdrop';
import FormHelperText from '@mui/material/FormHelperText';

import { Toolbar } from './toolbar';
import { StyledRoot } from './styles';
import { editorClasses } from './classes';
import { CodeHighlightBlock } from './components/code-highlight-block';

// ----------------------------------------------------------------------

// Detect tab-separated values pasted from terminals or stripped Excel cells.
// Excel/Sheets normally hand over `text/html` with a real <table>, so Tiptap
// renders those natively — this fallback only runs when nothing else applies.
const looksLikeTsv = (text) => {
  if (!text || !text.includes('\t')) return false;
  const lines = text.split(/\r?\n/).filter((l) => l.length > 0);
  return lines.length >= 1 && lines.every((l) => l.includes('\t'));
};

const tsvToTableHtml = (text) => {
  const rows = text.split(/\r?\n/).filter((l) => l.length > 0).map((l) => l.split('\t'));
  const cols = Math.max(...rows.map((r) => r.length));
  const escape = (s) => s.replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
  const headerCells = rows[0].map((c) => `<th>${escape(c)}</th>`).join('');
  const bodyRows = rows.slice(1).map((r) => {
    const padded = [...r, ...Array(cols - r.length).fill('')];
    return `<tr>${padded.map((c) => `<td>${escape(c)}</td>`).join('')}</tr>`;
  }).join('');
  return `<table><tbody><tr>${headerCells}</tr>${bodyRows}</tbody></table>`;
};

export const Editor = forwardRef(
  (
    {
      sx,
      error,
      onChange,
      slotProps,
      helperText,
      resetValue,
      editable = true,
      fullItem = false,
      onUploadImage,
      value: content = '',
      placeholder = 'Write something awesome...',
      ...other
    },
    ref
  ) => {
    const [fullScreen, setFullScreen] = useState(false);
    // Stable ref so paste/drop callbacks (captured once by useEditor) can
    // reach the editor instance after it finishes initializing.
    const editorRef = useRef(null);

    const handleToggleFullScreen = useCallback(() => {
      setFullScreen((prev) => !prev);
    }, []);

    const lowlight = createLowlight(common);

    // `onUploadImage` is an app-provided callback: async (file) => url | null.
    // When absent, dropped/pasted image files are ignored (URL insertion via
    // the toolbar still works).
    const uploadAndInsertImage = useCallback(
      async (editorInstance, file) => {
        if (!onUploadImage) return false;
        if (!file || !file.type.startsWith('image/')) return false;
        const src = await onUploadImage(file);
        if (src) {
          editorInstance?.chain().focus().setImage({ src }).run();
          return true;
        }
        return false;
      },
      [onUploadImage]
    );

    const editor = useEditor({
      content,
      editable,
      extensions: [
        StarterKitExtension.configure({
          codeBlock: false,
          code: { HTMLAttributes: { class: editorClasses.content.codeInline } },
          heading: { HTMLAttributes: { class: editorClasses.content.heading } },
          horizontalRule: { HTMLAttributes: { class: editorClasses.content.hr } },
          listItem: { HTMLAttributes: { class: editorClasses.content.listItem } },
          blockquote: { HTMLAttributes: { class: editorClasses.content.blockquote } },
          bulletList: { HTMLAttributes: { class: editorClasses.content.bulletList } },
          orderedList: { HTMLAttributes: { class: editorClasses.content.orderedList } },
        }),
        PlaceholderExtension.configure({
          placeholder,
          emptyEditorClass: editorClasses.content.placeholder,
        }),
        ImageExtension.configure({
          allowBase64: false,
          HTMLAttributes: { class: editorClasses.content.image },
        }),
        TextAlignExtension.configure({ types: ['heading', 'paragraph'] }),
        LinkExtension.configure({
          autolink: true,
          openOnClick: false,
          HTMLAttributes: { class: editorClasses.content.link },
        }),
        TableExtension.configure({
          resizable: true,
          HTMLAttributes: { class: editorClasses.content.table },
        }),
        TableRowExtension.configure({ HTMLAttributes: { class: editorClasses.content.tableRow } }),
        TableHeaderExtension.configure({ HTMLAttributes: { class: editorClasses.content.tableHeader } }),
        TableCellExtension.configure({ HTMLAttributes: { class: editorClasses.content.tableCell } }),
        CodeBlockLowlightExtension.extend({
          addNodeView() {
            return ReactNodeViewRenderer(CodeHighlightBlock);
          },
        }).configure({ lowlight, HTMLAttributes: { class: editorClasses.content.codeBlock } }),
      ],
      editorProps: {
        handleDrop: (view, event) => {
          const files = Array.from(event.dataTransfer?.files ?? []);
          const images = files.filter((f) => f.type.startsWith('image/'));
          if (images.length === 0) return false;
          event.preventDefault();
          // We don't have the editor closure inside this callback (useEditor
          // wires `view` here), so we re-derive via ProseMirror's view.
          // The outer `editor` ref is stable once set — but we fire upload
          // through the closure using setTimeout to let useEditor finish init.
          // eslint-disable-next-line no-use-before-define
          images.forEach((file) => uploadAndInsertImage(editorRef.current, file));
          return true;
        },
        handlePaste: (view, event) => {
          const items = Array.from(event.clipboardData?.items ?? []);
          const imageItem = items.find((it) => it.kind === 'file' && it.type.startsWith('image/'));
          if (imageItem) {
            const file = imageItem.getAsFile();
            if (file) {
              event.preventDefault();
              // eslint-disable-next-line no-use-before-define
              uploadAndInsertImage(editorRef.current, file);
              return true;
            }
          }

          const html = event.clipboardData?.getData('text/html');
          // If the clipboard already has an HTML table (Excel, Sheets, Word),
          // let Tiptap's default paste handler take it — Table extension will
          // parse it into a real table node.
          if (html && /<table[\s>]/i.test(html)) return false;

          const text = event.clipboardData?.getData('text/plain') ?? '';
          if (looksLikeTsv(text)) {
            event.preventDefault();
            // eslint-disable-next-line no-use-before-define
            editorRef.current?.chain().focus().insertContent(tsvToTableHtml(text)).run();
            return true;
          }
          return false;
        },
      },
      onUpdate({ editor: _editor }) {
        const html = _editor.getHTML();
        onChange?.(html);
      },
      ...other,
    });

    editorRef.current = editor;

    // Keep the editor in sync when `value` changes from the outside — e.g. a
    // dialog reopening with a different record, or being reset to empty after
    // submit. We diff against the editor's current HTML so the user's own
    // keystrokes (which round-trip back through onChange) never trigger a
    // redundant setContent that would reset the caret.
    useEffect(() => {
      if (!editor) return;
      const next = content || '';
      const current = editor.getHTML();
      if (next === current) return;
      // '' and '<p></p>' are both "empty" — don't fight an already-empty editor.
      if (editor.isEmpty && (next === '' || next === '<p></p>')) return;
      editor.commands.setContent(next, false);
    }, [content, editor]);

    useEffect(() => {
      if (resetValue && !content) {
        editor?.commands.clearContent();
      }
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [content]);

    useEffect(() => {
      if (fullScreen) {
        document.body.style.overflow = 'hidden';
      } else {
        document.body.style.overflow = '';
      }
    }, [fullScreen]);

    return (
      <Portal disablePortal={!fullScreen}>
        {fullScreen && <Backdrop open sx={{ zIndex: (theme) => theme.zIndex.modal - 1 }} />}

        <Stack sx={{ ...(!editable && { cursor: 'not-allowed' }), ...slotProps?.wrap }}>
          <StyledRoot
            error={!!error}
            disabled={!editable}
            fullScreen={fullScreen}
            className={editorClasses.root}
            sx={sx}
          >
            <Toolbar
              editor={editor}
              fullItem={fullItem}
              fullScreen={fullScreen}
              onUploadImage={onUploadImage}
              onToggleFullScreen={handleToggleFullScreen}
            />
            <EditorContent
              ref={ref}
              spellCheck="false"
              autoComplete="off"
              autoCapitalize="off"
              editor={editor}
              className={editorClasses.content.root}
            />
          </StyledRoot>

          {helperText && (
            <FormHelperText error={!!error} sx={{ px: 2 }}>
              {helperText}
            </FormHelperText>
          )}
        </Stack>
      </Portal>
    );
  }
);
