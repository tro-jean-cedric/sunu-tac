import { useRef, useState, useCallback } from 'react';

import Tab from '@mui/material/Tab';
import Box from '@mui/material/Box';
import Tabs from '@mui/material/Tabs';
import Stack from '@mui/material/Stack';
import Button from '@mui/material/Button';
import Popover from '@mui/material/Popover';
import TextField from '@mui/material/TextField';
import Typography from '@mui/material/Typography';
import CircularProgress from '@mui/material/CircularProgress';

import { editorClasses } from '../classes';
import { ToolbarItem } from './toolbar-item';

// ----------------------------------------------------------------------

// `onUploadImage` is an app-provided callback: async (file) => url | null.
// When absent, the popover runs in URL-only mode (no "Importer" tab).
export function ImageBlock({ editor, onUploadImage }) {
  const canUpload = !!onUploadImage;

  const [url, setUrl] = useState('');
  const [tab, setTab] = useState('upload');
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState('');

  const [anchorEl, setAnchorEl] = useState(null);
  const fileInputRef = useRef(null);

  const handleOpenPopover = (event) => {
    setError('');
    setAnchorEl(event.currentTarget);
  };

  const handleClosePopover = () => {
    setAnchorEl(null);
  };

  const handleUpdateUrl = useCallback(() => {
    handleClosePopover();
    if (anchorEl && url) {
      editor?.chain().focus().setImage({ src: url }).run();
      setUrl('');
    }
  }, [anchorEl, editor, url]);

  const handleFileSelected = useCallback(
    async (event) => {
      const file = event.target.files?.[0];
      // Reset the input so re-selecting the same file still fires onChange.
      if (event.target) event.target.value = '';
      if (!file || !editor || !onUploadImage) return;

      setError('');
      setUploading(true);
      try {
        const src = await onUploadImage(file);
        if (src) {
          editor.chain().focus().setImage({ src }).run();
          handleClosePopover();
        } else {
          setError("Échec de l'envoi de l'image");
        }
      } catch (err) {
        setError(err?.message ?? "Échec de l'envoi de l'image");
      } finally {
        setUploading(false);
      }
    },
    [editor, onUploadImage]
  );

  if (!editor) {
    return null;
  }

  const activeTab = canUpload ? tab : 'url';

  return (
    <>
      <ToolbarItem
        aria-label="Image"
        className={editorClasses.toolbar.image}
        onClick={handleOpenPopover}
        icon={
          <path d="M20 5H4V19L13.2923 9.70649C13.6828 9.31595 14.3159 9.31591 14.7065 9.70641L20 15.0104V5ZM2 3.9934C2 3.44476 2.45531 3 2.9918 3H21.0082C21.556 3 22 3.44495 22 3.9934V20.0066C22 20.5552 21.5447 21 21.0082 21H2.9918C2.44405 21 2 20.5551 2 20.0066V3.9934ZM8 11C6.89543 11 6 10.1046 6 9C6 7.89543 6.89543 7 8 7C9.10457 7 10 7.89543 10 9C10 10.1046 9.10457 11 8 11Z" />
        }
      />

      <Popover
        id={anchorEl ? 'simple-popover' : undefined}
        open={!!anchorEl}
        anchorEl={anchorEl}
        onClose={handleClosePopover}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
        slotProps={{ paper: { sx: { p: 0, width: 320 } } }}
      >
        {canUpload && (
          <Tabs
            value={activeTab}
            onChange={(_, v) => setTab(v)}
            variant="fullWidth"
            sx={{ borderBottom: 1, borderColor: 'divider' }}
          >
            <Tab value="upload" label="Importer" />
            <Tab value="url" label="URL" />
          </Tabs>
        )}

        <Box sx={{ p: 2.5 }}>
          {activeTab === 'upload' && (
            <Stack spacing={1.5}>
              <Typography variant="body2" color="text.secondary">
                Sélectionnez une image depuis votre ordinateur.
              </Typography>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                hidden
                onChange={handleFileSelected}
              />
              <Button
                variant="contained"
                disabled={uploading}
                onClick={() => fileInputRef.current?.click()}
                startIcon={uploading ? <CircularProgress size={16} color="inherit" /> : null}
              >
                {uploading ? 'Envoi…' : 'Choisir un fichier'}
              </Button>
              {error && (
                <Typography variant="caption" color="error">
                  {error}
                </Typography>
              )}
            </Stack>
          )}

          {activeTab === 'url' && (
            <Stack spacing={1}>
              <Typography variant="subtitle2">URL</Typography>
              <Stack direction="row" alignItems="center" spacing={1}>
                <TextField
                  size="small"
                  placeholder="Entrer une URL..."
                  value={url}
                  onChange={(event) => setUrl(event.target.value)}
                  fullWidth
                />
                <Button variant="contained" onClick={handleUpdateUrl} disabled={!url}>
                  OK
                </Button>
              </Stack>
            </Stack>
          )}
        </Box>
      </Popover>
    </>
  );
}
