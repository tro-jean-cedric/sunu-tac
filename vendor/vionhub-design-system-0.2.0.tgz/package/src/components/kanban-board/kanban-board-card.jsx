import { Box, Chip, Stack, Avatar, Tooltip, Typography } from '@mui/material';

import { Label } from 'src/components/label';
import { Iconify } from 'src/components/iconify';

// ----------------------------------------------------------------------

/**
 * KanbanBoardCard — the default card rendered by KanbanBoard. A Paper-like
 * tile with: code caption + optional age/urgency badge on the first line,
 * a two-line clamped title, an avatar row with an optional secondary chip,
 * and a DS Label for the status. Everything is driven by accessor props so
 * most apps never need to write a custom `renderCard`.
 *
 * Accessors (all optional — a section is skipped when its accessor returns
 * a nullish value):
 * @param {object}   item             - The kanban item to render.
 * @param {Function} [getTitle]       - (item) => string. Default: `item.title ?? item.object`.
 * @param {Function} [getCode]        - (item) => string. Caption on the first line. Default: `item.code`.
 * @param {Function} [getStatusLabel] - (item) => string. Text of the status Label. Default: `item.status`.
 * @param {Function} [getStatusColor] - (item) => Label color ('default'|'primary'|'secondary'|'info'|'success'|'warning'|'error'). Default: 'default'.
 * @param {Function} [getAvatar]      - (item) => string | { name, src? }. Default: `item.owner?.name`.
 * @param {Function} [getBadge]       - (item) => { label, color?, tooltip? } | null. Small Label on the
 *                                      first line (e.g. age in days: `{ label: '5j', color: 'warning' }`).
 * @param {Function} [getChip]        - (item) => { label, color?, variant?, icon?, tooltip? } | null.
 *                                      Secondary outlined chip on the avatar row (e.g. request type).
 *                                      `icon` is an Iconify icon name.
 * @param {object}   [sx]             - Extra styles for the card root.
 */
export function KanbanBoardCard({
  item,
  getTitle = (i) => i?.title ?? i?.object ?? '—',
  getCode = (i) => i?.code ?? null,
  getStatusLabel = (i) => i?.status ?? null,
  getStatusColor = () => 'default',
  getAvatar = (i) => i?.owner?.name ?? null,
  getBadge,
  getChip,
  sx,
}) {
  const code = getCode?.(item);
  const badge = getBadge?.(item);
  const chip = getChip?.(item);
  const statusLabel = getStatusLabel?.(item);

  const rawAvatar = getAvatar?.(item);
  const avatar =
    rawAvatar == null ? null : typeof rawAvatar === 'string' ? { name: rawAvatar } : rawAvatar;

  const chipNode = chip ? (
    <Chip
      size="small"
      color={chip.color}
      variant={chip.variant ?? 'outlined'}
      icon={chip.icon ? <Iconify icon={chip.icon} width={12} /> : undefined}
      label={chip.label}
      sx={{
        height: 18,
        ...(chip.icon && { '& .MuiChip-icon': { ml: 0.25 } }),
        '& .MuiChip-label': { px: 0.5, fontSize: 10 },
      }}
    />
  ) : null;

  return (
    <Box
      sx={(theme) => ({
        p: 1.5,
        borderRadius: 1.5,
        bgcolor: 'background.paper',
        boxShadow: theme.customShadows?.z1 ?? theme.shadows[1],
        '&:hover': { boxShadow: theme.customShadows?.z8 ?? theme.shadows[4] },
        ...sx,
      })}
    >
      <Stack spacing={1}>
        {(code || badge) && (
          <Stack direction="row" alignItems="center" spacing={0.75} sx={{ minWidth: 0 }}>
            {code && (
              <Typography variant="caption" sx={{ fontWeight: 700, color: 'text.secondary' }}>
                {code}
              </Typography>
            )}
            <Box sx={{ flexGrow: 1 }} />
            {badge &&
              (badge.tooltip ? (
                <Tooltip title={badge.tooltip}>
                  <Label
                    color={badge.color ?? 'default'}
                    variant="soft"
                    sx={{ height: 18, fontSize: 10, px: 0.75 }}
                  >
                    {badge.label}
                  </Label>
                </Tooltip>
              ) : (
                <Label
                  color={badge.color ?? 'default'}
                  variant="soft"
                  sx={{ height: 18, fontSize: 10, px: 0.75 }}
                >
                  {badge.label}
                </Label>
              ))}
          </Stack>
        )}

        <Typography
          variant="body2"
          sx={{
            fontWeight: 600,
            display: '-webkit-box',
            WebkitBoxOrient: 'vertical',
            WebkitLineClamp: 2,
            overflow: 'hidden',
          }}
        >
          {getTitle?.(item) ?? '—'}
        </Typography>

        {(avatar || chipNode) && (
          <Stack direction="row" alignItems="center" spacing={1}>
            {avatar && (
              <>
                <Avatar src={avatar.src} sx={{ width: 22, height: 22, fontSize: 11 }}>
                  {avatar.name?.[0]?.toUpperCase() ?? '?'}
                </Avatar>
                <Typography
                  variant="caption"
                  noWrap
                  sx={{ color: 'text.secondary', flexGrow: 1 }}
                >
                  {avatar.name ?? '—'}
                </Typography>
              </>
            )}
            {!avatar && <Box sx={{ flexGrow: 1 }} />}
            {chip?.tooltip ? <Tooltip title={chip.tooltip}>{chipNode}</Tooltip> : chipNode}
          </Stack>
        )}

        {statusLabel && (
          <Label
            color={getStatusColor?.(item) ?? 'default'}
            variant="soft"
            sx={{ textTransform: 'none', alignSelf: 'flex-start', fontSize: 10, height: 20 }}
          >
            {statusLabel}
          </Label>
        )}
      </Stack>
    </Box>
  );
}
