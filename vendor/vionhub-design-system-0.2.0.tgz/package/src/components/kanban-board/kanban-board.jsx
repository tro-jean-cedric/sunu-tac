import { useMemo, useState, useCallback } from 'react';
import {
  useSensor,
  DndContext,
  useSensors,
  DragOverlay,
  MouseSensor,
  TouchSensor,
  KeyboardSensor,
  closestCorners,
  MeasuringStrategy,
  defaultDropAnimationSideEffects,
} from '@dnd-kit/core';

import { Box, Stack, Portal } from '@mui/material';

import { EmptyContent } from 'src/components/empty-content';

import { KanbanColumn } from './kanban-column';
import { KanbanBoardCard } from './kanban-board-card';

// ----------------------------------------------------------------------

/**
 * KanbanBoard — a config-driven kanban where drag-and-drop does NOT reorder
 * data: dropping a card on a column resolves a *workflow action* instead.
 * The board never mutates `items` itself — after an action completes the
 * parent refreshes its data and the cards redistribute.
 *
 * While a card is being dragged, every column live-evaluates `resolveDrop`
 * for that card and paints accept (column accent border) vs deny (error
 * border) feedback. On drop:
 *   - `{ kind: 'noop' }`             → nothing happens (same column, no rule…).
 *   - `{ kind: 'blocked', reason }`  → `onBlocked(reason)` is called — the
 *     caller decides how to surface it (toast…); the board stays silent.
 *   - `{ kind: 'action', payload }`  → `await onDropAction(payload, item)`;
 *     a busy overlay covers the target column while the promise is pending.
 *     Errors thrown by `onDropAction` are swallowed here — handle them (and
 *     any toasts) inside the callback.
 *
 * Props:
 * @param {Array}    columns       - [{ id, title, accent?: 'primary'|'secondary'|'info'|'success'|'warning'|'error'|'default', emptyLabel? }].
 * @param {Array}    items         - Flat list of items; bucketed via `getItemColumn`.
 * @param {Function} [getItemId]   - (item) => unique id. Default: `(i) => i.id`.
 * @param {Function} getItemColumn - (item) => columnId. Items mapping to no known column are hidden.
 * @param {Function} resolveDrop   - ({ item, from, to }) => { kind: 'noop' } | { kind: 'blocked', reason } | { kind: 'action', payload }.
 *                                   Pure function — keep the drop-rule matrix app-side as data.
 * @param {Function} onDropAction  - async (payload, item) => {}. Fires for `kind: 'action'` drops.
 * @param {Function} [onBlocked]   - (reason) => void. Fires for `kind: 'blocked'` drops.
 * @param {Function} [onItemClick] - (item) => void. Card click (ignored when the click ends a drag).
 * @param {Function} [renderCard]  - (item, { isDragOverlay }) => node. Defaults to `<KanbanBoardCard item={item} />`.
 * @param {boolean}  [loading]     - Disables dragging while data is being (re)fetched.
 * @param {number}   [columnWidth] - Column width in px. Default 320.
 * @param {number|string} [maxBodyHeight] - Max height of each column body. Default 'calc(100vh - 320px)'.
 * @param {string}   [emptyTitle]  - Title of the EmptyContent shown when there are no items at all.
 * @param {string}   [emptyDescription] - Optional description under `emptyTitle`.
 * @param {object}   [sx]          - Applied to the horizontal scroll container.
 */
export function KanbanBoard({
  columns,
  items,
  getItemId = (i) => i.id,
  getItemColumn,
  resolveDrop,
  onDropAction,
  onBlocked,
  onItemClick,
  renderCard,
  loading = false,
  columnWidth = 320,
  maxBodyHeight = 'calc(100vh - 320px)',
  emptyTitle = 'Aucun élément',
  emptyDescription,
  sx,
}) {
  const [activeId, setActiveId] = useState(null);
  // Column currently awaiting its onDropAction promise — gets a busy overlay.
  const [busyColumnId, setBusyColumnId] = useState(null);

  // Build a map: columnId → cards. Rebuilt on every render — cheap (linear in
  // items) and keeps the board in sync with refreshed parent data.
  const cardsByColumn = useMemo(() => {
    const buckets = Object.fromEntries(columns.map((c) => [c.id, []]));
    (items ?? []).forEach((item) => {
      const colId = getItemColumn?.(item);
      if (colId && buckets[colId]) buckets[colId].push(item);
    });
    return buckets;
  }, [columns, items, getItemColumn]);

  const findItemById = useCallback(
    (id) => (items ?? []).find((item) => String(getItemId(item)) === String(id)),
    [items, getItemId]
  );

  const findColumnOfCard = useCallback(
    (cardId) => {
      const entry = Object.entries(cardsByColumn).find(([, arr]) =>
        arr.some((item) => String(getItemId(item)) === String(cardId))
      );
      return entry ? columns.find((c) => c.id === entry[0]) : null;
    },
    [cardsByColumn, columns, getItemId]
  );

  const sensors = useSensors(
    useSensor(MouseSensor, { activationConstraint: { distance: 6 } }),
    useSensor(TouchSensor, { activationConstraint: { delay: 150, tolerance: 8 } }),
    useSensor(KeyboardSensor)
  );

  const activeItem = activeId ? findItemById(activeId) : null;
  const activeColumn = activeItem ? findColumnOfCard(activeId) : null;

  // For visual feedback: tell each column whether dropping the currently
  // dragged card on it would resolve to an action.
  const canDropOn = useCallback(
    (column) => {
      if (!activeItem || !activeColumn || !resolveDrop) return false;
      const result = resolveDrop({ item: activeItem, from: activeColumn, to: column });
      return result?.kind === 'action';
    },
    [activeItem, activeColumn, resolveDrop]
  );

  const renderCardFn = useCallback(
    (item, opts) =>
      renderCard ? renderCard(item, opts) : <KanbanBoardCard item={item} />,
    [renderCard]
  );

  const handleDragEnd = useCallback(
    async ({ active, over }) => {
      setActiveId(null);
      if (!over) return;

      const overId = String(over.id);
      // Drop target may be a column id or a card id (when hovering over a
      // card). Normalize to the column.
      const targetColumn = columns.find((c) => c.id === overId) || findColumnOfCard(overId);
      if (!targetColumn) return;

      const item = findItemById(active.id);
      if (!item) return;
      const sourceColumn = findColumnOfCard(active.id);
      if (!sourceColumn) return;

      const result = resolveDrop?.({ item, from: sourceColumn, to: targetColumn });
      if (!result || result.kind === 'noop') return;

      if (result.kind === 'blocked') {
        onBlocked?.(result.reason);
        return;
      }

      if (result.kind === 'action') {
        setBusyColumnId(targetColumn.id);
        try {
          await onDropAction?.(result.payload, item);
        } catch {
          // Errors belong to the caller (toast/log inside onDropAction).
        } finally {
          setBusyColumnId(null);
        }
      }
    },
    [columns, findColumnOfCard, findItemById, resolveDrop, onBlocked, onDropAction]
  );

  // All-columns-empty case: nothing to drag, nothing to show — a single
  // EmptyContent replaces the board until the parent provides items.
  if (!loading && (items ?? []).length === 0) {
    return (
      <EmptyContent
        filled
        title={emptyTitle}
        description={emptyDescription}
        sx={{ py: 10, ...sx }}
      />
    );
  }

  return (
    <DndContext
      sensors={sensors}
      collisionDetection={closestCorners}
      measuring={{ droppable: { strategy: MeasuringStrategy.Always } }}
      onDragStart={({ active }) => setActiveId(String(active.id))}
      onDragCancel={() => setActiveId(null)}
      onDragEnd={handleDragEnd}
    >
      <Box sx={{ overflowX: 'auto', pb: 2, ...sx }}>
        <Stack direction="row" spacing={2} sx={{ minWidth: 'min-content' }}>
          {columns.map((col) => (
            <KanbanColumn
              key={col.id}
              column={col}
              items={cardsByColumn[col.id] ?? []}
              getItemId={getItemId}
              activeId={activeId}
              canDropFromActive={canDropOn(col)}
              draggable={!loading && !busyColumnId}
              busy={busyColumnId === col.id}
              columnWidth={columnWidth}
              maxBodyHeight={maxBodyHeight}
              onItemClick={onItemClick}
              renderCard={renderCardFn}
            />
          ))}
        </Stack>
      </Box>

      <Portal>
        <DragOverlay
          adjustScale={false}
          dropAnimation={{
            sideEffects: defaultDropAnimationSideEffects({ styles: { active: { opacity: '0.5' } } }),
          }}
        >
          {activeItem ? (
            <Box sx={{ width: columnWidth - 24, cursor: 'grabbing' }}>
              {renderCardFn(activeItem, { isDragOverlay: true })}
            </Box>
          ) : null}
        </DragOverlay>
      </Portal>
    </DndContext>
  );
}
