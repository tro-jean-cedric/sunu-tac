import { CSS } from '@dnd-kit/utilities';
import { useDroppable } from '@dnd-kit/core';
import { useSortable, SortableContext, verticalListSortingStrategy } from '@dnd-kit/sortable';

import { Box, Chip, Stack, Typography, CircularProgress } from '@mui/material';

import { varAlpha, hideScrollY } from 'src/theme/styles';

import { Iconify } from 'src/components/iconify';

// ----------------------------------------------------------------------

// A single droppable column (internal to KanbanBoard — not part of the public
// API). Cards stay sortable within it (cosmetic reorder only); cross-column
// drops are intercepted by the board to fire workflow actions instead of
// mutating the local order.
//
// `canDropFromActive` controls visual feedback only — the board still gets to
// decide what to do with the drop (so the caller can surface "blocked").
export function KanbanColumn({
  column,
  items,
  getItemId,
  activeId,
  canDropFromActive,
  draggable,
  busy,
  columnWidth,
  maxBodyHeight,
  onItemClick,
  renderCard,
}) {
  const { setNodeRef, isOver } = useDroppable({
    id: column.id,
    data: { type: 'column', column },
  });

  const isDropTarget = isOver && activeId;
  const highlight = isDropTarget && canDropFromActive;
  const dimmed = isDropTarget && !canDropFromActive;

  const accentColor = (theme) =>
    !column.accent || column.accent === 'default'
      ? theme.palette.grey[500]
      : (theme.palette[column.accent]?.main ?? theme.palette.grey[500]);

  return (
    <Stack
      sx={(theme) => ({
        width: columnWidth,
        flexShrink: 0,
        borderRadius: 2,
        position: 'relative',
        bgcolor: theme.palette.background.neutral ?? theme.palette.grey[100],
        border: '1px solid',
        borderColor: highlight
          ? column.accent && column.accent !== 'default'
            ? `${column.accent}.main`
            : 'success.main'
          : dimmed
            ? 'error.main'
            : 'transparent',
        transition: theme.transitions.create(['border-color', 'background-color']),
      })}
    >
      <Stack
        direction="row"
        alignItems="center"
        spacing={1}
        sx={{ px: 2, py: 1.5, borderBottom: '1px solid', borderColor: 'divider' }}
      >
        <Box
          sx={(theme) => ({
            width: 8,
            height: 8,
            borderRadius: '50%',
            bgcolor: accentColor(theme),
          })}
        />
        <Typography variant="subtitle2" sx={{ flexGrow: 1 }} noWrap>
          {column.title}
        </Typography>
        <Chip
          size="small"
          label={items.length}
          sx={{ height: 22, fontWeight: 700, '& .MuiChip-label': { px: 1 } }}
        />
        {Boolean(activeId) && canDropFromActive && (
          <Iconify
            icon="solar:download-square-bold-duotone"
            width={16}
            sx={{ color: 'text.disabled' }}
          />
        )}
      </Stack>

      <Box
        ref={setNodeRef}
        sx={{
          ...hideScrollY,
          minHeight: 80,
          maxHeight: maxBodyHeight,
          p: 1.5,
        }}
      >
        <SortableContext
          items={items.map((item) => String(getItemId(item)))}
          strategy={verticalListSortingStrategy}
        >
          <Stack spacing={1}>
            {items.length === 0 ? (
              <Typography
                variant="caption"
                sx={{ color: 'text.disabled', textAlign: 'center', py: 3 }}
              >
                {column.emptyLabel ?? 'Aucun élément'}
              </Typography>
            ) : (
              items.map((item) => (
                <SortableBoardCard
                  key={String(getItemId(item))}
                  id={String(getItemId(item))}
                  item={item}
                  disabled={!draggable}
                  onItemClick={onItemClick}
                  renderCard={renderCard}
                />
              ))
            )}
          </Stack>
        </SortableContext>
      </Box>

      {/* Busy overlay while the board awaits onDropAction for this column. */}
      {busy && (
        <Stack
          alignItems="center"
          justifyContent="center"
          sx={(theme) => ({
            position: 'absolute',
            inset: 0,
            zIndex: 2,
            borderRadius: 'inherit',
            bgcolor: varAlpha(theme.vars.palette.background.paperChannel, 0.72),
          })}
        >
          <CircularProgress size={28} />
        </Stack>
      )}
    </Stack>
  );
}

// ----------------------------------------------------------------------

// Sortable wrapper around whatever `renderCard` produces. Drag is gated by
// the board (loading / pending action); clicking always goes to onItemClick —
// except the synthetic click dnd-kit fires right after a drag ends.
function SortableBoardCard({ id, item, disabled, onItemClick, renderCard }) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({
    id,
    disabled,
    data: { type: 'card', item },
  });

  const dragStyle = {
    transform: CSS.Translate.toString(transform),
    transition,
    opacity: isDragging ? 0.35 : 1,
  };

  return (
    <Box
      ref={setNodeRef}
      style={dragStyle}
      onClick={(e) => {
        // Ignore the click that ends a drag — dnd-kit fires it after pointer-up.
        if (isDragging) return;
        if (e.defaultPrevented) return;
        onItemClick?.(item);
      }}
      {...attributes}
      {...listeners}
      sx={{
        userSelect: 'none',
        cursor: !disabled ? 'grab' : onItemClick ? 'pointer' : 'default',
        '&:active': { cursor: !disabled ? 'grabbing' : onItemClick ? 'pointer' : 'default' },
      }}
    >
      {renderCard(item, { isDragOverlay: false })}
    </Box>
  );
}
