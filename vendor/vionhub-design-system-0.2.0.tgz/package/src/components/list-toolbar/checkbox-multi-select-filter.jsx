import { useId } from 'react';

import { Select, Checkbox, MenuItem, InputLabel, FormControl, OutlinedInput } from '@mui/material';

// ----------------------------------------------------------------------
// Multi-select filter with checkbox items — the "Rôle" filter of the users
// list view. Renders the selected labels joined with ', ', caps the menu
// height, and absorbs MUI's quirk where a multiple Select can emit its value
// as a comma-joined string. Pairs naturally with FiltersResult chips (one
// chip per selected value, onDelete removes it from `value`).
//
// Props:
// - label         — InputLabel / OutlinedInput label.
// - value         — string[] of selected option values.
// - onChange      — (nextValues: string[]) => void.
// - options       — [{ value, label }].
// - width         — width at md+ (xs is always 100%). Default 200.
// - menuMaxHeight — max height of the dropdown. Default 240.
// - size          — FormControl size ('small' | 'medium'); label and Select
//                   both inherit it so they stay vertically aligned.
// - sx            — merged over the FormControl defaults.

export function CheckboxMultiSelectFilter({
  label,
  value = [],
  onChange,
  options = [],
  width = 200,
  menuMaxHeight = 240,
  size,
  sx,
  ...other
}) {
  const inputId = useId();

  const labelFor = (val) => options.find((opt) => opt.value === val)?.label ?? val;

  return (
    <FormControl size={size} sx={{ flexShrink: 0, width: { xs: 1, md: width }, ...sx }}>
      <InputLabel htmlFor={inputId}>{label}</InputLabel>
      <Select
        multiple
        value={value}
        onChange={(event) =>
          onChange?.(
            typeof event.target.value === 'string'
              ? event.target.value.split(',')
              : event.target.value
          )
        }
        input={<OutlinedInput label={label} />}
        renderValue={(selected) => selected.map(labelFor).join(', ')}
        inputProps={{ id: inputId }}
        MenuProps={{ PaperProps: { sx: { maxHeight: menuMaxHeight } } }}
        {...other}
      >
        {options.map((opt) => (
          <MenuItem key={opt.value} value={opt.value}>
            <Checkbox disableRipple size="small" checked={value.includes(opt.value)} />
            {opt.label}
          </MenuItem>
        ))}
      </Select>
    </FormControl>
  );
}
