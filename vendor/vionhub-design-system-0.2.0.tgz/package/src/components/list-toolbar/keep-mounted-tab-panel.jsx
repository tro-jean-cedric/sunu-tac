import { Box } from '@mui/material';

// ----------------------------------------------------------------------
// Tab panel toggled via display:none instead of unmounting — the pattern from
// the budget-histories dialog: both grids stay mounted so switching tabs
// preserves their rows, pagination and scroll state (no reset to a loading
// spinner). Combined with a cached paginated fetcher, returning to a tab
// paints instantly while a fresh fetch runs silently in the background.
//
// Props:
// - current  — the currently active tab value.
// - value    — the value this panel belongs to.
// - children — panel content (kept mounted while hidden).
// - sx       — merged over the wrapper Box.

export function KeepMountedTabPanel({ current, value, children, sx }) {
  return (
    <Box
      role="tabpanel"
      sx={[{ display: current === value ? 'block' : 'none' }, ...(Array.isArray(sx) ? sx : [sx])]}
    >
      {children}
    </Box>
  );
}
