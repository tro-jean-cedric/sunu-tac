import { Box, Tab, Tabs, Stack } from '@mui/material';

import { Iconify } from 'src/components/iconify';

// ----------------------------------------------------------------------
// Pill-shaped tabs — the rounded-999px tab language shared by the users list
// ("Tous / per-role" selector), the budget-histories dialog (Dépenses /
// Autres mouvements) and the requests scope tabs: hidden indicator, selected
// pill filled primary with a soft glow shadow, black on hover, focus-visible
// outline, optional leading Iconify icon and a count badge that inverts its
// colors when the tab is active.
//
// Props:
// - value    — active tab value.
// - onChange — (nextValue) => void.
// - tabs     — [{ value, label, icon?, count? }]. `icon` is an Iconify name;
//              `count` renders the badge (hidden when falsy).
// - maxBadge — counts above this render as `${maxBadge}+`. Default 99.
// - sx       — merged over the Tabs defaults.
//
// `TabsWithCounts` (see bottom) is an alias kept for API compatibility with
// the users-view naming.

/**
 * One pill tab descriptor.
 *
 * @template {string | number} T
 * @typedef {object} PillTabsItem
 * @property {T} value
 * @property {import('react').ReactNode} label
 * @property {string} [icon] Iconify icon name.
 * @property {number} [count] Badge count — the badge is hidden when falsy.
 */

/**
 * Props of {@link PillTabs}. Everything else is forwarded to MUI's `Tabs`.
 *
 * @template {string | number} T
 * @typedef {{
 *   value: T,
 *   onChange?: (nextValue: T) => void,
 *   tabs?: PillTabsItem<T>[],
 *   maxBadge?: number,
 *   sx?: import('@mui/material').SxProps<import('@mui/material').Theme>,
 * } & Omit<import('@mui/material').TabsProps, 'value' | 'onChange' | 'sx' | 'children'>} PillTabsProps
 */

/**
 * Pill-shaped scrollable tabs with an optional leading icon and count badge.
 *
 * Generic in the tab value so string unions and numeric indexes both keep their
 * exact type in `onChange`.
 *
 * @template {string | number} T
 * @param {PillTabsProps<T>} props
 * @returns {import('react').JSX.Element}
 */
export function PillTabs({ value, onChange, tabs = [], maxBadge = 99, sx, ...other }) {
  return (
    <Tabs
      value={value}
      onChange={(_, next) => onChange?.(next)}
      variant="scrollable"
      scrollButtons="auto"
      allowScrollButtonsMobile
      TabIndicatorProps={{ sx: { display: 'none' } }}
      sx={{
        minHeight: 0,
        '& .MuiTabs-scroller': { py: 1 },
        '& .MuiTabs-flexContainer': { gap: 1 },
        '& .MuiTabScrollButton-root.Mui-disabled': { opacity: 0.3 },
        ...sx,
      }}
      {...other}
    >
      {tabs.map((tab) => {
        const isActive = value === tab.value;
        return (
          <Tab
            key={tab.value}
            value={tab.value}
            disableRipple
            label={
              <Stack direction="row" alignItems="center" spacing={1}>
                {tab.icon && <Iconify icon={tab.icon} width={18} />}
                <span>{tab.label}</span>
                {!!tab.count && (
                  <Box
                    component="span"
                    sx={{
                      height: 22,
                      minWidth: 22,
                      px: 0.75,
                      display: 'inline-flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      fontSize: 12,
                      fontWeight: 700,
                      lineHeight: 1,
                      borderRadius: '11px',
                      bgcolor: isActive ? 'common.white' : 'primary.main',
                      color: isActive ? 'primary.main' : 'common.white',
                    }}
                  >
                    {tab.count > maxBadge ? `${maxBadge}+` : tab.count}
                  </Box>
                )}
              </Stack>
            }
            sx={(theme) => ({
              minHeight: 0,
              py: 1,
              px: 2.25,
              mb: 1,
              borderRadius: '999px',
              textTransform: 'none',
              fontWeight: 600,
              fontSize: 14,
              color: 'text.secondary',
              transition: theme.transitions.create(
                ['background-color', 'color', 'box-shadow', 'transform'],
                { duration: theme.transitions.duration.shorter }
              ),
              '&:hover': {
                color: 'common.white',
                bgcolor: 'common.black',
              },
              '&.Mui-selected': {
                color: 'common.white',
                bgcolor: 'primary.main',
                boxShadow: `0 6px 16px -4px ${theme.palette.primary.main}66`,
                '&:hover': {
                  bgcolor: 'common.black',
                },
              },
              '&.Mui-focusVisible': {
                outline: `2px solid ${theme.palette.primary.main}`,
                outlineOffset: 2,
              },
            })}
          />
        );
      })}
    </Tabs>
  );
}

// ----------------------------------------------------------------------
// Alias for API compatibility with the users list view naming — same
// component, same '99+' badge cap.

export { PillTabs as TabsWithCounts };
