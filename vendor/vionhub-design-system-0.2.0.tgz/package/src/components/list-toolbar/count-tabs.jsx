import { Tab } from '@mui/material';

import { Label } from 'src/components/label';
import { CustomTabs } from 'src/components/custom-tabs';

// ----------------------------------------------------------------------
// CustomTabs-based tabs where each tab carries a Label count badge — the
// notifications drawer style ("Non lues 3 / Toutes 12"): badge at the end of
// the label, `filled` when the tab is active / `soft` otherwise, with a
// per-tab Label color.
//
// Props:
// - value    — active tab value.
// - onChange — (nextValue) => void.
// - tabs     — [{ value, label, count?, color? }]. `color` is a Label color
//              ('default' | 'info' | 'success' | ...); default 'default'.
//              The badge only renders when `count` is a number.
// - variant  — forwarded to CustomTabs (e.g. 'fullWidth').
// - sx       — forwarded to CustomTabs.

export function CountTabs({ value, onChange, tabs = [], variant, sx, ...other }) {
  return (
    <CustomTabs
      variant={variant}
      value={value}
      onChange={(_, next) => onChange?.(next)}
      sx={sx}
      {...other}
    >
      {tabs.map((tab) => (
        <Tab
          key={tab.value}
          iconPosition="end"
          value={tab.value}
          label={tab.label}
          icon={
            typeof tab.count === 'number' ? (
              <Label
                variant={(tab.value === value && 'filled') || 'soft'}
                color={tab.color ?? 'default'}
              >
                {tab.count}
              </Label>
            ) : undefined
          }
        />
      ))}
    </CustomTabs>
  );
}
