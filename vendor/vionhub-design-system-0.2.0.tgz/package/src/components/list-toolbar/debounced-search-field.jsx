import { useRef, useState, useEffect } from 'react';

import { TextField, InputAdornment, CircularProgress } from '@mui/material';

import { Iconify } from 'src/components/iconify';
import { SEARCH_DEBOUNCE_MS } from 'src/components/list-defaults';

// ----------------------------------------------------------------------
// Debounced search TextField — the search box every list page re-implements
// (requests kanban view, AsyncDataGrid toolbar…): magnifier start-adornment,
// spinner end-adornment while loading, and an internal input state that is
// debounced before being emitted so the parent only refetches / refilters
// after the user pauses typing.
//
// Props:
// - value              — optional controlled value (the *debounced* value the
//                        parent holds). When it changes externally — e.g. a
//                        FiltersResult chip clears the search — the input
//                        syncs; while the user is typing it never clobbers.
// - onDebouncedChange  — (nextValue: string) => void, fired once the input
//                        settles for `delay` ms and differs from `value`.
// - delay              — debounce in ms. Default 500 (SEARCH_DEBOUNCE_MS, the
//                        library-wide search debounce, shared with
//                        AsyncDataGrid).
// - loading            — shows a CircularProgress end-adornment (searching /
//                        fetching in progress).
// - placeholder        — default 'Rechercher...'.
// - fullWidth          — passed to TextField.
// - size               — TextField size, default 'small'.
// - sx, ...other       — forwarded to TextField.

/**
 * Own props of {@link DebouncedSearchField}. Everything else is forwarded to
 * MUI's `TextField`.
 *
 * @typedef {object} DebouncedSearchFieldOwnProps
 * @property {string} [value] Controlled *debounced* value held by the parent.
 * @property {(nextValue: string) => void} [onDebouncedChange] Fired with the settled input value — takes a single argument.
 * @property {number} [delay] Debounce in ms. Defaults to `500` — the library-wide `SEARCH_DEBOUNCE_MS`, shared with `AsyncDataGrid`'s `searchDebounce`.
 * @property {boolean} [loading] Shows a spinner end-adornment. Defaults to `false`.
 * @property {string} [placeholder] Defaults to `'Rechercher...'`.
 * @property {boolean} [fullWidth] Defaults to `false`.
 * @property {'small' | 'medium'} [size] Defaults to `'small'`.
 * @property {import('@mui/material').SxProps<import('@mui/material').Theme>} [sx]
 */

/**
 * @typedef {DebouncedSearchFieldOwnProps &
 *   Omit<import('@mui/material').BaseTextFieldProps,
 *     'value' | 'onChange' | 'size' | 'sx' | 'select' | 'children'> &
 *   { variant?: import('@mui/material').TextFieldVariants }} DebouncedSearchFieldProps
 */

/**
 * Search `TextField` whose input is debounced before it reaches the parent.
 *
 * @param {DebouncedSearchFieldProps} props
 * @returns {import('react').JSX.Element}
 */
export function DebouncedSearchField({
  value,
  onDebouncedChange,
  delay = SEARCH_DEBOUNCE_MS,
  loading = false,
  placeholder = 'Rechercher...',
  fullWidth = false,
  size = 'small',
  sx,
  ...other
}) {
  const [inputValue, setInputValue] = useState(value ?? '');
  const isTypingRef = useRef(false);

  // Sync local input when the parent resets/changes the search externally
  // (e.g. clearing the chip in FiltersResult). Don't clobber while typing.
  useEffect(() => {
    if (!isTypingRef.current) {
      setInputValue(value ?? '');
    }
  }, [value]);

  // Debounce inline (same pattern as the original async-data-grid toolbar):
  // after every typing burst the timeout fires, unconditionally resetting
  // isTypingRef — even when the input settled back to its previous value —
  // then emits only if the settled value differs from the parent's.
  useEffect(() => {
    if (!isTypingRef.current) return undefined;
    const t = setTimeout(() => {
      isTypingRef.current = false;
      if (inputValue !== (value ?? '')) {
        onDebouncedChange?.(inputValue);
      }
    }, delay);
    return () => clearTimeout(t);
  }, [inputValue, value, delay, onDebouncedChange]);

  return (
    <TextField
      size={size}
      fullWidth={fullWidth}
      value={inputValue}
      onChange={(event) => {
        isTypingRef.current = true;
        setInputValue(event.target.value);
      }}
      placeholder={placeholder}
      InputProps={{
        startAdornment: (
          <InputAdornment position="start">
            <Iconify icon="eva:search-fill" sx={{ color: 'text.disabled' }} />
          </InputAdornment>
        ),
        endAdornment: loading ? (
          <InputAdornment position="end">
            <CircularProgress size={16} />
          </InputAdornment>
        ) : null,
      }}
      sx={sx}
      {...other}
    />
  );
}
